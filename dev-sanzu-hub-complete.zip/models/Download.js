/**
 * ================================================
 * MODÈLE DOWNLOAD
 * ================================================
 * Suivi des téléchargements de fichiers
 */

const { pool } = require('../config/database');
const { v4: uuidv4 } = require('uuid');
const logger = require('../config/logger');

class Download {
    /**
     * Enregistrer un téléchargement
     * @param {Object} downloadData - Données du téléchargement
     * @returns {Promise<Object>} Téléchargement enregistré
     */
    static async create(downloadData) {
        try {
            const { userId, projectId, botType, fileName, fileSize, ipAddress } = downloadData;
            const id = uuidv4();

            const result = await pool.query(
                `INSERT INTO downloads 
                 (id, user_id, project_id, bot_type, file_name, file_size, ip_address)
                 VALUES ($1, $2, $3, $4, $5, $6, $7)
                 RETURNING *`,
                [id, userId, projectId, botType, fileName, fileSize, ipAddress]
            );

            logger.info(`✓ Téléchargement enregistré: ${fileName}`);
            return result.rows[0];
        } catch (error) {
            logger.error(`Erreur enregistrement téléchargement: ${error.message}`);
            throw error;
        }
    }

    /**
     * Obtenir les téléchargements d'un utilisateur
     * @param {string} userId - ID de l'utilisateur
     * @param {number} limit - Limite
     * @param {number} offset - Décalage
     * @returns {Promise<Array>} Téléchargements de l'utilisateur
     */
    static async getByUser(userId, limit = 50, offset = 0) {
        try {
            const result = await pool.query(
                `SELECT d.*, p.title as project_title
                 FROM downloads d
                 LEFT JOIN projects p ON d.project_id = p.id
                 WHERE d.user_id = $1
                 ORDER BY d.created_at DESC
                 LIMIT $2 OFFSET $3`,
                [userId, limit, offset]
            );
            return result.rows;
        } catch (error) {
            logger.error(`Erreur téléchargements utilisateur: ${error.message}`);
            throw error;
        }
    }

    /**
     * Obtenir les téléchargements d'un projet
     * @param {string} projectId - ID du projet
     * @param {number} limit - Limite
     * @param {number} offset - Décalage
     * @returns {Promise<Array>} Téléchargements du projet
     */
    static async getByProject(projectId, limit = 50, offset = 0) {
        try {
            const result = await pool.query(
                `SELECT d.*, u.username as user_name
                 FROM downloads d
                 LEFT JOIN users u ON d.user_id = u.id
                 WHERE d.project_id = $1
                 ORDER BY d.created_at DESC
                 LIMIT $2 OFFSET $3`,
                [projectId, limit, offset]
            );
            return result.rows;
        } catch (error) {
            logger.error(`Erreur téléchargements projet: ${error.message}`);
            throw error;
        }
    }

    /**
     * Obtenir les téléchargements par type de bot
     * @param {string} botType - Type de bot (telegram, whatsapp)
     * @param {number} limit - Limite
     * @param {number} offset - Décalage
     * @returns {Promise<Array>} Téléchargements du type
     */
    static async getByBotType(botType, limit = 50, offset = 0) {
        try {
            const result = await pool.query(
                `SELECT d.*, u.username as user_name, p.title as project_title
                 FROM downloads d
                 LEFT JOIN users u ON d.user_id = u.id
                 LEFT JOIN projects p ON d.project_id = p.id
                 WHERE d.bot_type = $1
                 ORDER BY d.created_at DESC
                 LIMIT $2 OFFSET $3`,
                [botType, limit, offset]
            );
            return result.rows;
        } catch (error) {
            logger.error(`Erreur téléchargements par type: ${error.message}`);
            throw error;
        }
    }

    /**
     * Obtenir tous les téléchargements (pour admin)
     * @param {number} limit - Limite
     * @param {number} offset - Décalage
     * @returns {Promise<Array>} Tous les téléchargements
     */
    static async getAll(limit = 50, offset = 0) {
        try {
            const result = await pool.query(
                `SELECT d.*, u.username as user_name, p.title as project_title
                 FROM downloads d
                 LEFT JOIN users u ON d.user_id = u.id
                 LEFT JOIN projects p ON d.project_id = p.id
                 ORDER BY d.created_at DESC
                 LIMIT $1 OFFSET $2`,
                [limit, offset]
            );
            return result.rows;
        } catch (error) {
            logger.error(`Erreur récupération téléchargements: ${error.message}`);
            throw error;
        }
    }

    /**
     * Obtenir les statistiques de téléchargements
     * @returns {Promise<Object>} Statistiques
     */
    static async getStatistics() {
        try {
            const result = await pool.query(`
                SELECT 
                    COUNT(*) as total_downloads,
                    COUNT(DISTINCT user_id) as unique_users,
                    COUNT(DISTINCT project_id) as projects_downloaded,
                    SUM(file_size) as total_size_downloaded,
                    AVG(file_size) as average_file_size
                FROM downloads
            `);
            return result.rows[0];
        } catch (error) {
            logger.error(`Erreur statistiques: ${error.message}`);
            throw error;
        }
    }

    /**
     * Obtenir les téléchargements des 7 derniers jours
     * @returns {Promise<Object>} Statistiques
     */
    static async getRecentStats() {
        try {
            const result = await pool.query(`
                SELECT 
                    DATE(created_at) as download_date,
                    COUNT(*) as daily_downloads,
                    SUM(file_size) as daily_size
                FROM downloads
                WHERE created_at >= NOW() - INTERVAL '7 days'
                GROUP BY DATE(created_at)
                ORDER BY download_date DESC
            `);
            return result.rows;
        } catch (error) {
            logger.error(`Erreur statistiques récentes: ${error.message}`);
            throw error;
        }
        }

    /**
     * Compter les téléchargements d'un utilisateur
     * @param {string} userId - ID de l'utilisateur
     * @returns {Promise<number>} Nombre de téléchargements
     */
    static async countByUser(userId) {
        try {
            const result = await pool.query(
                'SELECT COUNT(*) as count FROM downloads WHERE user_id = $1',
                [userId]
            );
            return parseInt(result.rows[0].count);
        } catch (error) {
            logger.error(`Erreur compte téléchargements: ${error.message}`);
            throw error;
        }
    }

    /**
     * Obtenir les projets les plus téléchargés
     * @param {number} limit - Limite
     * @returns {Promise<Array>} Projets populaires
     */
    static async getMostDownloaded(limit = 10) {
        try {
            const result = await pool.query(
                `SELECT 
                    d.project_id,
                    p.title,
                    COUNT(*) as download_count,
                    SUM(d.file_size) as total_size
                 FROM downloads d
                 LEFT JOIN projects p ON d.project_id = p.id
                 WHERE d.project_id IS NOT NULL
                 GROUP BY d.project_id, p.title
                 ORDER BY download_count DESC
                 LIMIT $1`,
                [limit]
            );
            return result.rows;
        } catch (error) {
            logger.error(`Erreur projets populaires: ${error.message}`);
            throw error;
        }
    }

    /**
     * Obtenir les téléchargements par adresse IP
     * @param {string} ipAddress - Adresse IP
     * @param {number} limit - Limite
     * @returns {Promise<Array>} Téléchargements de l'IP
     */
    static async getByIpAddress(ipAddress, limit = 50) {
        try {
            const result = await pool.query(
                `SELECT d.*, u.username as user_name, p.title as project_title
                 FROM downloads d
                 LEFT JOIN users u ON d.user_id = u.id
                 LEFT JOIN projects p ON d.project_id = p.id
                 WHERE d.ip_address = $1
                 ORDER BY d.created_at DESC
                 LIMIT $2`,
                [ipAddress, limit]
            );
            return result.rows;
        } catch (error) {
            logger.error(`Erreur téléchargements IP: ${error.message}`);
            throw error;
        }
    }
}

module.exports = Download;
