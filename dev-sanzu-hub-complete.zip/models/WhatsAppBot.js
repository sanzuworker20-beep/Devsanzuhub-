/**
 * ================================================
 * MODÈLE BOT WHATSAPP
 * ================================================
 * Gestion des bots WhatsApp gratuits
 */

const { pool } = require('../config/database');
const { v4: uuidv4 } = require('uuid');
const logger = require('../config/logger');

class WhatsAppBot {
    /**
     * Créer un nouveau bot WhatsApp
     * @param {Object} botData - Données du bot
     * @returns {Promise<Object>} Bot créé
     */
    static async create(botData) {
        try {
            const { projectId, name, description, version, features, fileUrl, filePath, fileSize, changelog } = botData;
            const id = uuidv4();

            const result = await pool.query(
                `INSERT INTO whatsapp_bots 
                 (id, project_id, name, description, version, features, file_url, file_path, file_size, changelog)
                 VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
                 RETURNING *`,
                [id, projectId, name, description, version, features, fileUrl, filePath, fileSize, changelog]
            );

            logger.info(`✓ Nouveau bot WhatsApp créé: ${name}`);
            return result.rows[0];
        } catch (error) {
            logger.error(`Erreur création bot WhatsApp: ${error.message}`);
            throw error;
        }
    }

    /**
     * Obtenir un bot par ID
     * @param {string} id - ID du bot
     * @returns {Promise<Object|null>} Bot trouvé ou null
     */
    static async findById(id) {
        try {
            const result = await pool.query(
                `SELECT wb.*, p.title as project_title
                 FROM whatsapp_bots wb
                 LEFT JOIN projects p ON wb.project_id = p.id
                 WHERE wb.id = $1`,
                [id]
            );
            return result.rows[0] || null;
        } catch (error) {
            logger.error(`Erreur recherche bot: ${error.message}`);
            throw error;
        }
    }

    /**
     * Obtenir tous les bots WhatsApp
     * @param {number} limit - Limite
     * @param {number} offset - Décalage
     * @returns {Promise<Array>} Bots WhatsApp
     */
    static async getAll(limit = 20, offset = 0) {
        try {
            const result = await pool.query(
                `SELECT wb.*, p.title as project_title, p.image_url
                 FROM whatsapp_bots wb
                 LEFT JOIN projects p ON wb.project_id = p.id
                 ORDER BY wb.created_at DESC
                 LIMIT $1 OFFSET $2`,
                [limit, offset]
            );
            return result.rows;
        } catch (error) {
            logger.error(`Erreur récupération bots: ${error.message}`);
            throw error;
        }
    }

    /**
     * Chercher des bots
     * @param {string} searchTerm - Terme de recherche
     * @param {number} limit - Limite
     * @param {number} offset - Décalage
     * @returns {Promise<Array>} Bots trouvés
     */
    static async search(searchTerm, limit = 20, offset = 0) {
        try {
            const result = await pool.query(
                `SELECT wb.*, p.title as project_title, p.image_url
                 FROM whatsapp_bots wb
                 LEFT JOIN projects p ON wb.project_id = p.id
                 WHERE wb.name ILIKE $1 OR wb.description ILIKE $1
                 ORDER BY wb.created_at DESC
                 LIMIT $2 OFFSET $3`,
                [`%${searchTerm}%`, limit, offset]
            );
            return result.rows;
        } catch (error) {
            logger.error(`Erreur recherche bot: ${error.message}`);
            throw error;
        }
    }

    /**
     * Obtenir les bots populaires
     * @param {number} limit - Limite
     * @returns {Promise<Array>} Bots populaires
     */
    static async getPopular(limit = 10) {
        try {
            const result = await pool.query(
                `SELECT wb.*, p.title as project_title, p.image_url
                 FROM whatsapp_bots wb
                 LEFT JOIN projects p ON wb.project_id = p.id
                 ORDER BY wb.download_count DESC
                 LIMIT $1`,
                [limit]
            );
            return result.rows;
        } catch (error) {
            logger.error(`Erreur bots populaires: ${error.message}`);
            throw error;
        }
    }

    /**
     * Obtenir les derniers bots
     * @param {number} limit - Limite
     * @returns {Promise<Array>} Derniers bots
     */
    static async getLatest(limit = 10) {
        try {
            const result = await pool.query(
                `SELECT wb.*, p.title as project_title, p.image_url
                 FROM whatsapp_bots wb
                 LEFT JOIN projects p ON wb.project_id = p.id
                 ORDER BY wb.created_at DESC
                 LIMIT $1`,
                [limit]
            );
            return result.rows;
        } catch (error) {
            logger.error(`Erreur derniers bots: ${error.message}`);
            throw error;
        }
    }

    /**
     * Mettre à jour un bot
     * @param {string} id - ID du bot
     * @param {Object} updateData - Données à mettre à jour
     * @returns {Promise<Object>} Bot mis à jour
     */
    static async update(id, updateData) {
        try {
            const { name, description, version, features, changelog } = updateData;

            const result = await pool.query(
                `UPDATE whatsapp_bots 
                 SET name = COALESCE($2, name),
                     description = COALESCE($3, description),
                     version = COALESCE($4, version),
                     features = COALESCE($5, features),
                     changelog = COALESCE($6, changelog),
                     updated_at = CURRENT_TIMESTAMP
                 WHERE id = $1
                 RETURNING *`,
                [id, name, description, version, features, changelog]
            );

            if (result.rows.length === 0) {
                throw new Error('Bot non trouvé');
            }

            logger.info(`✓ Bot ${id} mis à jour`);
            return result.rows[0];
        } catch (error) {
            logger.error(`Erreur mise à jour bot: ${error.message}`);
            throw error;
        }
    }

    /**
     * Incrémenter le compteur de téléchargements
     * @param {string} id - ID du bot
     * @returns {Promise<void>}
     */
    static async incrementDownloadCount(id) {
        try {
            await pool.query(
                'UPDATE whatsapp_bots SET download_count = download_count + 1 WHERE id = $1',
                [id]
            );
        } catch (error) {
            logger.error(`Erreur incrément téléchargements: ${error.message}`);
            throw error;
        }
    }

    /**
     * Supprimer un bot
     * @param {string} id - ID du bot
     * @returns {Promise<void>}
     */
    static async delete(id) {
        try {
            await pool.query('DELETE FROM whatsapp_bots WHERE id = $1', [id]);
            logger.info(`✓ Bot WhatsApp ${id} supprimé`);
        } catch (error) {
            logger.error(`Erreur suppression bot: ${error.message}`);
            throw error;
        }
    }

    /**
     * Obtenir les bots par projet
     * @param {string} projectId - ID du projet
     * @returns {Promise<Array>} Bots du projet
     */
    static async getByProject(projectId) {
        try {
            const result = await pool.query(
                'SELECT * FROM whatsapp_bots WHERE project_id = $1 ORDER BY created_at DESC',
                [projectId]
            );
            return result.rows;
        } catch (error) {
            logger.error(`Erreur bots par projet: ${error.message}`);
            throw error;
        }
    }

    /**
     * Compter le nombre total de bots
     * @returns {Promise<number>} Nombre de bots
     */
    static async count() {
        try {
            const result = await pool.query('SELECT COUNT(*) as count FROM whatsapp_bots');
            return parseInt(result.rows[0].count);
        } catch (error) {
            logger.error(`Erreur compte bots: ${error.message}`);
            throw error;
        }
    }

    /**
     * Obtenir les statistiques globales
     * @returns {Promise<Object>} Statistiques
     */
    static async getStatistics() {
        try {
            const result = await pool.query(`
                SELECT 
                    COUNT(*) as total_bots,
                    SUM(download_count) as total_downloads
                FROM whatsapp_bots
            `);
            return result.rows[0];
        } catch (error) {
            logger.error(`Erreur statistiques: ${error.message}`);
            throw error;
        }
    }
}

module.exports = WhatsAppBot;
