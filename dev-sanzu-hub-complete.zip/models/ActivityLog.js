/**
 * ================================================
 * MODÈLE ACTIVITÉ LOG
 * ================================================
 * Suivi des activités des utilisateurs
 */

const { pool } = require('../config/database');
const { v4: uuidv4 } = require('uuid');
const logger = require('../config/logger');

class ActivityLog {
    /**
     * Enregistrer une activité
     * @param {Object} logData - Données de l'activité
     * @returns {Promise<Object>} Log enregistré
     */
    static async create(logData) {
        try {
            const { userId, action, entityType, entityId, details, ipAddress } = logData;
            const id = uuidv4();

            const result = await pool.query(
                `INSERT INTO activity_logs 
                 (id, user_id, action, entity_type, entity_id, details, ip_address)
                 VALUES ($1, $2, $3, $4, $5, $6, $7)
                 RETURNING *`,
                [id, userId, action, entityType, entityId, details, ipAddress]
            );

            logger.debug(`✓ Activité enregistrée: ${action} par ${userId}`);
            return result.rows[0];
        } catch (error) {
            logger.error(`Erreur enregistrement activité: ${error.message}`);
            throw error;
        }
    }

    /**
     * Obtenir les activités d'un utilisateur
     * @param {string} userId - ID de l'utilisateur
     * @param {number} limit - Limite
     * @param {number} offset - Décalage
     * @returns {Promise<Array>} Activités de l'utilisateur
     */
    static async getByUser(userId, limit = 50, offset = 0) {
        try {
            const result = await pool.query(
                `SELECT * FROM activity_logs 
                 WHERE user_id = $1
                 ORDER BY created_at DESC
                 LIMIT $2 OFFSET $3`,
                [userId, limit, offset]
            );
            return result.rows;
        } catch (error) {
            logger.error(`Erreur activités utilisateur: ${error.message}`);
            throw error;
        }
    }

    /**
     * Obtenir toutes les activités (pour admin)
     * @param {number} limit - Limite
     * @param {number} offset - Décalage
     * @returns {Promise<Array>} Toutes les activités
     */
    static async getAll(limit = 100, offset = 0) {
        try {
            const result = await pool.query(
                `SELECT al.*, u.username as user_name
                 FROM activity_logs al
                 LEFT JOIN users u ON al.user_id = u.id
                 ORDER BY al.created_at DESC
                 LIMIT $1 OFFSET $2`,
                [limit, offset]
            );
            return result.rows;
        } catch (error) {
            logger.error(`Erreur récupération activités: ${error.message}`);
            throw error;
        }
    }

    /**
     * Obtenir les activités par type d'action
     * @param {string} action - Type d'action
     * @param {number} limit - Limite
     * @param {number} offset - Décalage
     * @returns {Promise<Array>} Activités du type
     */
    static async getByAction(action, limit = 50, offset = 0) {
        try {
            const result = await pool.query(
                `SELECT al.*, u.username as user_name
                 FROM activity_logs al
                 LEFT JOIN users u ON al.user_id = u.id
                 WHERE al.action = $1
                 ORDER BY al.created_at DESC
                 LIMIT $2 OFFSET $3`,
                [action, limit, offset]
            );
            return result.rows;
        } catch (error) {
            logger.error(`Erreur activités par action: ${error.message}`);
            throw error;
        }
    }

    /**
     * Obtenir les activités par type d'entité
     * @param {string} entityType - Type d'entité
     * @param {number} limit - Limite
     * @param {number} offset - Décalage
     * @returns {Promise<Array>} Activités du type
     */
    static async getByEntityType(entityType, limit = 50, offset = 0) {
        try {
            const result = await pool.query(
                `SELECT al.*, u.username as user_name
                 FROM activity_logs al
                 LEFT JOIN users u ON al.user_id = u.id
                 WHERE al.entity_type = $1
                 ORDER BY al.created_at DESC
                 LIMIT $2 OFFSET $3`,
                [entityType, limit, offset]
            );
            return result.rows;
        } catch (error) {
            logger.error(`Erreur activités par entité: ${error.message}`);
            throw error;
        }
    }

    /**
     * Obtenir les activités des 24 dernières heures
     * @returns {Promise<Array>} Activités récentes
     */
    static async getRecent24Hours() {
        try {
            const result = await pool.query(
                `SELECT al.*, u.username as user_name
                 FROM activity_logs al
                 LEFT JOIN users u ON al.user_id = u.id
                 WHERE al.created_at >= NOW() - INTERVAL '24 hours'
                 ORDER BY al.created_at DESC`
            );
            return result.rows;
        } catch (error) {
            logger.error(`Erreur activités récentes: ${error.message}`);
            throw error;
        }
    }

    /**
     * Obtenir les activités suspectes (plusieurs tentatives)
     * @returns {Promise<Array>} Activités suspectes
     */
    static async getSuspiciousActivity() {
        try {
            const result = await pool.query(
                `SELECT 
                    ip_address,
                    COUNT(*) as attempt_count,
                    MAX(created_at) as last_attempt
                 FROM activity_logs
                 WHERE action IN ('login_failed', 'invalid_payment')
                 GROUP BY ip_address
                 HAVING COUNT(*) > 5
                 ORDER BY attempt_count DESC`
            );
            return result.rows;
        } catch (error) {
            logger.error(`Erreur activités suspectes: ${error.message}`);
            throw error;
        }
    }

    /**
     * Obtenir les statistiques d'activité
     * @returns {Promise<Object>} Statistiques
     */
    static async getStatistics() {
        try {
            const result = await pool.query(`
                SELECT 
                    COUNT(*) as total_activities,
                    COUNT(DISTINCT user_id) as active_users,
                    COUNT(DISTINCT action) as unique_actions,
                    MAX(created_at) as last_activity
                FROM activity_logs
            `);
            return result.rows[0];
        } catch (error) {
            logger.error(`Erreur statistiques: ${error.message}`);
            throw error;
        }
    }

    /**
     * Obtenir le résumé des activités par jour
     * @param {number} days - Nombre de jours à analyser
     * @returns {Promise<Array>} Résumé par jour
     */
    static async getActivityByDay(days = 30) {
        try {
            const result = await pool.query(
                `SELECT 
                    DATE(created_at) as activity_date,
                    COUNT(*) as daily_count,
                    COUNT(DISTINCT user_id) as unique_users
                 FROM activity_logs
                 WHERE created_at >= NOW() - INTERVAL '${days} days'
                 GROUP BY DATE(created_at)
                 ORDER BY activity_date DESC`
            );
            return result.rows;
        } catch (error) {
            logger.error(`Erreur activités par jour: ${error.message}`);
            throw error;
        }
    }

    /**
     * Nettoyer les anciens logs (archivage)
     * @param {number} daysOld - Supprimer les logs plus anciens que X jours
     * @returns {Promise<number>} Nombre de lignes supprimées
     */
    static async cleanOldLogs(daysOld = 90) {
        try {
            const result = await pool.query(
                `DELETE FROM activity_logs 
                 WHERE created_at < NOW() - INTERVAL '${daysOld} days'`
            );
            logger.info(`✓ Logs nettoyés: ${result.rowCount} lignes supprimées`);
            return result.rowCount;
        } catch (error) {
            logger.error(`Erreur nettoyage logs: ${error.message}`);
            throw error;
        }
    }

    /**
     * Exporter les logs au format JSON
     * @param {string} userId - ID de l'utilisateur (optionnel)
     * @returns {Promise<Array>} Logs en JSON
     */
    static async exportAsJSON(userId = null) {
        try {
            let query = 'SELECT * FROM activity_logs';
            let params = [];

            if (userId) {
                query += ' WHERE user_id = $1';
                params = [userId];
            }

            query += ' ORDER BY created_at DESC';

            const result = await pool.query(query, params);
            return result.rows;
        } catch (error) {
            logger.error(`Erreur export logs: ${error.message}`);
            throw error;
        }
    }
}

module.exports = ActivityLog;
