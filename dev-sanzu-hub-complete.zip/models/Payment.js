/**
 * ================================================
 * MODÈLE PAIEMENT
 * ================================================
 * Gestion des paiements et transactions
 */

const { pool } = require('../config/database');
const { v4: uuidv4 } = require('uuid');
const logger = require('../config/logger');

class Payment {
    /**
     * Créer un nouveau paiement
     * @param {Object} paymentData - Données du paiement
     * @returns {Promise<Object>} Paiement créé
     */
    static async create(paymentData) {
        try {
            const { userId, methodId, amount, currency, paymentMethod, transactionId, notes } = paymentData;
            const id = uuidv4();

            const result = await pool.query(
                `INSERT INTO payments 
                 (id, user_id, method_id, amount, currency, payment_method, transaction_id, notes, status)
                 VALUES ($1, $2, $3, $4, $5, $6, $7, $8, 'pending')
                 RETURNING *`,
                [id, userId, methodId, amount, currency, paymentMethod, transactionId, notes]
            );

            logger.info(`✓ Nouveau paiement créé: ${id}`);
            return result.rows[0];
        } catch (error) {
            logger.error(`Erreur création paiement: ${error.message}`);
            throw error;
        }
    }

    /**
     * Obtenir un paiement par ID
     * @param {string} id - ID du paiement
     * @returns {Promise<Object|null>} Paiement trouvé ou null
     */
    static async findById(id) {
        try {
            const result = await pool.query(
                `SELECT p.*, m.title as method_title, u.email as user_email 
                 FROM payments p 
                 LEFT JOIN methods m ON p.method_id = m.id
                 LEFT JOIN users u ON p.user_id = u.id
                 WHERE p.id = $1`,
                [id]
            );
            return result.rows[0] || null;
        } catch (error) {
            logger.error(`Erreur recherche paiement: ${error.message}`);
            throw error;
        }
    }

    /**
     * Obtenir les paiements d'un utilisateur
     * @param {string} userId - ID de l'utilisateur
     * @param {number} limit - Limite
     * @param {number} offset - Décalage
     * @returns {Promise<Array>} Paiements de l'utilisateur
     */
    static async getByUser(userId, limit = 50, offset = 0) {
        try {
            const result = await pool.query(
                `SELECT p.*, m.title as method_title 
                 FROM payments p 
                 LEFT JOIN methods m ON p.method_id = m.id
                 WHERE p.user_id = $1
                 ORDER BY p.created_at DESC
                 LIMIT $2 OFFSET $3`,
                [userId, limit, offset]
            );
            return result.rows;
        } catch (error) {
            logger.error(`Erreur paiements utilisateur: ${error.message}`);
            throw error;
        }
    }

    /**
     * Obtenir les paiements en attente de validation
     * @param {number} limit - Limite
     * @param {number} offset - Décalage
     * @returns {Promise<Array>} Paiements en attente
     */
    static async getPending(limit = 50, offset = 0) {
        try {
            const result = await pool.query(
                `SELECT p.*, m.title as method_title, u.email as user_email 
                 FROM payments p 
                 LEFT JOIN methods m ON p.method_id = m.id
                 LEFT JOIN users u ON p.user_id = u.id
                 WHERE p.status = 'pending'
                 ORDER BY p.created_at ASC
                 LIMIT $1 OFFSET $2`,
                [limit, offset]
            );
            return result.rows;
        } catch (error) {
            logger.error(`Erreur paiements en attente: ${error.message}`);
            throw error;
        }
    }

    /**
     * Obtenir les paiements validés
     * @param {number} limit - Limite
     * @param {number} offset - Décalage
     * @returns {Promise<Array>} Paiements validés
     */
    static async getValidated(limit = 50, offset = 0) {
        try {
            const result = await pool.query(
                `SELECT p.*, m.title as method_title, u.email as user_email 
                 FROM payments p 
                 LEFT JOIN methods m ON p.method_id = m.id
                 LEFT JOIN users u ON p.user_id = u.id
                 WHERE p.is_validated = TRUE
                 ORDER BY p.validated_at DESC
                 LIMIT $1 OFFSET $2`,
                [limit, offset]
            );
            return result.rows;
        } catch (error) {
            logger.error(`Erreur paiements validés: ${error.message}`);
            throw error;
        }
    }

    /**
     * Valider un paiement (par admin)
     * @param {string} paymentId - ID du paiement
     * @param {string} adminId - ID de l'admin qui valide
     * @param {string} validationNotes - Notes de validation
     * @returns {Promise<Object>} Paiement validé
     */
    static async validate(paymentId, adminId, validationNotes = '') {
        try {
            const result = await pool.query(
                `UPDATE payments 
                 SET is_validated = TRUE,
                     status = 'completed',
                     validation_notes = $2,
                     validated_by = $3,
                     validated_at = CURRENT_TIMESTAMP,
                     updated_at = CURRENT_TIMESTAMP
                 WHERE id = $1
                 RETURNING *`,
                [paymentId, validationNotes, adminId]
            );

            if (result.rows.length === 0) {
                throw new Error('Paiement non trouvé');
            }

            logger.info(`✓ Paiement ${paymentId} validé par ${adminId}`);
            return result.rows[0];
        } catch (error) {
            logger.error(`Erreur validation paiement: ${error.message}`);
            throw error;
        }
    }

    /**
     * Rejeter un paiement
     * @param {string} paymentId - ID du paiement
     * @param {string} adminId - ID de l'admin qui rejette
     * @param {string} rejectionNotes - Raison du rejet
     * @returns {Promise<Object>} Paiement rejeté
     */
    static async reject(paymentId, adminId, rejectionNotes = '') {
        try {
            const result = await pool.query(
                `UPDATE payments 
                 SET status = 'rejected',
                     validation_notes = $2,
                     validated_by = $3,
                     validated_at = CURRENT_TIMESTAMP,
                     updated_at = CURRENT_TIMESTAMP
                 WHERE id = $1
                 RETURNING *`,
                [paymentId, rejectionNotes, adminId]
            );

            if (result.rows.length === 0) {
                throw new Error('Paiement non trouvé');
            }

            logger.info(`✓ Paiement ${paymentId} rejeté par ${adminId}`);
            return result.rows[0];
        } catch (error) {
            logger.error(`Erreur rejet paiement: ${error.message}`);
            throw error;
        }
    }

    /**
     * Débloquer les coordonnées après paiement validé
     * @param {string} paymentId - ID du paiement
     * @returns {Promise<void>}
     */
    static async unlockContact(paymentId) {
        try {
            // Obtenir l'utilisateur lié au paiement
            const paymentResult = await pool.query(
                'SELECT user_id FROM payments WHERE id = $1',
                [paymentId]
            );

            if (paymentResult.rows.length === 0) {
                throw new Error('Paiement non trouvé');
            }

            const userId = paymentResult.rows[0].user_id;

            // Débloquer les coordonnées de l'utilisateur
            await pool.query(
                `UPDATE users 
                 SET is_contact_locked = FALSE,
                     unlocked_at = CURRENT_TIMESTAMP
                 WHERE id = $1`,
                [userId]
            );

            // Marquer le contact comme débloqué dans le paiement
            await pool.query(
                `UPDATE payments 
                 SET contact_unlocked = TRUE,
                     unlocked_at = CURRENT_TIMESTAMP
                 WHERE id = $1`,
                [paymentId]
            );

            logger.info(`✓ Coordonnées débloquées pour paiement ${paymentId}`);
        } catch (error) {
            logger.error(`Erreur déblocage coordonnées: ${error.message}`);
            throw error;
        }
    }

    /**
     * Obtenir toutes les transactions (pour admin)
     * @param {number} limit - Limite
     * @param {number} offset - Décalage
     * @returns {Promise<Array>} Toutes les transactions
     */
    static async getAll(limit = 50, offset = 0) {
        try {
            const result = await pool.query(
                `SELECT p.*, m.title as method_title, u.email as user_email 
                 FROM payments p 
                 LEFT JOIN methods m ON p.method_id = m.id
                 LEFT JOIN users u ON p.user_id = u.id
                 ORDER BY p.created_at DESC
                 LIMIT $1 OFFSET $2`,
                [limit, offset]
            );
            return result.rows;
        } catch (error) {
            logger.error(`Erreur récupération paiements: ${error.message}`);
            throw error;
        }
    }

    /**
     * Obtenir les statistiques de paiement
     * @returns {Promise<Object>} Statistiques
     */
    static async getStatistics() {
        try {
            const result = await pool.query(`
                SELECT 
                    COUNT(*) as total_payments,
                    SUM(CASE WHEN is_validated = TRUE THEN 1 ELSE 0 END) as validated_payments,
                    SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending_payments,
                    SUM(CASE WHEN is_validated = TRUE THEN amount ELSE 0 END) as total_revenue,
                    AVG(CASE WHEN is_validated = TRUE THEN amount END) as average_payment
                FROM payments
            `);
            return result.rows[0];
        } catch (error) {
            logger.error(`Erreur statistiques: ${error.message}`);
            throw error;
        }
    }

    /**
     * Compter les paiements en attente de validation
     * @returns {Promise<number>} Nombre de paiements en attente
     */
    static async countPending() {
        try {
            const result = await pool.query(
                "SELECT COUNT(*) as count FROM payments WHERE status = 'pending'"
            );
            return parseInt(result.rows[0].count);
        } catch (error) {
            logger.error(`Erreur compte paiements: ${error.message}`);
            throw error;
        }
    }
}

module.exports = Payment;
