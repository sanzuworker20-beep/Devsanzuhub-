/**
 * ================================================
 * MODÈLE SETTINGS
 * ================================================
 * Gestion des paramètres globaux du site
 * Administrable 100% via le panneau d'administration
 */

const { pool } = require('../config/database');
const { v4: uuidv4 } = require('uuid');
const logger = require('../config/logger');

class Settings {
    /**
     * Obtenir une paramètre par clé
     * @param {string} key - Clé du paramètre
     * @returns {Promise<string|null>} Valeur du paramètre
     */
    static async get(key) {
        try {
            const result = await pool.query(
                'SELECT setting_value FROM settings WHERE setting_key = $1',
                [key]
            );
            return result.rows.length > 0 ? result.rows[0].setting_value : null;
        } catch (error) {
            logger.error(`Erreur récupération setting: ${error.message}`);
            throw error;
        }
    }

    /**
     * Obtenir toutes les paramètres
     * @returns {Promise<Array>} Tous les paramètres
     */
    static async getAll() {
        try {
            const result = await pool.query(
                'SELECT * FROM settings ORDER BY setting_key ASC'
            );
            return result.rows;
        } catch (error) {
            logger.error(`Erreur récupération settings: ${error.message}`);
            throw error;
        }
    }

    /**
     * Obtenir les paramètres par catégorie
     * @param {string} category - Catégorie
     * @returns {Promise<Array>} Paramètres de la catégorie
     */
    static async getByCategory(category) {
        try {
            const result = await pool.query(
                `SELECT * FROM settings 
                 WHERE setting_key LIKE $1 
                 ORDER BY setting_key ASC`,
                [`${category}_%`]
            );
            return result.rows;
        } catch (error) {
            logger.error(`Erreur récupération settings par catégorie: ${error.message}`);
            throw error;
        }
    }

    /**
     * Définir une paramètre
     * @param {string} key - Clé du paramètre
     * @param {string} value - Valeur
     * @param {string} type - Type (string, boolean, json, etc.)
     * @param {string} description - Description
     * @returns {Promise<Object>} Paramètre mis à jour ou créé
     */
    static async set(key, value, type = 'string', description = '') {
        try {
            // Vérifier si existe
            const existing = await pool.query(
                'SELECT id FROM settings WHERE setting_key = $1',
                [key]
            );

            let result;
            if (existing.rows.length > 0) {
                // Mettre à jour
                result = await pool.query(
                    `UPDATE settings 
                     SET setting_value = $2, 
                         setting_type = $3,
                         description = COALESCE($4, description),
                         updated_at = CURRENT_TIMESTAMP
                     WHERE setting_key = $1
                     RETURNING *`,
                    [key, value, type, description]
                );
            } else {
                // Créer
                const id = uuidv4();
                result = await pool.query(
                    `INSERT INTO settings 
                     (id, setting_key, setting_value, setting_type, description)
                     VALUES ($1, $2, $3, $4, $5)
                     RETURNING *`,
                    [id, key, value, type, description]
                );
            }

            logger.info(`✓ Setting ${key} mis à jour`);
            return result.rows[0];
        } catch (error) {
            logger.error(`Erreur mise à jour setting: ${error.message}`);
            throw error;
        }
    }

    /**
     * Supprimer une paramètre
     * @param {string} key - Clé du paramètre
     * @returns {Promise<void>}
     */
    static async delete(key) {
        try {
            await pool.query(
                'DELETE FROM settings WHERE setting_key = $1',
                [key]
            );
            logger.info(`✓ Setting ${key} supprimé`);
        } catch (error) {
            logger.error(`Erreur suppression setting: ${error.message}`);
            throw error;
        }
    }

    /**
     * Initialiser les paramètres par défaut
     * @returns {Promise<void>}
     */
    static async initializeDefaults() {
        try {
            const defaults = [
                // === PARAMÈTRES GÉNÉRAUX ===
                { key: 'app_name', value: 'DEV SANZU HUB', type: 'string', description: 'Nom de l\'application' },
                { key: 'app_description', value: 'Plateforme de distribution de bots et méthodes', type: 'string', description: 'Description' },
                { key: 'app_version', value: '1.0.0', type: 'string', description: 'Version' },
                { key: 'app_url', value: process.env.APP_URL || 'http://localhost:3000', type: 'string', description: 'URL du site' },

                // === LOGO ET IMAGES ===
                { key: 'logo_url', value: '/assets/logo.png', type: 'string', description: 'URL du logo' },
                { key: 'favicon_url', value: '/assets/favicon.ico', type: 'string', description: 'Favicon' },
                { key: 'banner_url', value: '/assets/banner.jpg', type: 'string', description: 'Image bannière' },

                // === PARAMÈTRES DE PAIEMENT ===
                { key: 'payment_qr_code', value: process.env.PAYMENT_QR_CODE_IMAGE || '', type: 'string', description: 'URL du QR Code de paiement' },
                { key: 'payment_instruction', value: process.env.PAYMENT_INSTRUCTION_TEXT || 'Scannez ce code QR pour effectuer le paiement', type: 'string', description: 'Instructions de paiement' },
                { key: 'currency_symbol', value: '$', type: 'string', description: 'Symbole monétaire' },
                { key: 'default_currency', value: 'USD', type: 'string', description: 'Devise par défaut' },

                // === CONTACT ===
                { key: 'contact_email', value: 'contact@devsanzu.com', type: 'string', description: 'Email de contact' },
                { key: 'contact_phone', value: '+1234567890', type: 'string', description: 'Téléphone de contact' },
                { key: 'contact_address', value: '123 Main St, City, Country', type: 'string', description: 'Adresse' },

                // === RÉSEAUX SOCIAUX ===
                { key: 'social_telegram', value: 'https://t.me/devsanzu', type: 'string', description: 'Lien Telegram' },
                { key: 'social_whatsapp', value: 'https://wa.me/1234567890', type: 'string', description: 'Lien WhatsApp' },
                { key: 'social_twitter', value: 'https://twitter.com/devsanzu', type: 'string', description: 'Lien Twitter' },
                { key: 'social_instagram', value: 'https://instagram.com/devsanzu', type: 'string', description: 'Lien Instagram' },

                // === PARAMÈTRES DE SÉCURITÉ ===
                { key: 'enable_registration', value: 'true', type: 'boolean', description: 'Autoriser les inscriptions' },
                { key: 'enable_downloads', value: 'true', type: 'boolean', description: 'Autoriser les téléchargements' },
                { key: 'require_email_verification', value: 'false', type: 'boolean', description: 'Vérification email obligatoire' },
                { key: 'maintenance_mode', value: 'false', type: 'boolean', description: 'Mode maintenance' },

                // === TEXTES PERSONNALISABLES ===
                { key: 'home_title', value: 'Bienvenue sur DEV SANZU HUB', type: 'string', description: 'Titre page d\'accueil' },
                { key: 'home_subtitle', value: 'Découvrez nos bots et méthodes exclusives', type: 'string', description: 'Sous-titre page d\'accueil' },
                { key: 'footer_text', value: '© 2024 DEV SANZU. Tous droits réservés.', type: 'string', description: 'Texte footer' },

                // === LIMITES ET RESTRICTIONS ===
                { key: 'max_file_size', value: '50000000', type: 'string', description: 'Taille max fichier (bytes)' },
                { key: 'max_downloads_per_day', value: '10', type: 'string', description: 'Téléchargements max par jour' },
                { key: 'max_failed_logins', value: '5', type: 'string', description: 'Tentatives login max' },

                // === STATISTIQUES ===
                { key: 'show_download_stats', value: 'true', type: 'boolean', description: 'Afficher les stats' },
                { key: 'show_user_count', value: 'true', type: 'boolean', description: 'Afficher le nombre utilisateurs' },
            ];

            for (const setting of defaults) {
                const existing = await pool.query(
                    'SELECT id FROM settings WHERE setting_key = $1',
                    [setting.key]
                );

                if (existing.rows.length === 0) {
                    const id = uuidv4();
                    await pool.query(
                        `INSERT INTO settings (id, setting_key, setting_value, setting_type, description)
                         VALUES ($1, $2, $3, $4, $5)`,
                        [id, setting.key, setting.value, setting.type, setting.description]
                    );
                }
            }

            logger.info('✓ Paramètres par défaut initialisés');
        } catch (error) {
            logger.error(`Erreur initialisation settings: ${error.message}`);
            throw error;
        }
    }

    /**
     * Obtenir les paramètres sous forme d'objet clé-valeur
     * @returns {Promise<Object>} Objet de paramètres
     */
    static async toObject() {
        try {
            const settings = await this.getAll();
            const obj = {};

            for (const setting of settings) {
                let value = setting.setting_value;

                // Convertir les types
                if (setting.setting_type === 'boolean') {
                    value = value === 'true' || value === true;
                } else if (setting.setting_type === 'number') {
                    value = parseFloat(value);
                } else if (setting.setting_type === 'json') {
                    try {
                        value = JSON.parse(value);
                    } catch (e) {
                        // Garder comme string si JSON invalide
                    }
                }

                obj[setting.setting_key] = value;
            }

            return obj;
        } catch (error) {
            logger.error(`Erreur conversion settings: ${error.message}`);
            throw error;
        }
    }
}

module.exports = Settings;
