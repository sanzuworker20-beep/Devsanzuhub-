/**
 * ================================================
 * MODÈLE MÉTHODE
 * ================================================
 * Gestion des méthodes privées payantes
 */

const { pool } = require('../config/database');
const { v4: uuidv4 } = require('uuid');
const logger = require('../config/logger');

class Method {
    /**
     * Créer une nouvelle méthode
     * @param {Object} methodData - Données de la méthode
     * @returns {Promise<Object>} Méthode créée
     */
    static async create(methodData) {
        try {
            const { 
                title, description, version, price, currency, 
                imageUrl, content, contactInfo, contactEmail, contactPhone 
            } = methodData;
            const id = uuidv4();

            const result = await pool.query(
                `INSERT INTO methods 
                 (id, title, description, version, price, currency, image_url, content, contact_info, contact_email, contact_phone)
                 VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
                 RETURNING *`,
                [id, title, description, version, price, currency, imageUrl, content, contactInfo, contactEmail, contactPhone]
            );

            logger.info(`✓ Nouvelle méthode créée: ${title}`);
            return result.rows[0];
        } catch (error) {
            logger.error(`Erreur création méthode: ${error.message}`);
            throw error;
        }
    }

    /**
     * Obtenir une méthode par ID
     * @param {string} id - ID de la méthode
     * @returns {Promise<Object|null>} Méthode trouvée ou null
     */
    static async findById(id) {
        try {
            const result = await pool.query(
                'SELECT * FROM methods WHERE id = $1',
                [id]
            );
            return result.rows[0] || null;
        } catch (error) {
            logger.error(`Erreur recherche méthode: ${error.message}`);
            throw error;
        }
    }

    /**
     * Obtenir toutes les méthodes publiées
     * @param {number} limit - Limite
     * @param {number} offset - Décalage
     * @returns {Promise<Array>} Méthodes publiées
     */
    static async getPublished(limit = 20, offset = 0) {
        try {
            const result = await pool.query(
                `SELECT id, title, description, version, price, currency, image_url, view_count, purchase_count, created_at
                 FROM methods 
                 WHERE is_published = TRUE AND is_active = TRUE
                 ORDER BY created_at DESC
                 LIMIT $1 OFFSET $2`,
                [limit, offset]
            );
            return result.rows;
        } catch (error) {
            logger.error(`Erreur récupération méthodes: ${error.message}`);
            throw error;
        }
    }

    /**
     * Chercher des méthodes
     * @param {string} searchTerm - Terme de recherche
     * @param {number} limit - Limite
     * @param {number} offset - Décalage
     * @returns {Promise<Array>} Méthodes trouvées
     */
    static async search(searchTerm, limit = 20, offset = 0) {
        try {
            const result = await pool.query(
                `SELECT id, title, description, version, price, currency, image_url, view_count, purchase_count, created_at
                 FROM methods 
                 WHERE is_published = TRUE AND is_active = TRUE
                 AND (title ILIKE $1 OR description ILIKE $1)
                 ORDER BY created_at DESC
                 LIMIT $2 OFFSET $3`,
                [`%${searchTerm}%`, limit, offset]
            );
            return result.rows;
        } catch (error) {
            logger.error(`Erreur recherche méthode: ${error.message}`);
            throw error;
        }
    }

    /**
     * Obtenir les méthodes populaires
     * @param {number} limit - Limite
     * @returns {Promise<Array>} Méthodes populaires
     */
    static async getPopular(limit = 10) {
        try {
            const result = await pool.query(
                `SELECT id, title, description, version, price, currency, image_url, view_count, purchase_count, created_at
                 FROM methods 
                 WHERE is_published = TRUE AND is_active = TRUE
                 ORDER BY purchase_count DESC, view_count DESC
                 LIMIT $1`,
                [limit]
            );
            return result.rows;
        } catch (error) {
            logger.error(`Erreur méthodes populaires: ${error.message}`);
            throw error;
        }
    }

    /**
     * Obtenir les dernières méthodes
     * @param {number} limit - Limite
     * @returns {Promise<Array>} Dernières méthodes
     */
    static async getLatest(limit = 10) {
        try {
            const result = await pool.query(
                `SELECT id, title, description, version, price, currency, image_url, view_count, purchase_count, created_at
                 FROM methods 
                 WHERE is_published = TRUE AND is_active = TRUE
                 ORDER BY created_at DESC
                 LIMIT $1`,
                [limit]
            );
            return result.rows;
        } catch (error) {
            logger.error(`Erreur dernières méthodes: ${error.message}`);
            throw error;
        }
    }

    /**
     * Mettre à jour une méthode
     * @param {string} id - ID de la méthode
     * @param {Object} updateData - Données à mettre à jour
     * @returns {Promise<Object>} Méthode mise à jour
     */
    static async update(id, updateData) {
        try {
            const { 
                title, description, version, price, currency, 
                imageUrl, content, contactInfo, isPublished, isActive 
            } = updateData;

            const result = await pool.query(
                `UPDATE methods 
                 SET title = COALESCE($2, title),
                     description = COALESCE($3, description),
                     version = COALESCE($4, version),
                     price = COALESCE($5, price),
                     currency = COALESCE($6, currency),
                     image_url = COALESCE($7, image_url),
                     content = COALESCE($8, content),
                     contact_info = COALESCE($9, contact_info),
                     is_published = COALESCE($10, is_published),
                     is_active = COALESCE($11, is_active),
                     updated_at = CURRENT_TIMESTAMP
                 WHERE id = $1
                 RETURNING *`,
                [id, title, description, version, price, currency, imageUrl, content, contactInfo, isPublished, isActive]
            );

            if (result.rows.length === 0) {
                throw new Error('Méthode non trouvée');
            }

            logger.info(`✓ Méthode ${id} mise à jour`);
            return result.rows[0];
        } catch (error) {
            logger.error(`Erreur mise à jour méthode: ${error.message}`);
            throw error;
        }
    }

    /**
     * Incrémenter le compteur de vues
     * @param {string} id - ID de la méthode
     * @returns {Promise<void>}
     */
    static async incrementViewCount(id) {
        try {
            await pool.query(
                'UPDATE methods SET view_count = view_count + 1 WHERE id = $1',
                [id]
            );
        } catch (error) {
            logger.error(`Erreur incrément vues: ${error.message}`);
            throw error;
        }
    }

    /**
     * Incrémenter le compteur d'achats
     * @param {string} id - ID de la méthode
     * @returns {Promise<void>}
     */
    static async incrementPurchaseCount(id) {
        try {
            await pool.query(
                'UPDATE methods SET purchase_count = purchase_count + 1 WHERE id = $1',
                [id]
            );
        } catch (error) {
            logger.error(`Erreur incrément achats: ${error.message}`);
            throw error;
        }
    }

    /**
     * Supprimer une méthode
     * @param {string} id - ID de la méthode
     * @returns {Promise<void>}
     */
    static async delete(id) {
        try {
            await pool.query('DELETE FROM methods WHERE id = $1', [id]);
            logger.info(`✓ Méthode ${id} supprimée`);
        } catch (error) {
            logger.error(`Erreur suppression méthode: ${error.message}`);
            throw error;
        }
    }

    /**
     * Compter le nombre total de méthodes publiées
     * @returns {Promise<number>} Nombre de méthodes
     */
    static async countPublished() {
        try {
            const result = await pool.query(
                'SELECT COUNT(*) as count FROM methods WHERE is_published = TRUE AND is_active = TRUE'
            );
            return parseInt(result.rows[0].count);
        } catch (error) {
            logger.error(`Erreur compte méthodes: ${error.message}`);
            throw error;
        }
    }

    /**
     * Obtenir le contenu privé d'une méthode (après paiement)
     * @param {string} methodId - ID de la méthode
     * @returns {Promise<Object|null>} Contenu privé
     */
    static async getPrivateContent(methodId) {
        try {
            const result = await pool.query(
                `SELECT id, content, contact_info, contact_email, contact_phone 
                 FROM methods 
                 WHERE id = $1 AND is_published = TRUE`,
                [methodId]
            );
            return result.rows[0] || null;
        } catch (error) {
            logger.error(`Erreur récupération contenu privé: ${error.message}`);
            throw error;
        }
    }

    /**
     * Obtenir les statistiques des méthodes
     * @returns {Promise<Object>} Statistiques
     */
    static async getStatistics() {
        try {
            const result = await pool.query(`
                SELECT 
                    COUNT(*) as total_methods,
                    SUM(purchase_count) as total_purchases,
                    AVG(price) as average_price,
                    SUM(view_count) as total_views
                FROM methods 
                WHERE is_published = TRUE AND is_active = TRUE
            `);
            return result.rows[0];
        } catch (error) {
            logger.error(`Erreur statistiques: ${error.message}`);
            throw error;
        }
    }
}

module.exports = Method;
