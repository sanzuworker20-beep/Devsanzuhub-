/**
 * ================================================
 * MODÈLE PROJET
 * ================================================
 * Gestion des projets et bots
 */

const { pool } = require('../config/database');
const { v4: uuidv4 } = require('uuid');
const logger = require('../config/logger');

class Project {
    /**
     * Créer un nouveau projet
     * @param {Object} projectData - Données du projet
     * @returns {Promise<Object>} Projet créé
     */
    static async create(projectData) {
        try {
            const { title, description, category, version, authorId, imageUrl } = projectData;
            const id = uuidv4();

            const result = await pool.query(
                `INSERT INTO projects (id, title, description, category, version, author_id, image_url)
                 VALUES ($1, $2, $3, $4, $5, $6, $7)
                 RETURNING *`,
                [id, title, description, category, version, authorId, imageUrl]
            );

            logger.info(`✓ Nouveau projet créé: ${title}`);
            return result.rows[0];
        } catch (error) {
            logger.error(`Erreur création projet: ${error.message}`);
            throw error;
        }
    }

    /**
     * Obtenir un projet par ID
     * @param {string} id - ID du projet
     * @returns {Promise<Object|null>} Projet trouvé ou null
     */
    static async findById(id) {
        try {
            const result = await pool.query(
                `SELECT p.*, u.username as author_name 
                 FROM projects p 
                 LEFT JOIN users u ON p.author_id = u.id
                 WHERE p.id = $1`,
                [id]
            );
            return result.rows[0] || null;
        } catch (error) {
            logger.error(`Erreur recherche projet: ${error.message}`);
            throw error;
        }
    }

    /**
     * Obtenir tous les projets publiés
     * @param {number} limit - Limite de résultats
     * @param {number} offset - Décalage
     * @returns {Promise<Array>} Liste des projets
     */
    static async getPublished(limit = 20, offset = 0) {
        try {
            const result = await pool.query(
                `SELECT p.*, u.username as author_name 
                 FROM projects p 
                 LEFT JOIN users u ON p.author_id = u.id
                 WHERE p.is_published = TRUE
                 ORDER BY p.created_at DESC
                 LIMIT $1 OFFSET $2`,
                [limit, offset]
            );
            return result.rows;
        } catch (error) {
            logger.error(`Erreur récupération projets: ${error.message}`);
            throw error;
        }
    }

    /**
     * Obtenir les projets par catégorie
     * @param {string} category - Catégorie
     * @param {number} limit - Limite
     * @param {number} offset - Décalage
     * @returns {Promise<Array>} Projets de la catégorie
     */
    static async getByCategory(category, limit = 20, offset = 0) {
        try {
            const result = await pool.query(
                `SELECT p.*, u.username as author_name 
                 FROM projects p 
                 LEFT JOIN users u ON p.author_id = u.id
                 WHERE p.is_published = TRUE AND p.category = $1
                 ORDER BY p.created_at DESC
                 LIMIT $2 OFFSET $3`,
                [category, limit, offset]
            );
            return result.rows;
        } catch (error) {
            logger.error(`Erreur recherche par catégorie: ${error.message}`);
            throw error;
        }
    }

    /**
     * Chercher des projets
     * @param {string} searchTerm - Terme de recherche
     * @param {number} limit - Limite
     * @param {number} offset - Décalage
     * @returns {Promise<Array>} Projets trouvés
     */
    static async search(searchTerm, limit = 20, offset = 0) {
        try {
            const result = await pool.query(
                `SELECT p.*, u.username as author_name 
                 FROM projects p 
                 LEFT JOIN users u ON p.author_id = u.id
                 WHERE p.is_published = TRUE 
                 AND (p.title ILIKE $1 OR p.description ILIKE $1)
                 ORDER BY p.created_at DESC
                 LIMIT $2 OFFSET $3`,
                [`%${searchTerm}%`, limit, offset]
            );
            return result.rows;
        } catch (error) {
            logger.error(`Erreur recherche projet: ${error.message}`);
            throw error;
        }
    }

    /**
     * Mettre à jour un projet
     * @param {string} id - ID du projet
     * @param {Object} updateData - Données à mettre à jour
     * @returns {Promise<Object>} Projet mis à jour
     */
    static async update(id, updateData) {
        try {
            const { title, description, category, version, imageUrl, isPublished } = updateData;

            const result = await pool.query(
                `UPDATE projects 
                 SET title = COALESCE($2, title),
                     description = COALESCE($3, description),
                     category = COALESCE($4, category),
                     version = COALESCE($5, version),
                     image_url = COALESCE($6, image_url),
                     is_published = COALESCE($7, is_published),
                     updated_at = CURRENT_TIMESTAMP
                 WHERE id = $1
                 RETURNING *`,
                [id, title, description, category, version, imageUrl, isPublished]
            );

            if (result.rows.length === 0) {
                throw new Error('Projet non trouvé');
            }

            logger.info(`✓ Projet ${id} mis à jour`);
            return result.rows[0];
        } catch (error) {
            logger.error(`Erreur mise à jour projet: ${error.message}`);
            throw error;
        }
    }

    /**
     * Incrémenter le compteur de téléchargements
     * @param {string} id - ID du projet
     * @returns {Promise<void>}
     */
    static async incrementDownloadCount(id) {
        try {
            await pool.query(
                'UPDATE projects SET download_count = download_count + 1 WHERE id = $1',
                [id]
            );
        } catch (error) {
            logger.error(`Erreur incrément téléchargements: ${error.message}`);
            throw error;
        }
    }

    /**
     * Incrémenter le compteur de vues
     * @param {string} id - ID du projet
     * @returns {Promise<void>}
     */
    static async incrementViewCount(id) {
        try {
            await pool.query(
                'UPDATE projects SET view_count = view_count + 1 WHERE id = $1',
                [id]
            );
        } catch (error) {
            logger.error(`Erreur incrément vues: ${error.message}`);
            throw error;
        }
    }

    /**
     * Obtenir les projets populaires
     * @param {number} limit - Limite
     * @returns {Promise<Array>} Projets populaires
     */
    static async getPopular(limit = 10) {
        try {
            const result = await pool.query(
                `SELECT p.*, u.username as author_name 
                 FROM projects p 
                 LEFT JOIN users u ON p.author_id = u.id
                 WHERE p.is_published = TRUE
                 ORDER BY p.download_count DESC, p.view_count DESC
                 LIMIT $1`,
                [limit]
            );
            return result.rows;
        } catch (error) {
            logger.error(`Erreur projets populaires: ${error.message}`);
            throw error;
        }
    }

    /**
     * Obtenir les derniers projets
     * @param {number} limit - Limite
     * @returns {Promise<Array>} Derniers projets
     */
    static async getLatest(limit = 10) {
        try {
            const result = await pool.query(
                `SELECT p.*, u.username as author_name 
                 FROM projects p 
                 LEFT JOIN users u ON p.author_id = u.id
                 WHERE p.is_published = TRUE
                 ORDER BY p.created_at DESC
                 LIMIT $1`,
                [limit]
            );
            return result.rows;
        } catch (error) {
            logger.error(`Erreur derniers projets: ${error.message}`);
            throw error;
        }
    }

    /**
     * Supprimer un projet
     * @param {string} id - ID du projet
     * @returns {Promise<void>}
     */
    static async delete(id) {
        try {
            await pool.query('DELETE FROM projects WHERE id = $1', [id]);
            logger.info(`✓ Projet ${id} supprimé`);
        } catch (error) {
            logger.error(`Erreur suppression projet: ${error.message}`);
            throw error;
        }
    }

    /**
     * Compter les projets publiés
     * @returns {Promise<number>} Nombre de projets
     */
    static async countPublished() {
        try {
            const result = await pool.query(
                'SELECT COUNT(*) as count FROM projects WHERE is_published = TRUE'
            );
            return parseInt(result.rows[0].count);
        } catch (error) {
            logger.error(`Erreur compte projets: ${error.message}`);
            throw error;
        }
    }

    /**
     * Obtenir les projets par auteur
     * @param {string} authorId - ID de l'auteur
     * @param {number} limit - Limite
     * @param {number} offset - Décalage
     * @returns {Promise<Array>} Projets de l'auteur
     */
    static async getByAuthor(authorId, limit = 20, offset = 0) {
        try {
            const result = await pool.query(
                `SELECT * FROM projects 
                 WHERE author_id = $1
                 ORDER BY created_at DESC
                 LIMIT $2 OFFSET $3`,
                [authorId, limit, offset]
            );
            return result.rows;
        } catch (error) {
            logger.error(`Erreur projets par auteur: ${error.message}`);
            throw error;
        }
    }
}

module.exports = Project;
