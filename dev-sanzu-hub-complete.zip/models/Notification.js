/**
 * ================================================
 * MODÈLE NOTIFICATION
 * ================================================
 * Gestion des notifications utilisateur
 */

const { pool } = require('../config/database');
const { v4: uuidv4 } = require('uuid');
const logger = require('../config/logger');

class Notification {
    /**
     * Créer une nouvelle notification
     * @param {Object} notificationData - Données de la notification
     * @returns {Promise<Object>} Notification créée
     */
    static async create(notificationData) {
        try {
            const { userId, type, title, message, relatedId } = notificationData;
            const id = uuidv4();

            const result = await pool.query(
                `INSERT INTO notifications 
                 (id, user_id, type, title, message, related_id)
                 VALUES ($1, $2, $3, $4, $5, $6)
                 RETURNING *`,
                [id, userId, type, title, message, relatedId]
            );

            logger.info(`✓ Notification créée pour utilisateur ${userId}`);
            return result.rows[0];
        } catch (error) {
            logger.error(`Erreur création notification: ${error.message}`);
            throw error;
        }
    }

    /**
     * Obtenir une notification par ID
     * @param {string} id - ID de la notification
     * @returns {Promise<Object|null>} Notification trouvée ou null
     */
    static async findById(id) {
        try {
            const result = await pool.query(
                'SELECT * FROM notifications WHERE id = $1',
                [id]
            );
            return result.rows[0] || null;
        } catch (error) {
            logger.error(`Erreur recherche notification: ${error.message}`);
            throw error;
        }
    }

    /**
     * Obtenir les notifications d'un utilisateur
     * @param {string} userId - ID de l'utilisateur
     * @param {number} limit - Limite
     * @param {number} offset - Décalage
     * @returns {Promise<Array>} Notifications de l'utilisateur
     */
    static async getByUser(userId, limit = 50, offset = 0) {
        try {
            const result = await pool.query(
                `SELECT * FROM notifications 
                 WHERE user_id = $1
                 ORDER BY created_at DESC
                 LIMIT $2 OFFSET $3`,
                [userId, limit, offset]
            );
            return result.rows;
        } catch (error) {
            logger.error(`Erreur notifications utilisateur: ${error.message}`);
            throw error;
        }
    }

    /**
     * Obtenir les notifications non lues d'un utilisateur
     * @param {string} userId - ID de l'utilisateur
     * @returns {Promise<Array>} Notifications non lues
     */
    static async getUnread(userId) {
        try {
            const result = await pool.query(
                `SELECT * FROM notifications 
                 WHERE user_id = $1 AND is_read = FALSE
                 ORDER BY created_at DESC`,
                [userId]
            );
            return result.rows;
        } catch (error) {
            logger.error(`Erreur notifications non lues: ${error.message}`);
            throw error;
        }
    }

    /**
     * Marquer une notification comme lue
     * @param {string} id - ID de la notification
     * @returns {Promise<Object>} Notification mise à jour
     */
    static async markAsRead(id) {
        try {
            const result = await pool.query(
                `UPDATE notifications 
                 SET is_read = TRUE, read_at = CURRENT_TIMESTAMP
                 WHERE id = $1
                 RETURNING *`,
                [id]
            );

            if (result.rows.length === 0) {
                throw new Error('Notification non trouvée');
            }

            return result.rows[0];
        } catch (error) {
            logger.error(`Erreur marquage notification: ${error.message}`);
            throw error;
        }
    }

    /**
     * Marquer toutes les notifications comme lues pour un utilisateur
     * @param {string} userId - ID de l'utilisateur
     * @returns {Promise<void>}
     */
    static async markAllAsRead(userId) {
        try {
            await pool.query(
                `UPDATE notifications 
                 SET is_read = TRUE, read_at = CURRENT_TIMESTAMP
                 WHERE user_id = $1 AND is_read = FALSE`,
                [userId]
            );

            logger.info(`✓ Toutes notifications marquées comme lues pour ${userId}`);
        } catch (error) {
            logger.error(`Erreur marquage all: ${error.message}`);
            throw error;
        }
    }

    /**
     * Supprimer une notification
     * @param {string} id - ID de la notification
     * @returns {Promise<void>}
     */
    static async delete(id) {
        try {
            await pool.query(
                'DELETE FROM notifications WHERE id = $1',
                [id]
            );
            logger.info(`✓ Notification ${id} supprimée`);
        } catch (error) {
            logger.error(`Erreur suppression notification: ${error.message}`);
            throw error;
        }
    }

    /**
     * Supprimer les notifications lues d'un utilisateur
     * @param {string} userId - ID de l'utilisateur
     * @returns {Promise<void>}
     */
    static async deleteReadNotifications(userId) {
        try {
            await pool.query(
                'DELETE FROM notifications WHERE user_id = $1 AND is_read = TRUE',
                [userId]
            );
            logger.info(`✓ Notifications lues supprimées pour ${userId}`);
        } catch (error) {
            logger.error(`Erreur suppression notifications: ${error.message}`);
            throw error;
        }
    }

    /**
     * Compter les notifications non lues
     * @param {string} userId - ID de l'utilisateur
     * @returns {Promise<number>} Nombre de notifications non lues
     */
    static async countUnread(userId) {
        try {
            const result = await pool.query(
                'SELECT COUNT(*) as count FROM notifications WHERE user_id = $1 AND is_read = FALSE',
                [userId]
            );
            return parseInt(result.rows[0].count);
        } catch (error) {
            logger.error(`Erreur compte notifications: ${error.message}`);
            throw error;
        }
    }

    /**
     * Envoyer une notification à plusieurs utilisateurs
     * @param {Array} userIds - Liste des IDs utilisateurs
     * @param {string} type - Type de notification
     * @param {string} title - Titre
     * @param {string} message - Message
     * @returns {Promise<Array>} Notifications créées
     */
    static async sendBulk(userIds, type, title, message) {
        try {
            const notifications = [];
            
            for (const userId of userIds) {
                const notif = await this.create({
                    userId,
                    type,
                    title,
                    message,
                    relatedId: null
                });
                notifications.push(notif);
            }

            logger.info(`✓ Notification en masse envoyée à ${userIds.length} utilisateurs`);
            return notifications;
        } catch (error) {
            logger.error(`Erreur envoi notification masse: ${error.message}`);
            throw error;
        }
    }

    /**
     * Créer une notification système
     * @param {string} title - Titre
     * @param {string} message - Message
     * @returns {Promise<Array>} Notifications créées
     */
    static async createSystemNotification(title, message) {
        try {
            // Obtenir tous les utilisateurs
            const usersResult = await pool.query('SELECT id FROM users');
            const userIds = usersResult.rows.map(row => row.id);

            // Envoyer notification à tous
            return await this.sendBulk(userIds, 'system', title, message);
        } catch (error) {
            logger.error(`Erreur notification système: ${error.message}`);
            throw error;
        }
    }

    /**
     * Obtenir les statistiques de notifications
     * @returns {Promise<Object>} Statistiques
     */
    static async getStatistics() {
        try {
            const result = await pool.query(`
                SELECT 
                    COUNT(*) as total_notifications,
                    SUM(CASE WHEN is_read = FALSE THEN 1 ELSE 0 END) as unread_notifications,
                    COUNT(DISTINCT user_id) as users_with_notifications
                FROM notifications
            `);
            return result.rows[0];
        } catch (error) {
            logger.error(`Erreur statistiques: ${error.message}`);
            throw error;
        }
    }
}

module.exports = Notification;
