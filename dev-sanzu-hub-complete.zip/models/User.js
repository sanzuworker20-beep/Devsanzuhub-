/**
 * ================================================
 * MODÈLE UTILISATEUR
 * ================================================
 * Gestion des utilisateurs et authentification
 */

const { pool } = require('../config/database');
const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');
const logger = require('../config/logger');

class User {
    /**
     * Créer un nouvel utilisateur
     * @param {Object} userData - Données utilisateur
     * @returns {Promise<Object>} Utilisateur créé
     */
    static async create(userData) {
        try {
            const { username, email, password, fullName } = userData;
            const id = uuidv4();
            const hashedPassword = await bcrypt.hash(password, parseInt(process.env.BCRYPT_ROUNDS) || 10);
            const verificationToken = uuidv4();

            const result = await pool.query(
                `INSERT INTO users (id, username, email, password_hash, full_name, verification_token)
                 VALUES ($1, $2, $3, $4, $5, $6)
                 RETURNING id, username, email, full_name, is_admin, created_at`,
                [id, username, email, hashedPassword, fullName, verificationToken]
            );

            logger.info(`✓ Nouvel utilisateur créé: ${username}`);
            return result.rows[0];
        } catch (error) {
            logger.error(`Erreur création utilisateur: ${error.message}`);
            throw error;
        }
    }

    /**
     * Chercher un utilisateur par email
     * @param {string} email - Email de l'utilisateur
     * @returns {Promise<Object|null>} Utilisateur trouvé ou null
     */
    static async findByEmail(email) {
        try {
            const result = await pool.query(
                'SELECT * FROM users WHERE email = $1',
                [email]
            );
            return result.rows[0] || null;
        } catch (error) {
            logger.error(`Erreur recherche utilisateur: ${error.message}`);
            throw error;
        }
    }

    /**
     * Chercher un utilisateur par ID
     * @param {string} id - ID de l'utilisateur
     * @returns {Promise<Object|null>} Utilisateur trouvé ou null
     */
    static async findById(id) {
        try {
            const result = await pool.query(
                'SELECT id, username, email, full_name, bio, avatar_url, is_admin, is_banned, created_at FROM users WHERE id = $1',
                [id]
            );
            return result.rows[0] || null;
        } catch (error) {
            logger.error(`Erreur recherche utilisateur par ID: ${error.message}`);
            throw error;
        }
    }

    /**
     * Chercher un utilisateur par nom d'utilisateur
     * @param {string} username - Nom d'utilisateur
     * @returns {Promise<Object|null>} Utilisateur trouvé ou null
     */
    static async findByUsername(username) {
        try {
            const result = await pool.query(
                'SELECT * FROM users WHERE username = $1',
                [username]
            );
            return result.rows[0] || null;
        } catch (error) {
            logger.error(`Erreur recherche utilisateur par username: ${error.message}`);
            throw error;
        }
    }

    /**
     * Vérifier le mot de passe
     * @param {string} password - Mot de passe en clair
     * @param {string} passwordHash - Hash du mot de passe
     * @returns {Promise<boolean>} Vrai si le mot de passe est correct
     */
    static async verifyPassword(password, passwordHash) {
        try {
            return await bcrypt.compare(password, passwordHash);
        } catch (error) {
            logger.error(`Erreur vérification mot de passe: ${error.message}`);
            throw error;
        }
    }

    /**
     * Mettre à jour les informations de l'utilisateur
     * @param {string} id - ID de l'utilisateur
     * @param {Object} updateData - Données à mettre à jour
     * @returns {Promise<Object>} Utilisateur mis à jour
     */
    static async update(id, updateData) {
        try {
            const { fullName, bio, avatarUrl, phoneNumber, contactInfo } = updateData;
            
            const result = await pool.query(
                `UPDATE users 
                 SET full_name = COALESCE($2, full_name),
                     bio = COALESCE($3, bio),
                     avatar_url = COALESCE($4, avatar_url),
                     phone_number = COALESCE($5, phone_number),
                     contact_info = COALESCE($6, contact_info),
                     updated_at = CURRENT_TIMESTAMP
                 WHERE id = $1
                 RETURNING id, username, email, full_name, bio, avatar_url, is_admin`,
                [id, fullName, bio, avatarUrl, phoneNumber, contactInfo]
            );

            if (result.rows.length === 0) {
                throw new Error('Utilisateur non trouvé');
            }

            logger.info(`✓ Utilisateur ${id} mis à jour`);
            return result.rows[0];
        } catch (error) {
            logger.error(`Erreur mise à jour utilisateur: ${error.message}`);
            throw error;
        }
    }

    /**
     * Vérifier l'email d'un utilisateur
     * @param {string} id - ID de l'utilisateur
     * @returns {Promise<void>}
     */
    static async verifyEmail(id) {
        try {
            await pool.query(
                `UPDATE users 
                 SET email_verified = TRUE, 
                     verification_token = NULL,
                     updated_at = CURRENT_TIMESTAMP
                 WHERE id = $1`,
                [id]
            );

            logger.info(`✓ Email vérifié pour l'utilisateur ${id}`);
        } catch (error) {
            logger.error(`Erreur vérification email: ${error.message}`);
            throw error;
        }
    }

    /**
     * Obtenir tous les utilisateurs (pour admin)
     * @param {number} limit - Nombre de résultats
     * @param {number} offset - Décalage
     * @returns {Promise<Array>} Liste des utilisateurs
     */
    static async getAll(limit = 50, offset = 0) {
        try {
            const result = await pool.query(
                `SELECT id, username, email, full_name, is_admin, is_banned, created_at 
                 FROM users 
                 ORDER BY created_at DESC
                 LIMIT $1 OFFSET $2`,
                [limit, offset]
            );
            return result.rows;
        } catch (error) {
            logger.error(`Erreur récupération utilisateurs: ${error.message}`);
            throw error;
        }
    }

    /**
     * Bannir un utilisateur
     * @param {string} id - ID de l'utilisateur
     * @returns {Promise<void>}
     */
    static async ban(id) {
        try {
            await pool.query(
                'UPDATE users SET is_banned = TRUE, updated_at = CURRENT_TIMESTAMP WHERE id = $1',
                [id]
            );
            logger.info(`✓ Utilisateur ${id} banni`);
        } catch (error) {
            logger.error(`Erreur bannissement utilisateur: ${error.message}`);
            throw error;
        }
    }

    /**
     * Débannir un utilisateur
     * @param {string} id - ID de l'utilisateur
     * @returns {Promise<void>}
     */
    static async unban(id) {
        try {
            await pool.query(
                'UPDATE users SET is_banned = FALSE, updated_at = CURRENT_TIMESTAMP WHERE id = $1',
                [id]
            );
            logger.info(`✓ Utilisateur ${id} débanni`);
        } catch (error) {
            logger.error(`Erreur débannissement utilisateur: ${error.message}`);
            throw error;
        }
    }

    /**
     * Rendre administrateur
     * @param {string} id - ID de l'utilisateur
     * @returns {Promise<void>}
     */
    static async makeAdmin(id) {
        try {
            await pool.query(
                'UPDATE users SET is_admin = TRUE, updated_at = CURRENT_TIMESTAMP WHERE id = $1',
                [id]
            );
            logger.info(`✓ Utilisateur ${id} promu administrateur`);
        } catch (error) {
            logger.error(`Erreur promotion admin: ${error.message}`);
            throw error;
        }
    }

    /**
     * Débloquer les coordonnées de contact
     * @param {string} userId - ID de l'utilisateur
     * @returns {Promise<void>}
     */
    static async unlockContactInfo(userId) {
        try {
            await pool.query(
                `UPDATE users 
                 SET is_contact_locked = FALSE, 
                     unlocked_at = CURRENT_TIMESTAMP,
                     updated_at = CURRENT_TIMESTAMP
                 WHERE id = $1`,
                [userId]
            );
            logger.info(`✓ Coordonnées débloquées pour ${userId}`);
        } catch (error) {
            logger.error(`Erreur déblocage coordonnées: ${error.message}`);
            throw error;
        }
    }

    /**
     * Compter le nombre total d'utilisateurs
     * @returns {Promise<number>} Nombre total d'utilisateurs
     */
    static async count() {
        try {
            const result = await pool.query('SELECT COUNT(*) as count FROM users');
            return parseInt(result.rows[0].count);
        } catch (error) {
            logger.error(`Erreur compte utilisateurs: ${error.message}`);
            throw error;
        }
    }

    /**
     * Supprimer un utilisateur
     * @param {string} id - ID de l'utilisateur
     * @returns {Promise<void>}
     */
    static async delete(id) {
        try {
            await pool.query('DELETE FROM users WHERE id = $1', [id]);
            logger.info(`✓ Utilisateur ${id} supprimé`);
        } catch (error) {
            logger.error(`Erreur suppression utilisateur: ${error.message}`);
            throw error;
        }
    }
}

module.exports = User;
