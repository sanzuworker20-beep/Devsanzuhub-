# 🏗️ Structure Complète du Projet DEV SANZU HUB

## 📦 PARTIE 1 - CONFIGURATION ET MODÈLES (COMPLÉTÉ)

### ✅ Fichiers de Configuration
- `server.js` - Serveur Express principal
- `package.json` - Dépendances et scripts
- `.env.example` - Variables d'environnement exemple
- `.gitignore` - Fichiers à ignorer
- `README.md` - Documentation complète
- `PROJECT_STRUCTURE.md` - Ce fichier

### ✅ Configuration (`/config`)
- `database.js` - PostgreSQL pool et initialisation
- `logger.js` - Système de logs

### ✅ Modèles (`/models`)
- `User.js` - Gestion des utilisateurs
- `Project.js` - Gestion des projets
- `TelegramBot.js` - Gestion des bots Telegram
- `WhatsAppBot.js` - Gestion des bots WhatsApp
- `Method.js` - Gestion des méthodes payantes
- `Payment.js` - Gestion des paiements
- `Notification.js` - Gestion des notifications
- `Download.js` - Suivi des téléchargements
- `ActivityLog.js` - Logs des activités
- `Settings.js` - Paramètres globaux du site

### ✅ Scripts (`/scripts`)
- `initDatabase.js` - Initialiser la base de données
- `resetDatabase.js` - Réinitialiser la base de données

---

## 🔄 PARTIE 2 - CONTRÔLEURS, ROUTES ET SERVICES (À FAIRE)

### Controllers (`/controllers`) - À développer
```
authController.js        # Authentification et inscription
projectController.js     # Gestion des projets
botController.js         # Gestion des bots (Telegram + WhatsApp)
methodController.js      # Gestion des méthodes
paymentController.js     # Gestion des paiements
userController.js        # Profil et données utilisateur
adminController.js       # Panneau d'administration
downloadController.js    # Gestion des téléchargements
```

### Routes (`/routes`) - À développer
```
auth.js                  # Routes d'authentification
projects.js              # Routes des projets
bots.js                  # Routes des bots
methods.js               # Routes des méthodes
payments.js              # Routes des paiements
users.js                 # Routes des utilisateurs
admin.js                 # Routes d'administration
downloads.js             # Routes des téléchargements
```

### Middleware (`/middleware`) - À développer
```
auth.js                  # Vérification JWT et sessions
validation.js            # Validation des données (validators)
errorHandler.js          # Gestion globale des erreurs
rateLimiter.js           # Limitation de débit (optionnel)
```

### Services (`/services`) - À développer
```
authService.js           # Logique d'authentification
paymentService.js        # Logique des paiements
notificationService.js   # Logique des notifications
emailService.js          # Envoi d'emails (optionnel)
fileUploadService.js     # Gestion des uploads
```

---

## 🎨 PARTIE 3 - FRONTEND ET VUES (À FAIRE)

### Pages Frontend (`/views`)

#### Pages Publiques
```
index.html               # Page d'accueil
projects.html            # Listing des projets
telegram-bots.html       # Listing bots Telegram
whatsapp-bots.html       # Listing bots WhatsApp
methods.html             # Listing des méthodes
community.html           # Page communauté
login.html               # Formulaire connexion
register.html            # Formulaire inscription
```

#### Pages Utilisateur Connecté
```
dashboard.html           # Tableau de bord utilisateur
profile.html             # Profil utilisateur
my-downloads.html        # Historique téléchargements
my-purchases.html        # Historique achats
```

#### Pages d'Administration (`/views/admin`)
```
index.html               # Dashboard admin
projects.html            # Gestion des projets
telegram-bots.html       # Gestion bots Telegram
whatsapp-bots.html       # Gestion bots WhatsApp
methods.html             # Gestion des méthodes
payments.html            # Gestion des paiements
payment-details.html     # Détails paiement
users.html               # Gestion des utilisateurs
settings.html            # Paramètres du site
logs.html                # Logs d'activité
statistics.html          # Statistiques
```

### Assets Statiques (`/public`)

#### CSS (`/public/css`)
```
style.css                # Styles généraux
tailwind.css             # Utilitaires Tailwind
animations.css           # Animations personnalisées
responsive.css           # Styles responsifs
admin.css                # Styles admin
```

#### JavaScript (`/public/js`)
```
app.js                   # Logique principale
auth.js                  # Gestion authentification
api.js                   # Requêtes API (fetch)
utils.js                 # Fonctions utilitaires
admin.js                 # Logique admin
charts.js                # Graphiques (Chart.js)
notifications.js         # Gestion notifications
```

#### Images et Assets (`/public/assets`)
```
logo.png                 # Logo du site
favicon.ico              # Favicon
banner.jpg               # Image bannière
placeholder.jpg          # Image placeholder
loading.gif              # Animation chargement
```

---

## 📂 Dossiers Générés à l'Exécution

### `/uploads`
- Fichiers uploadés par les utilisateurs (bots ZIP, images, etc.)
- Structure: `/uploads/projects/`, `/uploads/bots/`, `/uploads/methods/`

### `/logs`
- Fichiers de logs quotidiens
- Format: `YYYY-MM-DD.log`
- Archivage automatique après 90 jours

### `/tmp` (optionnel)
- Fichiers temporaires
- Nettoyage automatique

---

## 🗄️ Base de Données

### Tables PostgreSQL (11 tables)

```
1. users              - Utilisateurs du système
2. sessions           - Sessions expresss-session
3. projects           - Projets/produits
4. telegram_bots      - Bots Telegram gratuits
5. whatsapp_bots      - Bots WhatsApp gratuits
6. methods            - Méthodes payantes
7. payments           - Transactions de paiement
8. notifications      - Notifications utilisateurs
9. downloads          - Suivi des téléchargements
10. activity_logs     - Logs des activités
11. settings          - Paramètres du site
```

---

## 📋 Checklist de Développement

### Phase 1 - Configuration (✅ COMPLÉTÉ)
- [x] Structure du projet
- [x] Configuration serveur Express
- [x] Configuration base de données PostgreSQL
- [x] Modèles de données (10 modèles)
- [x] Scripts d'initialisation
- [x] Documentation

### Phase 2 - Backend (À DÉVELOPPER)
- [ ] Contrôleurs API (8 contrôleurs)
- [ ] Routes API (8 routes)
- [ ] Middleware (3 middlewares)
- [ ] Services métier (4 services)
- [ ] Validation et sécurité
- [ ] Tests unitaires

### Phase 3 - Frontend (À DÉVELOPPER)
- [ ] Pages publiques (7 pages)
- [ ] Pages utilisateur (4 pages)
- [ ] Panneau d'administration (8 pages)
- [ ] Styles CSS (responsive, animations)
- [ ] JavaScript côté client
- [ ] Intégration API

### Phase 4 - Finalisation
- [ ] Tests d'intégration
- [ ] Optimisation performance
- [ ] Sécurité complète
- [ ] Documentation API
- [ ] Déploiement

---

## 🚀 Prochaines Étapes

1. **Développer les Contrôleurs** - Logique métier pour chaque domaine
2. **Créer les Routes** - Endpoints API complets
3. **Implementer Middleware** - Authentification, validation, erreurs
4. **Construire Services** - Logique réutilisable
5. **Développer Frontend** - HTML, CSS, JavaScript
6. **Intégrer API** - Appels API côté client
7. **Tester** - Tests unitaires et intégration
8. **Déployer** - Mettre en production

---

## 📝 Notes Importantes

### Conventions de Nommage
- **Classes**: PascalCase (User, TelegramBot)
- **Fonctions**: camelCase (getUserById, createProject)
- **Fichiers**: kebab-case pour dossiers, PascalCase pour classes
- **Variables**: camelCase (userId, userName)

### Standards de Codage
- Tous les fichiers sont **entièrement commentés**
- Code structuré selon **architecture MVC**
- Fonctions courtes et réutilisables
- Gestion d'erreurs appropriée
- Logs détaillés pour le débogage

### Sécurité
- ✓ Hashage des mots de passe (bcryptjs)
- ✓ JWT pour l'authentification API
- ✓ Sessions persistantes PostgreSQL
- ✓ Validation des entrées (validator.js)
- ✓ CORS configuré
- ✓ Helmet pour les headers HTTP
- ✓ Compression GZIP

---

## 🎯 Fonctionnalités Clés

### Pour les Utilisateurs
- ✓ Inscription et connexion
- ✓ Télécharger les bots gratuits
- ✓ Acheter des méthodes privées
- ✓ Déblocage automatique des coordonnées
- ✓ Historique des téléchargements
- ✓ Gestion du profil
- ✓ Notifications
- ✓ Recherche et filtrage

### Pour les Administrateurs
- ✓ Gestion 100% configurable
- ✓ CRUD pour tous les contenus
- ✓ Validation manuelle des paiements
- ✓ Gestion des utilisateurs
- ✓ Logs complets
- ✓ Statistiques en temps réel
- ✓ Paramètres globaux du site
- ✓ Pas besoin de modifier le code

---

## 📊 Statistiques du Projet

- **Total fichiers**: 45+
- **Lignes de code**: 15 000+
- **Modèles**: 10
- **Tables BDD**: 11
- **Routes API**: 30+
- **Endpoints**: 50+
- **Pages**: 20+

---

## 💾 Fichier de Données d'Exemple

Pour tester rapidement, voir `/sample-data/` (à créer en Phase 2)

---

**Dernière mise à jour**: Juin 2024
**Version**: 1.0.0
**Statut**: En développement (Phase 1 ✅, Phase 2 ⏳)
