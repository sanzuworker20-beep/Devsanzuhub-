/**
 * ================================================
 * DEV SANZU HUB - SERVEUR PRINCIPAL
 * ================================================
 * Serveur Express pour la plateforme DEV SANZU HUB
 * Gestion complète de la distribution de bots et méthodes
 * 
 * Architecture: MVC
 * Base de données: PostgreSQL
 * Framework: Express.js
 */

// Imports des dépendances principales
require('dotenv').config(); // Charger les variables d'environnement
const express = require('express');
const path = require('path');
const cors = require('cors');
const helmet = require('helmet');
const compression = require('compression');
const bodyParser = require('body-parser');
const session = require('express-session');
const pgSession = require('connect-pg-simple')(session);

// Imports des configurations
const { pool, checkDatabaseConnection } = require('./config/database');
const logger = require('./config/logger');

// Imports des routes
const authRoutes = require('./routes/auth');
const projectRoutes = require('./routes/projects');
const botRoutes = require('./routes/bots');
const methodRoutes = require('./routes/methods');
const paymentRoutes = require('./routes/payments');
const userRoutes = require('./routes/users');
const adminRoutes = require('./routes/admin');
const downloadRoutes = require('./routes/downloads');

// Initialiser l'application Express
const app = express();

// ============================================
// CONFIGURATION GLOBALE
// ============================================

// Port d'écoute
const PORT = process.env.PORT || 3000;
const HOST = process.env.HOST || 'localhost';

// ============================================
// MIDDLEWARE DE SÉCURITÉ ET DE BASE
// ============================================

// Helmet - Sécurisation des en-têtes HTTP
app.use(helmet());

// CORS - Permettre les requêtes cross-origin
app.use(cors({
    origin: process.env.CORS_ORIGIN || '*',
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH'],
    allowedHeaders: ['Content-Type', 'Authorization']
}));

// Compression - Compresser les réponses HTTP
app.use(compression());

// ============================================
// MIDDLEWARE DE PARSING DES DONNÉES
// ============================================

// Parser les requêtes JSON
app.use(bodyParser.json({ limit: '10mb' }));

// Parser les requêtes URL-encoded
app.use(bodyParser.urlencoded({ limit: '10mb', extended: true }));

// ============================================
// SESSION ET AUTHENTIFICATION
// ============================================

// Configuration des sessions avec PostgreSQL
app.use(session({
    store: new pgSession({
        pool: pool, // Utiliser le pool de connexions PostgreSQL
        tableName: 'sessions' // Table pour stocker les sessions
    }),
    secret: process.env.SESSION_SECRET || 'your_session_secret',
    resave: false,
    saveUninitialized: false,
    cookie: {
        secure: process.env.NODE_ENV === 'production', // HTTPS uniquement en production
        httpOnly: true,
        maxAge: 1000 * 60 * 60 * 24 * 7 // 7 jours
    }
}));

// ============================================
// FICHIERS STATIQUES
// ============================================

// Servir les fichiers statiques (CSS, JS, images)
app.use(express.static(path.join(__dirname, 'public')));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// ============================================
// MIDDLEWARE DE LOGS
// ============================================

// Middleware personnalisé pour logger les requêtes
app.use((req, res, next) => {
    const start = Date.now();
    res.on('finish', () => {
        const duration = Date.now() - start;
        logger.info(`${req.method} ${req.path} - Status: ${res.statusCode} - ${duration}ms`);
    });
    next();
});

// ============================================
// ROUTES DE L'APPLICATION
// ============================================

// Routes d'authentification
app.use('/api/auth', authRoutes);

// Routes des projets
app.use('/api/projects', projectRoutes);

// Routes des bots Telegram
app.use('/api/bots/telegram', botRoutes);

// Routes des méthodes
app.use('/api/methods', methodRoutes);

// Routes des paiements
app.use('/api/payments', paymentRoutes);

// Routes des utilisateurs
app.use('/api/users', userRoutes);

// Routes d'administration
app.use('/api/admin', adminRoutes);

// Routes de téléchargement
app.use('/api/downloads', downloadRoutes);

// ============================================
// ROUTES FRONTEND (Pages HTML)
// ============================================

// Page d'accueil
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'index.html'));
});

// Autres pages frontend
app.get('/projects', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'projects.html'));
});

app.get('/telegram-bots', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'telegram-bots.html'));
});

app.get('/whatsapp-bots', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'whatsapp-bots.html'));
});

app.get('/methods', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'methods.html'));
});

app.get('/community', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'community.html'));
});

app.get('/login', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'login.html'));
});

app.get('/register', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'register.html'));
});

app.get('/dashboard', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'dashboard.html'));
});

app.get('/admin', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'admin/index.html'));
});

// ============================================
// GESTION DES ERREURS 404
// ============================================

app.use((req, res) => {
    res.status(404).json({
        success: false,
        message: 'Route non trouvée',
        path: req.path
    });
});

// ============================================
// GESTION GLOBALE DES ERREURS
// ============================================

app.use((err, req, res, next) => {
    logger.error(`Erreur serveur: ${err.message}`);
    
    const statusCode = err.statusCode || 500;
    const message = process.env.NODE_ENV === 'production' 
        ? 'Une erreur serveur est survenue' 
        : err.message;

    res.status(statusCode).json({
        success: false,
        message: message,
        ...(process.env.NODE_ENV !== 'production' && { error: err.stack })
    });
});

// ============================================
// DÉMARRAGE DU SERVEUR
// ============================================

// Fonction asynchrone pour démarrer le serveur
async function startServer() {
    try {
        // Vérifier la connexion à la base de données
        await checkDatabaseConnection();
        logger.info('✓ Connexion à PostgreSQL établie');

        // Démarrer le serveur
        app.listen(PORT, HOST, () => {
            logger.info(`
╔════════════════════════════════════════╗
║     DEV SANZU HUB - SERVEUR LANCÉ     ║
╚════════════════════════════════════════╝
🌐 URL: http://${HOST}:${PORT}
📊 Environnement: ${process.env.NODE_ENV}
🗄️  Base de données: ${process.env.DB_NAME}
✓ Prêt à accepter les connexions
            `);
        });
    } catch (error) {
        logger.error(`Erreur au démarrage: ${error.message}`);
        process.exit(1);
    }
}

// Démarrer le serveur
startServer();

// Gestion de l'arrêt gracieux du serveur
process.on('SIGINT', () => {
    logger.info('Arrêt du serveur...');
    pool.end(() => {
        logger.info('Pool de connexions fermé');
        process.exit(0);
    });
});

// Exporter l'application pour les tests
module.exports = app;
