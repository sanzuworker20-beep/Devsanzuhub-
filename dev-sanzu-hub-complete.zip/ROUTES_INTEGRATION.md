/**
 * ================================================
 * INTÉGRATION DES ROUTES - À AJOUTER DANS SERVER.JS
 * ================================================
 * Remplacer les anciennes routes par celles-ci
 */

// ============================================
// IMPORTS DES ROUTES
// ============================================

const authRoutes = require('./routes/auth');
const projectRoutes = require('./routes/projects');
const botRoutes = require('./routes/bots');
const methodRoutes = require('./routes/methods');
const paymentRoutes = require('./routes/payments');
const userRoutes = require('./routes/users');
const adminRoutes = require('./routes/admin');
const downloadRoutes = require('./routes/downloads');
const notificationRoutes = require('./routes/notifications');

// ============================================
// ENREGISTREMENT DES ROUTES
// ============================================

// À ajouter après le middleware de logs dans server.js:

app.use('/api/auth', authRoutes);
app.use('/api/projects', projectRoutes);
app.use('/api/bots', botRoutes);
app.use('/api/methods', methodRoutes);
app.use('/api/payments', paymentRoutes);
app.use('/api/users', userRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/downloads', downloadRoutes);
app.use('/api/notifications', notificationRoutes);

// ============================================
// EXEMPLE D'INTÉGRATION COMPLÈTE
// ============================================

/*
// Dans le fichier server.js, après tous les autres middleware:

// Imports des dépendances
const authRoutes = require('./routes/auth');
const projectRoutes = require('./routes/projects');
const botRoutes = require('./routes/bots');
const methodRoutes = require('./routes/methods');
const paymentRoutes = require('./routes/payments');
const userRoutes = require('./routes/users');
const adminRoutes = require('./routes/admin');
const downloadRoutes = require('./routes/downloads');
const notificationRoutes = require('./routes/notifications');

// ... autres imports ...

const app = express();

// ... middleware ...

// ============================================
// ROUTES DE L'APPLICATION
// ============================================

app.use('/api/auth', authRoutes);
app.use('/api/projects', projectRoutes);
app.use('/api/bots', botRoutes);
app.use('/api/methods', methodRoutes);
app.use('/api/payments', paymentRoutes);
app.use('/api/users', userRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/downloads', downloadRoutes);
app.use('/api/notifications', notificationRoutes);

// Pages statiques...
// Gestion erreurs...
// Démarrage serveur...
*/

// ============================================
// STRUCTURE COMPLÈTE DES ROUTES
// ============================================

/*
📍 BASE API: /api

├── 🔐 /auth (9 routes)
│   ├── POST /register - Inscription
│   ├── POST /login - Connexion
│   ├── POST /logout - Déconnexion
│   ├── GET /me - Profil
│   ├── PUT /profile - Mettre à jour
│   ├── POST /change-password - Changer mot de passe
│   ├── POST /refresh-token - Rafraîchir JWT
│   ├── POST /forgot-password - Oublier mot de passe
│   └── POST /reset-password - Réinitialiser

├── 📦 /projects (7 routes)
│   ├── GET / - Lister
│   ├── GET /:id - Détail
│   ├── GET /category/:category - Par catégorie
│   ├── GET /search - Chercher
│   ├── GET /popular - Populaires
│   ├── POST / - Créer (ADMIN)
│   ├── PUT /:id - Mettre à jour (ADMIN)
│   └── DELETE /:id - Supprimer (ADMIN)

├── 🤖 /bots (14 routes)
│   ├── 📱 Telegram (7)
│   │   ├── GET /telegram - Lister
│   │   ├── GET /telegram/:id - Détail
│   │   ├── GET /telegram/search - Chercher
│   │   ├── GET /telegram/popular - Populaires
│   │   ├── GET /telegram/:id/download - Télécharger
│   │   ├── POST /telegram - Créer (ADMIN)
│   │   └── DELETE /telegram/:id - Supprimer (ADMIN)
│   └── 💬 WhatsApp (7)
│       └── (Structure identique)

├── 💎 /methods (9 routes)
│   ├── GET / - Lister
│   ├── GET /:id - Détail
│   ├── GET /search - Chercher
│   ├── GET /popular - Populaires
│   ├── GET /:id/content - Contenu privé (AUTH)
│   ├── GET /:id/stats - Stats (ADMIN)
│   ├── POST / - Créer (ADMIN)
│   ├── PUT /:id - Mettre à jour (ADMIN)
│   └── DELETE /:id - Supprimer (ADMIN)

├── 💳 /payments (10 routes)
│   ├── POST / - Créer
│   ├── GET /:id - Détail
│   ├── GET /user/me - Mes paiements
│   ├── GET /status/:status - Par statut (ADMIN)
│   ├── POST /:id/validate - Valider (ADMIN) ⭐
│   ├── POST /:id/reject - Rejeter (ADMIN)
│   ├── POST /:id/unlock-contact - Débloquer (ADMIN) ⭐
│   ├── GET /stats/overview - Stats (ADMIN)
│   ├── GET /pending/count - Nombre en attente (ADMIN)
│   └── POST /send-reminders - Rappels (ADMIN)

├── 👤 /users (7 routes)
│   ├── GET /:id - Profil
│   ├── GET /:id/downloads - Téléchargements
│   ├── GET / - Lister (ADMIN)
│   ├── POST /:id/ban - Bannir (ADMIN)
│   ├── POST /:id/unban - Débannir (ADMIN)
│   ├── POST /:id/make-admin - Promouvoir (ADMIN)
│   └── DELETE /:id - Supprimer (ADMIN)

├── ⚙️ /admin (9 routes)
│   ├── GET /dashboard - Dashboard
│   ├── GET /recent-activity - Activités
│   ├── GET /settings - Paramètres
│   ├── GET /settings/:key - Un paramètre
│   ├── POST /settings - Mettre à jour (ADMIN)
│   ├── PUT /settings/:key - Mettre à jour un (ADMIN)
│   ├── GET /logs - Logs
│   ├── GET /logs/suspicious - Activités suspectes
│   └── POST /logs/cleanup - Nettoyer (ADMIN)

├── 📥 /downloads (5 routes)
│   ├── GET /history - Mon historique
│   ├── GET /stats/overview - Stats globales (ADMIN)
│   ├── GET /stats/recent - Stats 7 jours (ADMIN)
│   ├── GET /stats/popular - Plus populaires (ADMIN)
│   └── GET /all - Tous (ADMIN)

└── 🔔 /notifications (7 routes)
    ├── GET / - Mes notifications
    ├── GET /unread - Non lues
    ├── GET /unread/count - Nombre non lues
    ├── POST /:id/read - Marquer lue
    ├── POST /mark-all-read - Marquer toutes
    ├── DELETE /:id - Supprimer
    └── DELETE /cleanup - Nettoyer lues
*/

// ============================================
// AUTHENTIFICATION PAR ROUTE
// ============================================

/*
🔓 PUBLIQUES (pas d'authentification)
- POST /auth/register
- POST /auth/login
- GET /auth/check
- POST /auth/forgot-password
- POST /auth/reset-password
- GET /projects (toutes)
- GET /bots/telegram (toutes sauf POST/DELETE)
- GET /bots/whatsapp (toutes sauf POST/DELETE)
- GET /methods (sauf /content, sauf DELETE/POST)
- GET /users/:id (profil public)

🔐 AUTHENTIFIÉES (utilisateur connecté)
- POST /auth/logout
- GET /auth/me
- PUT /auth/profile
- POST /auth/change-password
- POST /auth/refresh-token
- POST /payments
- GET /payments/:id (ses paiements)
- GET /payments/user/me
- GET /payments/check-access/:methodId
- GET /methods/:id/content ⭐
- GET /downloads/history
- GET /notifications (tous)
- POST /notifications/:id/read
- POST /notifications/mark-all-read
- DELETE /notifications/:id
- DELETE /notifications/cleanup

🛡️ ADMIN SEULEMENT
- POST /projects
- PUT /projects/:id
- DELETE /projects/:id
- POST /bots/telegram
- DELETE /bots/telegram/:id
- POST /bots/whatsapp
- DELETE /bots/whatsapp/:id
- POST /methods
- PUT /methods/:id
- DELETE /methods/:id
- GET /payments/status/:status
- POST /payments/:id/validate ⭐
- POST /payments/:id/reject
- POST /payments/:id/unlock-contact ⭐
- GET /payments/stats/overview
- GET /payments/pending/count
- POST /payments/send-reminders
- GET /users
- POST /users/:id/ban
- POST /users/:id/unban
- POST /users/:id/make-admin
- DELETE /users/:id
- GET /users/stats/overview
- GET /admin/dashboard
- GET /admin/recent-activity
- GET /admin/settings
- GET /admin/settings/:key
- POST /admin/settings
- PUT /admin/settings/:key
- GET /admin/logs
- GET /admin/logs/suspicious
- POST /admin/logs/cleanup
- POST /admin/notifications/broadcast
- POST /admin/backup
- GET /downloads/stats/overview
- GET /downloads/stats/recent
- GET /downloads/stats/popular
- GET /downloads/all
- GET /downloads/by-type/:botType
*/

// ============================================
// FONCTIONNALITÉS CLÉS
// ============================================

/*
⭐ VALIDATION MANUELLE DES PAIEMENTS
   POST /api/payments/:id/validate

⭐ DÉBLOCAGE AUTOMATIQUE DES COORDONNÉES
   POST /api/payments/:id/unlock-contact

⭐ ACCÈS AU CONTENU PRIVÉ APRÈS ACHAT
   GET /api/methods/:id/content

⭐ SYSTÈME DE NOTIFICATION COMPLET
   GET /api/notifications
   POST /api/notifications/:id/read

⭐ LOGS ET AUDIT COMPLETS
   GET /api/admin/logs
   GET /api/admin/logs/suspicious

⭐ PARAMÈTRES CONFIGURABLES 100% SANS CODE
   GET /api/admin/settings
   PUT /api/admin/settings/:key
*/

module.exports = {
    authRoutes,
    projectRoutes,
    botRoutes,
    methodRoutes,
    paymentRoutes,
    userRoutes,
    adminRoutes,
    downloadRoutes,
    notificationRoutes
};
