# 🚀 GUIDE D'INSTALLATION - DEV SANZU HUB

## 📋 Table des matières
1. [Prérequis](#prérequis)
2. [Installation](#installation)
3. [Configuration](#configuration)
4. [Démarrage](#démarrage)
5. [Tests](#tests)
6. [Déploiement](#déploiement)
7. [Troubleshooting](#troubleshooting)

---

## 🔧 Prérequis

### Système d'exploitation
- Linux (Ubuntu/Debian)
- macOS
- Windows avec WSL2

### Logiciels requis
- **Node.js** v16 ou supérieur
- **npm** v7 ou supérieur
- **PostgreSQL** v13 ou supérieur
- **Git** (optionnel)

### Vérifier les versions
```bash
node --version    # v16.x.x ou supérieur
npm --version     # 7.x.x ou supérieur
psql --version    # PostgreSQL 13 ou supérieur
```

---

## 📦 Installation

### Étape 1: Cloner/Télécharger le projet

```bash
# Via Git
git clone https://github.com/devsanzu/dev-sanzu-hub.git
cd dev-sanzu-hub

# Ou télécharger et extraire le ZIP
unzip dev-sanzu-hub.zip
cd dev-sanzu-hub
```

### Étape 2: Installer les dépendances Node.js

```bash
npm install
```

Les dépendances seront installées dans `node_modules/`

Vérifier l'installation:
```bash
npm list --depth=0
```

### Étape 3: Créer la base de données PostgreSQL

#### Option A: Ligne de commande

```bash
# Créer l'utilisateur
createuser -P devsanzu
# Entrer le mot de passe: your_secure_password

# Créer la base de données
createdb -O devsanzu devsanzu_hub

# Vérifier
psql -U devsanzu -d devsanzu_hub -c "SELECT version();"
```

#### Option B: Interface graphique (pgAdmin)

1. Ouvrir pgAdmin 4
2. Connexion au serveur PostgreSQL
3. Créer un nouvel utilisateur: `devsanzu`
4. Créer une nouvelle base: `devsanzu_hub`

### Étape 4: Configurer les variables d'environnement

```bash
# Copier le fichier exemple
cp .env.example .env

# Éditer le fichier avec vos paramètres
nano .env
```

**Paramètres critiques à modifier:**

```env
# Base de données
DB_HOST=localhost
DB_PORT=5432
DB_USER=devsanzu
DB_PASSWORD=your_secure_password  # Changer!
DB_NAME=devsanzu_hub

# JWT
JWT_SECRET=votre_clé_secrète_très_complexe  # Changer!
JWT_EXPIRE=7d

# Session
SESSION_SECRET=votre_autre_clé_secrète      # Changer!

# Paiement
PAYMENT_QR_CODE_IMAGE=https://votre-url/qrcode.jpg  # Ajouter votre QR code

# URL App
APP_URL=http://localhost:3000  # À adapter

# Node environnement
NODE_ENV=development
```

---

## ⚙️ Configuration

### 1. Initialiser la base de données

```bash
npm run db:init
```

Ceci créera:
- Toutes les tables
- Les index
- Les paramètres par défaut

Vérifier dans PostgreSQL:
```bash
psql -U devsanzu -d devsanzu_hub -c "\dt"
```

### 2. Créer un utilisateur administrateur

Créer un fichier `scripts/createAdmin.js`:

```javascript
const User = require('./models/User');

async function createAdmin() {
    try {
        const admin = await User.create({
            username: 'admin',
            email: 'admin@devsanzu.com',
            password: 'AdminPassword123!',
            fullName: 'Administrateur'
        });

        // Rendre administrateur
        const { pool } = require('./config/database');
        await pool.query(
            'UPDATE users SET is_admin = TRUE WHERE id = $1',
            [admin.id]
        );

        console.log('✓ Admin créé:', admin.email);
        process.exit(0);
    } catch (error) {
        console.error('Erreur:', error.message);
        process.exit(1);
    }
}

createAdmin();
```

Exécuter:
```bash
node scripts/createAdmin.js
```

### 3. Configuration des dossiers

Les dossiers suivants seront créés automatiquement:
- `/uploads` - Fichiers uploadés
- `/logs` - Fichiers de logs
- `/uploads/bots` - Fichiers de bots
- `/uploads/projects` - Images de projets
- `/uploads/avatars` - Avatars utilisateurs

---

## 🚀 Démarrage

### Mode développement (avec rechargement automatique)

```bash
npm run dev
```

Le serveur démarre sur `http://localhost:3000`

Avec **nodemon**, les changements sont appliqués automatiquement.

### Mode production

```bash
npm start
```

### Vérifier que tout fonctionne

```bash
# Le serveur affiche:
# ╔════════════════════════════════════════╗
# ║     DEV SANZU HUB - SERVEUR LANCÉ     ║
# ╚════════════════════════════════════════╝
# 🌐 URL: http://localhost:3000
# 📊 Environnement: development
# 🗄️  Base de données: devsanzu_hub
# ✓ Prêt à accepter les connexions
```

### Accéder au site

- **Page d'accueil:** http://localhost:3000
- **Inscription:** http://localhost:3000/register
- **Connexion:** http://localhost:3000/login
- **Admin:** http://localhost:3000/admin

---

## ✅ Tests

### Test de l'API avec cURL

```bash
# Vérifier l'authentification
curl http://localhost:3000/api/auth/check

# Inscription
curl -X POST http://localhost:3000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "username": "testuser",
    "email": "test@example.com",
    "password": "TestPassword123!",
    "passwordConfirm": "TestPassword123!"
  }'

# Connexion
curl -X POST http://localhost:3000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "test@example.com",
    "password": "TestPassword123!"
  }'

# Lister les projets
curl http://localhost:3000/api/projects
```

### Test avec Postman

1. Importer la collection des endpoints
2. Configurer les variables d'environnement
3. Exécuter les requêtes de test

---

## 🌐 Déploiement

### Déployer sur Heroku

```bash
# 1. Créer une app Heroku
heroku create dev-sanzu-hub

# 2. Ajouter PostgreSQL
heroku addons:create heroku-postgresql:standard-0

# 3. Définir les variables d'environnement
heroku config:set JWT_SECRET=votre_clé_complexe
heroku config:set SESSION_SECRET=autre_clé_complexe
heroku config:set NODE_ENV=production

# 4. Déployer
git push heroku main

# 5. Initialiser la base
heroku run npm run db:init
```

### Déployer sur Railway

```bash
# 1. Connecter GitHub et créer un service PostgreSQL
# 2. Ajouter les variables d'environnement depuis Railway dashboard
# 3. Déployer via GitHub

# Vérifie la déployment
railway logs
```

### Déployer sur un VPS (DigitalOcean, Linode, etc.)

```bash
# 1. SSH sur le serveur
ssh root@your_server_ip

# 2. Installer Node.js et PostgreSQL
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt install nodejs postgresql postgresql-contrib

# 3. Cloner le projet
git clone https://github.com/devsanzu/dev-sanzu-hub.git
cd dev-sanzu-hub

# 4. Installer les dépendances
npm install --production

# 5. Configurer .env
nano .env

# 6. Initialiser la BDD
npm run db:init

# 7. Utiliser PM2 pour maintenir le serveur en vie
npm install -g pm2
pm2 start server.js --name "devsanzu-hub"
pm2 startup
pm2 save

# 8. Configurer nginx comme reverse proxy
sudo nano /etc/nginx/sites-available/default
# Ajouter:
# server {
#     listen 80;
#     server_name votre-domaine.com;
#     location / {
#         proxy_pass http://localhost:3000;
#         proxy_http_version 1.1;
#         proxy_set_header Upgrade $http_upgrade;
#         proxy_set_header Connection 'upgrade';
#         proxy_set_header Host $host;
#     }
# }

sudo systemctl restart nginx
```

---

## 🔧 Troubleshooting

### "Module not found" erreur

```bash
rm -rf node_modules package-lock.json
npm install
```

### Erreur de connexion PostgreSQL

```bash
# Vérifier que PostgreSQL est en cours d'exécution
sudo systemctl status postgresql

# Redémarrer si nécessaire
sudo systemctl restart postgresql

# Vérifier les credentials
psql -U devsanzu -d devsanzu_hub -c "SELECT 1"
```

### Port 3000 déjà utilisé

```bash
# Lister les processus utilisant le port 3000
lsof -i :3000

# Tuer le processus
kill -9 <PID>

# Ou utiliser un autre port
PORT=3001 npm start
```

### Erreurs de logs

```bash
# Afficher les logs en direct
tail -f logs/2024-01-15.log

# Nettoyer les anciens logs
npm run db:init  # Puis POST /api/admin/logs/cleanup
```

### Erreur JWT invalide

Vérifier que `JWT_SECRET` est:
- Défini dans `.env`
- Suffisamment complexe
- Pas vide

```bash
# Générer une nouvelle clé
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

### Base de données non trouvée

```bash
# Créer la base
createdb -O devsanzu devsanzu_hub

# Initialiser les tables
npm run db:init
```

---

## 📞 Support

Si vous rencontrez des problèmes:

1. Consulter les logs: `logs/YYYY-MM-DD.log`
2. Vérifier les erreurs Node.js dans le terminal
3. Contacter le support: support@devsanzu.com

---

**Installation complètement fonctionnelle! 🎉**

Prochaines étapes:
- [ ] Créer un utilisateur admin
- [ ] Configurer le QR code de paiement
- [ ] Ajouter des bots et méthodes
- [ ] Configurer les paramètres du site
- [ ] Tester tous les endpoints
