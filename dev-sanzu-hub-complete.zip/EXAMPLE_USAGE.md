# 📚 Exemples d'Utilisation - DEV SANZU HUB

Ce fichier contient des exemples de code pour utiliser les modèles et la base de données.

---

## 🔐 Authentification Utilisateur

### Créer un nouvel utilisateur

```javascript
const User = require('./models/User');

// Créer un utilisateur
const newUser = await User.create({
    username: 'john_doe',
    email: 'john@example.com',
    password: 'SecurePassword123!',
    fullName: 'John Doe'
});

console.log('Utilisateur créé:', newUser);
// Résultat:
// {
//   id: 'uuid-xxx',
//   username: 'john_doe',
//   email: 'john@example.com',
//   full_name: 'John Doe',
//   is_admin: false,
//   created_at: '2024-06-20T10:30:00Z'
// }
```

### Chercher un utilisateur

```javascript
// Par email
const user = await User.findByEmail('john@example.com');

// Par ID
const userById = await User.findById('uuid-xxx');

// Par username
const userByUsername = await User.findByUsername('john_doe');
```

### Vérifier le mot de passe

```javascript
const user = await User.findByEmail('john@example.com');
const isValid = await User.verifyPassword('SecurePassword123!', user.password_hash);

if (isValid) {
    console.log('Mot de passe correct');
} else {
    console.log('Mot de passe incorrect');
}
```

### Mettre à jour le profil

```javascript
const user = await User.update('user-id', {
    fullName: 'John William Doe',
    bio: 'Bot developer from USA',
    avatarUrl: 'https://example.com/avatar.jpg',
    phoneNumber: '+1234567890',
    contactInfo: 'Contact via Telegram: @johndoe'
});
```

### Débloquer les coordonnées de contact

```javascript
// Après un paiement validé
await User.unlockContactInfo('user-id');
```

### Promouvoir en administrateur

```javascript
await User.makeAdmin('user-id');
```

---

## 📦 Gestion des Projets

### Créer un projet

```javascript
const Project = require('./models/Project');

const project = await Project.create({
    title: 'WhatsApp Bot Automation',
    description: 'Un bot WhatsApp complet pour l\'automatisation',
    category: 'whatsapp',
    version: '1.0.0',
    authorId: 'user-id-xxx',
    imageUrl: 'https://example.com/project-image.jpg'
});
```

### Obtenir les projets

```javascript
// Tous les projets publiés
const projects = await Project.getPublished(20, 0); // limit, offset

// Par catégorie
const telegramProjects = await Project.getByCategory('telegram', 20, 0);

// Chercher
const results = await Project.search('bot telegram', 20, 0);

// Populaires
const popular = await Project.getPopular(10);

// Derniers
const latest = await Project.getLatest(10);

// Par auteur
const authorProjects = await Project.getByAuthor('author-id', 20, 0);
```

### Mettre à jour un projet

```javascript
const updated = await Project.update('project-id', {
    title: 'Nouveau titre',
    description: 'Nouvelle description',
    version: '1.1.0',
    isPublished: true
});
```

### Incrémenter les compteurs

```javascript
// Quand quelqu'un télécharge
await Project.incrementDownloadCount('project-id');

// Quand quelqu'un voit le projet
await Project.incrementViewCount('project-id');
```

---

## 🤖 Gestion des Bots Telegram

### Créer un bot Telegram

```javascript
const TelegramBot = require('./models/TelegramBot');

const bot = await TelegramBot.create({
    projectId: 'project-id-xxx',
    name: 'Auto Messages Bot',
    description: 'Bot pour envoyer des messages automatiques sur Telegram',
    version: '1.0.0',
    features: 'Envoi automatique, Programmation, Statistics',
    fileUrl: 'https://example.com/telegram-bot-v1.zip',
    filePath: '/uploads/bots/telegram-bot-v1.zip',
    fileSize: 5242880, // 5 MB
    changelog: 'Version initiale avec toutes les fonctionnalités de base'
});
```

### Obtenir les bots Telegram

```javascript
// Tous les bots
const allBots = await TelegramBot.getAll(20, 0);

// Chercher
const results = await TelegramBot.search('messages', 20, 0);

// Populaires
const popular = await TelegramBot.getPopular(10);

// Par projet
const botsByProject = await TelegramBot.getByProject('project-id');
```

### Mettre à jour un bot

```javascript
const updated = await TelegramBot.update('bot-id', {
    name: 'Updated Bot Name',
    version: '1.1.0',
    changelog: 'Corrections de bugs et améliorations'
});
```

---

## 💬 Gestion des Bots WhatsApp

Fonctionnement identique aux bots Telegram:

```javascript
const WhatsAppBot = require('./models/WhatsAppBot');

const bot = await WhatsAppBot.create({
    projectId: 'project-id',
    name: 'WhatsApp Automation',
    description: 'Automatisation WhatsApp',
    version: '1.0.0',
    features: 'Réponses auto, Filtrage, Broadcasting',
    fileUrl: 'https://example.com/whatsapp-bot.zip',
    filePath: '/uploads/bots/whatsapp-bot.zip',
    fileSize: 7340032
});
```

---

## 💰 Gestion des Méthodes Payantes

### Créer une méthode

```javascript
const Method = require('./models/Method');

const method = await Method.create({
    title: 'Méthode WhatsApp Secrète',
    description: 'Une méthode exclusive pour gagner avec WhatsApp',
    version: '1.0.0',
    price: 49.99,
    currency: 'USD',
    imageUrl: 'https://example.com/method-image.jpg',
    content: 'Contenu privé de la méthode...',
    contactInfo: 'Contact via email après achat',
    contactEmail: 'support@devsanzu.com',
    contactPhone: '+1234567890'
});
```

### Obtenir les méthodes

```javascript
// Publiées
const published = await Method.getPublished(20, 0);

// Chercher
const search = await Method.search('whatsapp', 20, 0);

// Populaires
const popular = await Method.getPopular(10);

// Dernieres
const latest = await Method.getLatest(10);
```

### Mettre à jour une méthode

```javascript
const updated = await Method.update('method-id', {
    title: 'Titre mis à jour',
    price: 59.99,
    isPublished: true
});
```

### Incrémenter les compteurs

```javascript
// Quand quelqu'un voit la méthode
await Method.incrementViewCount('method-id');

// Quand quelqu'un achète
await Method.incrementPurchaseCount('method-id');
```

### Obtenir le contenu privé

```javascript
// Seulement après validation du paiement
const privateContent = await Method.getPrivateContent('method-id');

// Résultat: { content, contact_info, contact_email, contact_phone }
```

---

## 💳 Gestion des Paiements

### Créer un paiement

```javascript
const Payment = require('./models/Payment');

const payment = await Payment.create({
    userId: 'user-id',
    methodId: 'method-id',
    amount: 49.99,
    currency: 'USD',
    paymentMethod: 'qrcode', // ou 'crypto', 'other'
    transactionId: 'txn_12345',
    notes: 'Paiement via WhatsApp'
});
```

### Obtenir les paiements

```javascript
// D'un utilisateur
const userPayments = await Payment.getByUser('user-id', 50, 0);

// En attente de validation
const pending = await Payment.getPending(50, 0);

// Validés
const validated = await Payment.getValidated(50, 0);

// Tous (admin)
const all = await Payment.getAll(50, 0);
```

### Valider un paiement

```javascript
const validated = await Payment.validate(
    'payment-id',
    'admin-id',
    'Paiement validé - reçu bien reçu'
);

// Débloquer automatiquement les coordonnées
await Payment.unlockContact('payment-id');
```

### Rejeter un paiement

```javascript
const rejected = await Payment.reject(
    'payment-id',
    'admin-id',
    'Paiement non conforme - montant insuffisant'
);
```

### Statistiques

```javascript
const stats = await Payment.getStatistics();
// {
//   total_payments: 150,
//   validated_payments: 120,
//   pending_payments: 30,
//   total_revenue: 5999.50,
//   average_payment: 49.99
// }
```

---

## 🔔 Gestion des Notifications

### Créer une notification

```javascript
const Notification = require('./models/Notification');

const notif = await Notification.create({
    userId: 'user-id',
    type: 'payment',
    title: 'Paiement reçu',
    message: 'Votre paiement pour la méthode a été validé!',
    relatedId: 'payment-id'
});
```

### Obtenir les notifications

```javascript
// D'un utilisateur
const userNotifs = await Notification.getByUser('user-id', 50, 0);

// Non lues
const unread = await Notification.getUnread('user-id');
```

### Marquer comme lue

```javascript
await Notification.markAsRead('notification-id');

// Toutes les notifications
await Notification.markAllAsRead('user-id');
```

### Envoyer une notification en masse

```javascript
const userIds = ['user-1', 'user-2', 'user-3'];

await Notification.sendBulk(
    userIds,
    'announcement',
    'Nouvelle méthode disponible!',
    'Une nouvelle méthode WhatsApp vient d\'être publiée'
);
```

### Notification système

```javascript
// À tous les utilisateurs
await Notification.createSystemNotification(
    'Maintenance programmée',
    'Le site sera en maintenance le 25 juin de 2h à 3h du matin'
);
```

---

## 📥 Suivi des Téléchargements

### Enregistrer un téléchargement

```javascript
const Download = require('./models/Download');

const dl = await Download.create({
    userId: 'user-id',
    projectId: 'project-id',
    botType: 'telegram', // ou 'whatsapp'
    fileName: 'telegram-bot-v1.0.zip',
    fileSize: 5242880,
    ipAddress: '192.168.1.1'
});
```

### Obtenir les téléchargements

```javascript
// D'un utilisateur
const userDownloads = await Download.getByUser('user-id', 50, 0);

// D'un projet
const projectDownloads = await Download.getByProject('project-id', 50, 0);

// Par type de bot
const telegramDownloads = await Download.getByBotType('telegram', 50, 0);

// Tous (admin)
const allDownloads = await Download.getAll(50, 0);
```

### Projets les plus téléchargés

```javascript
const mostDownloaded = await Download.getMostDownloaded(10);
// [
//   { project_id, title, download_count, total_size },
//   ...
// ]
```

### Statistiques

```javascript
const stats = await Download.getStatistics();
// {
//   total_downloads: 1250,
//   unique_users: 890,
//   projects_downloaded: 45,
//   total_size_downloaded: 52428800000,
//   average_file_size: 41943040
// }
```

---

## 📊 Logs d'Activité

### Enregistrer une activité

```javascript
const ActivityLog = require('./models/ActivityLog');

await ActivityLog.create({
    userId: 'user-id',
    action: 'download_bot',
    entityType: 'bot',
    entityId: 'bot-id',
    details: 'Téléchargement du bot Telegram v1.0',
    ipAddress: '192.168.1.1'
});
```

### Obtenir les activités

```javascript
// D'un utilisateur
const userLogs = await ActivityLog.getByUser('user-id', 50, 0);

// Par type d'action
const downloadLogs = await ActivityLog.getByAction('download_bot', 50, 0);

// Toutes les activités (admin)
const allLogs = await ActivityLog.getAll(100, 0);

// Dernières 24h
const recentLogs = await ActivityLog.getRecent24Hours();
```

### Activités suspectes

```javascript
const suspicious = await ActivityLog.getSuspiciousActivity();
// [
//   { ip_address, attempt_count, last_attempt },
//   ...
// ]
```

---

## ⚙️ Gestion des Paramètres

### Obtenir une paramètre

```javascript
const Settings = require('./models/Settings');

const siteName = await Settings.get('app_name');
const paymentQR = await Settings.get('payment_qr_code');
```

### Définir une paramètre

```javascript
// Créer ou mettre à jour
await Settings.set(
    'app_name',
    'DEV SANZU HUB Updated',
    'string',
    'Nom de l\'application'
);

await Settings.set(
    'enable_registration',
    'true',
    'boolean',
    'Autoriser les inscriptions'
);
```

### Obtenir toutes les paramètres

```javascript
const allSettings = await Settings.getAll();

// Sous forme d'objet
const settingsObj = await Settings.toObject();
// { app_name: 'DEV SANZU HUB', enable_registration: true, ... }
```

### Obtenir par catégorie

```javascript
const paymentSettings = await Settings.getByCategory('payment');
```

### Initialiser les paramètres par défaut

```javascript
await Settings.initializeDefaults();
```

---

## 🔗 Intégration Complète - Exemple Flux d'Achat

```javascript
const User = require('./models/User');
const Method = require('./models/Method');
const Payment = require('./models/Payment');
const Notification = require('./models/Notification');
const ActivityLog = require('./models/ActivityLog');

async function buyMethod(userId, methodId, amount, ipAddress) {
    try {
        // 1. Vérifier l'utilisateur
        const user = await User.findById(userId);
        if (!user) throw new Error('Utilisateur non trouvé');

        // 2. Obtenir la méthode
        const method = await Method.findById(methodId);
        if (!method) throw new Error('Méthode non trouvée');

        // 3. Créer le paiement
        const payment = await Payment.create({
            userId,
            methodId,
            amount,
            currency: 'USD',
            paymentMethod: 'qrcode',
            transactionId: `txn_${Date.now()}`
        });

        // 4. Enregistrer l'activité
        await ActivityLog.create({
            userId,
            action: 'purchase_method',
            entityType: 'method',
            entityId: methodId,
            details: `Achat de: ${method.title}`,
            ipAddress
        });

        // 5. Envoyer une notification
        await Notification.create({
            userId,
            type: 'purchase',
            title: 'Paiement initié',
            message: `Votre paiement de ${amount} USD pour "${method.title}" est en attente de validation`,
            relatedId: payment.id
        });

        return payment;
    } catch (error) {
        console.error('Erreur achat:', error);
        throw error;
    }
}

// Utilisation
const payment = await buyMethod(
    'user-id',
    'method-id',
    49.99,
    '192.168.1.1'
);
console.log('Paiement créé:', payment);
```

---

## 🎯 Best Practices

1. **Toujours vérifier les erreurs** - Utilisez try/catch
2. **Valider les données** - Vérifiez les entrées utilisateur
3. **Utiliser les transactions** - Pour les opérations critiques
4. **Logger les actions importantes** - Audit trail complet
5. **Envoyer des notifications** - Informer les utilisateurs
6. **Respecter les permissions** - Vérifier les rôles
7. **Éviter les requêtes N+1** - Optimiser les queries
8. **Utiliser des indexes** - Sur les colonnes fréquemment cherchées

---

## 📞 Support

Pour toute question sur l'utilisation, consultez:
- Documentation: `README.md`
- Structure du projet: `PROJECT_STRUCTURE.md`
- Code des modèles: `/models/`

