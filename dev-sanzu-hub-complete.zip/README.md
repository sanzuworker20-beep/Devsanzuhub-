# 🚀 DEV SANZU HUB - Plateforme de Distribution de Bots et Méthodes

![DEV SANZU HUB](https://img.shields.io/badge/version-1.0.0-blue)
![Node.js](https://img.shields.io/badge/Node.js-v16+-green)
![PostgreSQL](https://img.shields.io/badge/PostgreSQL-13+-blue)
![License](https://img.shields.io/badge/license-MIT-orange)

---

## 📋 Sommaire

1. [Caractéristiques](#caractéristiques)
2. [Architecture](#architecture)
3. [Installation](#installation)
4. [Configuration](#configuration)
5. [Démarrage](#démarrage)
6. [API Endpoints](#api-endpoints)
7. [Panneau d'Administration](#panneau-dadministration)
8. [Structure du Projet](#structure-du-projet)
9. [Sécurité](#sécurité)
10. [Support](#support)

---

## ✨ Caractéristiques

### Fonctionnalités Principales
- ✅ **Gestion des Bots Gratuits** - Telegram et WhatsApp
- ✅ **Système de Paiement** - QR Code intégré et validable
- ✅ **Méthodes Privées Payantes** - Avec déblocage de coordonnées
- ✅ **Authentification Sécurisée** - JWT + Sessions PostgreSQL
- ✅ **Système de Notifications** - Notifications en temps réel
- ✅ **Téléchargements Tracés** - Suivi complet des téléchargements
- ✅ **Logs d'Activité** - Enregistrement de toutes les actions
- ✅ **Panneau d'Administration Complet** - 100% configurable
- ✅ **Design Responsive** - Android, iPhone, Tablet, Desktop
- ✅ **Interface Moderne** - Glassmorphism et animations

### Sécurité
- 🔒 Hashage bcryptjs pour les mots de passe
- 🔒 JWT pour l'authentification API
- 🔒 Sessions persistantes PostgreSQL
- 🔒 Validation des entrées (validator.js)
- 🔒 CORS configuré
- 🔒 Helmet pour les headers HTTP sécurisés
- 🔒 Compression GZIP automatique

---

## 🏗️ Architecture

```
DEV SANZU HUB
│
├── Frontend
│   ├── Pages HTML (index, projects, bots, methods, etc.)
│   ├── CSS (styles, tailwind, animations)
│   ├── JavaScript (client-side logic)
│   └── Assets (images, fonts, icons)
│
├── Backend (Node.js + Express)
│   ├── Routes (API endpoints)
│   ├── Controllers (logique métier)
│   ├── Models (couche données)
│   ├── Services (services réutilisables)
│   ├── Middleware (authentification, validation)
│   └── Config (base de données, logger)
│
└── Database (PostgreSQL)
    ├── users (utilisateurs)
    ├── projects (projets)
    ├── telegram_bots (bots telegram)
    ├── whatsapp_bots (bots whatsapp)
    ├── methods (méthodes payantes)
    ├── payments (paiements)
    ├── notifications (notifications)
    ├── downloads (téléchargements)
    ├── activity_logs (logs activités)
    ├── settings (paramètres)
    └── sessions (sessions utilisateur)
```

---

## 📦 Installation

### Prérequis
- **Node.js** v16 ou supérieur
- **PostgreSQL** v13 ou supérieur
- **npm** ou **yarn**
- **Git** (optionnel)

### Étapes d'installation

1. **Cloner ou télécharger le projet**
```bash
# Cloner depuis Git
git clone https://github.com/devsanzu/dev-sanzu-hub.git
cd dev-sanzu-hub

# Ou télécharger manuellement et extraire
unzip dev-sanzu-hub.zip
cd dev-sanzu-hub
```

2. **Installer les dépendances**
```bash
npm install
```

3. **Créer le fichier .env**
```bash
cp .env.example .env
# Éditer .env avec vos paramètres
```

4. **Configurer PostgreSQL**
```bash
# Créer la base de données
createdb devsanzu_hub

# Ou utiliser un client GUI (pgAdmin, DBeaver, etc.)
```

5. **Initialiser la base de données**
```bash
npm run db:init
```

---

## ⚙️ Configuration

### Variables d'Environnement (.env)

```env
# Server Configuration
NODE_ENV=development
PORT=3000
HOST=localhost

# Database Configuration
DB_HOST=localhost
DB_PORT=5432
DB_USER=devsanzu
DB_PASSWORD=your_secure_password
DB_NAME=devsanzu_hub

# JWT Configuration
JWT_SECRET=your_jwt_secret_key
JWT_EXPIRE=7d

# Session Configuration
SESSION_SECRET=your_session_secret_key

# Payment Configuration
PAYMENT_QR_CODE_IMAGE=https://example.com/qrcode.jpg
PAYMENT_INSTRUCTION_TEXT=Scannez ce code QR

# File Upload
MAX_FILE_SIZE=50000000
UPLOAD_DIR=uploads

# App Configuration
APP_NAME=DEV SANZU HUB
APP_URL=http://localhost:3000
```

### Créer un Utilisateur Admin Initial

```javascript
// Dans un terminal Node.js
const User = require('./models/User');

await User.create({
    username: 'admin',
    email: 'admin@devsanzu.com',
    password: 'AdminPassword123!',
    fullName: 'Administrator'
});

// Rendre administrateur
const user = await User.findByEmail('admin@devsanzu.com');
await User.makeAdmin(user.id);
```

---

## 🚀 Démarrage

### Mode Développement
```bash
npm run dev
# Le serveur démarre sur http://localhost:3000
# Hot-reload activé avec nodemon
```

### Mode Production
```bash
npm start
# Le serveur démarre en mode production
```

### Scripts Disponibles
```bash
npm start              # Démarrer le serveur
npm run dev           # Mode développement avec nodemon
npm run db:init       # Initialiser la base de données
npm run db:reset      # Réinitialiser complètement la BDD
```

---

## 🔌 API Endpoints

### Authentification
- `POST /api/auth/register` - Inscription
- `POST /api/auth/login` - Connexion
- `POST /api/auth/logout` - Déconnexion
- `GET /api/auth/me` - Infos utilisateur connecté
- `POST /api/auth/refresh-token` - Rafraîchir token

### Projets
- `GET /api/projects` - Lister les projets
- `GET /api/projects/:id` - Détail d'un projet
- `POST /api/projects` - Créer un projet (admin)
- `PUT /api/projects/:id` - Mettre à jour (admin)
- `DELETE /api/projects/:id` - Supprimer (admin)
- `GET /api/projects/category/:category` - Projets par catégorie

### Bots Telegram
- `GET /api/bots/telegram` - Lister les bots
- `GET /api/bots/telegram/:id` - Détail d'un bot
- `GET /api/bots/telegram/download/:id` - Télécharger un bot
- `POST /api/bots/telegram` - Créer un bot (admin)

### Bots WhatsApp
- `GET /api/bots/whatsapp` - Lister les bots
- `GET /api/bots/whatsapp/:id` - Détail d'un bot
- `GET /api/bots/whatsapp/download/:id` - Télécharger un bot
- `POST /api/bots/whatsapp` - Créer un bot (admin)

### Méthodes
- `GET /api/methods` - Lister les méthodes
- `GET /api/methods/:id` - Détail d'une méthode
- `POST /api/methods` - Créer une méthode (admin)
- `PUT /api/methods/:id` - Mettre à jour (admin)
- `DELETE /api/methods/:id` - Supprimer (admin)

### Paiements
- `POST /api/payments` - Créer un paiement
- `GET /api/payments/:id` - Détail d'un paiement
- `GET /api/payments/user/:userId` - Paiements d'un utilisateur
- `POST /api/payments/:id/validate` - Valider un paiement (admin)
- `GET /api/payments/pending/all` - Paiements en attente (admin)

### Utilisateurs
- `GET /api/users/:id` - Profil d'un utilisateur
- `PUT /api/users/:id` - Mettre à jour profil
- `DELETE /api/users/:id` - Supprimer compte (admin)
- `GET /api/users` - Lister les utilisateurs (admin)

### Admin
- `GET /api/admin/dashboard` - Statistiques du dashboard
- `GET /api/admin/settings` - Récupérer les paramètres
- `POST /api/admin/settings` - Mettre à jour les paramètres
- `GET /api/admin/logs` - Logs d'activité
- `GET /api/admin/payments` - Gestion des paiements

### Notifications
- `GET /api/notifications` - Mes notifications
- `POST /api/notifications/:id/read` - Marquer comme lue
- `DELETE /api/notifications/:id` - Supprimer notification

### Téléchargements
- `GET /api/downloads/history` - Historique de mes téléchargements
- `GET /api/downloads/statistics` - Statistiques (admin)

---

## 🎛️ Panneau d'Administration

### Accès
- URL: `http://localhost:3000/admin`
- Identifiants: admin / AdminPassword123!

### Fonctionnalités

#### 1. Dashboard
- Statistiques globales (utilisateurs, téléchargements, revenus)
- Graphiques des activités
- Alertes et notifications

#### 2. Gestion des Projets
- Créer, éditer, supprimer les projets
- Publier/dépublier les projets
- Uploader les images

#### 3. Gestion des Bots
- **Bots Telegram**: CRUD complet
- **Bots WhatsApp**: CRUD complet
- Gérer les versions et changelogs
- Upload des fichiers ZIP

#### 4. Gestion des Méthodes
- Créer les méthodes payantes
- Définir les prix
- Ajouter le contenu privé
- Publier les méthodes

#### 5. Gestion des Paiements
- Lister les paiements en attente
- Valider/rejeter les paiements
- Débloquer les coordonnées de contact
- Voir l'historique des transactions

#### 6. Gestion des Utilisateurs
- Lister tous les utilisateurs
- Voir les profils
- Bannir/débannir les utilisateurs
- Promouvoir en administrateur

#### 7. Paramètres du Site
- **Général**: Nom, description, version, URL
- **Images**: Logo, favicon, bannière
- **Paiements**: QR Code, instructions
- **Contact**: Email, téléphone, adresse
- **Réseaux Sociaux**: Liens Telegram, WhatsApp, Twitter, Instagram
- **Sécurité**: Registrations, téléchargements, vérification email
- **Textes**: Titres, sous-titres, footer

#### 8. Logs d'Activité
- Suivi complet de toutes les actions
- Filtrage par utilisateur, date, action
- Export en JSON

#### 9. Statistiques
- Graphiques des téléchargements
- Revenus générés
- Méthodes populaires
- Utilisateurs actifs

---

## 📁 Structure du Projet

```
dev-sanzu-hub/
│
├── config/
│   ├── database.js          # Configuration PostgreSQL
│   └── logger.js            # Système de logs
│
├── models/
│   ├── User.js              # Modèle utilisateur
│   ├── Project.js           # Modèle projet
│   ├── TelegramBot.js       # Modèle bot Telegram
│   ├── WhatsAppBot.js       # Modèle bot WhatsApp
│   ├── Method.js            # Modèle méthode payante
│   ├── Payment.js           # Modèle paiement
│   ├── Notification.js      # Modèle notification
│   ├── Download.js          # Modèle téléchargement
│   ├── ActivityLog.js       # Modèle logs activité
│   └── Settings.js          # Modèle paramètres
│
├── controllers/             # [À DÉVELOPPER EN PARTIE 2]
│   ├── authController.js
│   ├── projectController.js
│   ├── botController.js
│   ├── methodController.js
│   ├── paymentController.js
│   ├── userController.js
│   └── adminController.js
│
├── routes/                 # [À DÉVELOPPER EN PARTIE 2]
│   ├── auth.js
│   ├── projects.js
│   ├── bots.js
│   ├── methods.js
│   ├── payments.js
│   ├── users.js
│   ├── admin.js
│   └── downloads.js
│
├── middleware/             # [À DÉVELOPPER EN PARTIE 2]
│   ├── auth.js             # Vérification authentification
│   ├── validation.js       # Validation des données
│   └── errorHandler.js     # Gestion des erreurs
│
├── services/               # [À DÉVELOPPER EN PARTIE 2]
│   ├── authService.js
│   ├── paymentService.js
│   ├── notificationService.js
│   └── downloadService.js
│
├── public/                 # Fichiers statiques
│   ├── css/
│   │   ├── style.css
│   │   └── tailwind.css
│   ├── js/
│   │   ├── app.js
│   │   ├── auth.js
│   │   └── api.js
│   ├── assets/
│   │   ├── logo.png
│   │   ├── favicon.ico
│   │   └── banner.jpg
│   └── images/
│
├── views/                  # [À DÉVELOPPER EN PARTIE 3]
│   ├── index.html          # Page d'accueil
│   ├── projects.html       # Projets
│   ├── telegram-bots.html  # Bots Telegram
│   ├── whatsapp-bots.html  # Bots WhatsApp
│   ├── methods.html        # Méthodes
│   ├── community.html      # Communauté
│   ├── login.html          # Connexion
│   ├── register.html       # Inscription
│   ├── dashboard.html      # Dashboard utilisateur
│   └── admin/              # Pages admin
│       ├── index.html
│       ├── projects.html
│       ├── bots.html
│       ├── methods.html
│       ├── payments.html
│       ├── users.html
│       ├── settings.html
│       ├── logs.html
│       └── statistics.html
│
├── uploads/                # Fichiers uploadés (dossier)
│   └── .gitkeep
│
├── logs/                   # Fichiers de logs (dossier)
│   └── .gitkeep
│
├── scripts/
│   ├── initDatabase.js     # Initialiser BDD
│   └── resetDatabase.js    # Réinitialiser BDD
│
├── server.js               # Serveur principal
├── package.json            # Dépendances
├── .env.example            # Variables d'environnement (exemple)
├── .gitignore              # Fichiers à ignorer
└── README.md               # Documentation
```

---

## 🔐 Sécurité

### Bonnes Pratiques Implémentées

1. **Authentification**
   - Mot de passe hashé avec bcryptjs (10 rounds)
   - JWT pour les requêtes API
   - Sessions sécurisées avec PostgreSQL

2. **Autorisation**
   - Vérification des rôles (user, admin)
   - Vérification des permissions pour chaque endpoint
   - Isolation des données utilisateur

3. **Validation**
   - Validation des entrées avec validator.js
   - Vérification des types de données
   - Longueur maxima des champs

4. **Protection HTTP**
   - Helmet pour les headers sécurisés
   - CORS configuré
   - HTTPS recommandé en production

5. **Gestion des Données Sensibles**
   - Pas de mot de passe en log
   - Pas d'infos sensibles en réponse
   - Données de paiement sécurisées

6. **Rate Limiting**
   - À implémenter pour les endpoints sensibles
   - Prévention du brute-force

---

## 🌐 Déploiement

### Sur Replit
1. Créer un compte Replit
2. Forker ce projet ou créer un nouveau Replit
3. Installer PostgreSQL sur Replit
4. Configurer .env
5. Exécuter `npm install && npm run db:init`
6. Lancer le serveur

### Sur Railway
1. Connecter GitHub/GitLab
2. Créer un nouveau service PostgreSQL
3. Créer un nouveau service Node.js
4. Configurer les variables d'environnement
5. Déployer

### Sur Render
1. Connecter GitHub
2. Créer une base de données PostgreSQL
3. Créer un Web Service
4. Configurer les variables
5. Déployer

### Sur VPS Linux
```bash
# 1. Installer Node.js et PostgreSQL
sudo apt update
sudo apt install nodejs npm postgresql postgresql-contrib

# 2. Cloner le projet
git clone https://github.com/devsanzu/dev-sanzu-hub.git
cd dev-sanzu-hub

# 3. Installer les dépendances
npm install

# 4. Configurer .env
cp .env.example .env
# Éditer .env

# 5. Initialiser la BDD
npm run db:init

# 6. Démarrer le serveur
npm start
```

---

## 📊 Statistiques et Monitoring

### Dashboard Admin
- Nombre d'utilisateurs
- Téléchargements totaux
- Revenus générés
- Méthodes vendues
- Activités récentes

### Logs
- Fichiers logs dans `/logs`
- Nouveau fichier par jour
- Format: `YYYY-MM-DD.log`
- Niveaux: ERROR, WARN, INFO, DEBUG

---

## 📝 Licence

Ce projet est sous licence MIT. Voir `LICENSE` pour plus de détails.

---

## 👥 Support

Pour toute question ou problème:
- 📧 Email: support@devsanzu.com
- 💬 Telegram: https://t.me/devsanzu
- 📱 WhatsApp: https://wa.me/1234567890
- 🐦 Twitter: https://twitter.com/devsanzu

---

## 🎯 Roadmap

- [ ] Système de cache Redis
- [ ] WebSocket pour notifications en temps réel
- [ ] API GraphQL
- [ ] Mobile app React Native
- [ ] Intégration Stripe/PayPal
- [ ] Multi-langue
- [ ] Dark mode

---

## 🙏 Remerciements

Merci à tous les contributeurs et utilisateurs de DEV SANZU HUB!

---

**DEV SANZU HUB** © 2024 - Plateforme de Distribution de Bots et Méthodes
