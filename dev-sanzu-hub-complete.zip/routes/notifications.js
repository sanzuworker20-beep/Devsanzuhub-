/**
 * ================================================
 * ROUTES NOTIFICATIONS
 * ================================================
 * Endpoints pour les notifications utilisateur
 */

const express = require('express');
const router = express.Router();

const notificationController = require('../controllers/notificationController');
const { authRequired } = require('../middleware/auth');
const { validateUUIDParam, sanitizeInputs } = require('../middleware/validation');

// ============================================
// MIDDLEWARE
// ============================================

router.use(sanitizeInputs);
router.use(authRequired);

// ============================================
// NOTIFICATIONS UTILISATEUR
// ============================================

/**
 * GET /api/notifications
 * Obtenir mes notifications
 */
router.get('/', notificationController.getMyNotifications);

/**
 * GET /api/notifications/unread
 * Obtenir les notifications non lues
 */
router.get('/unread', notificationController.getUnreadNotifications);

/**
 * GET /api/notifications/unread/count
 * Nombre de notifications non lues
 */
router.get('/unread/count', notificationController.getUnreadCount);

/**
 * POST /api/notifications/:id/read
 * Marquer comme lue
 */
router.post('/:id/read', validateUUIDParam('id'), notificationController.markAsRead);

/**
 * POST /api/notifications/mark-all-read
 * Marquer toutes comme lues
 */
router.post('/mark-all-read', notificationController.markAllAsRead);

/**
 * DELETE /api/notifications/:id
 * Supprimer une notification
 */
router.delete('/:id', validateUUIDParam('id'), notificationController.deleteNotification);

/**
 * DELETE /api/notifications/cleanup
 * Nettoyer les notifications lues
 */
router.delete('/cleanup', notificationController.cleanupReadNotifications);

module.exports = router;
