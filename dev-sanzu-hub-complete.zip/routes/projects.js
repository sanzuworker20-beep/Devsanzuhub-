/**
 * ================================================
 * ROUTES PROJETS
 * ================================================
 * Endpoints pour les projets
 */

const express = require('express');
const router = express.Router();

const projectController = require('../controllers/projectController');
const { authRequired, adminRequired, loadUser } = require('../middleware/auth');
const { validateProject, validateUUIDParam, sanitizeInputs } = require('../middleware/validation');

// ============================================
// MIDDLEWARE
// ============================================

router.use(sanitizeInputs);
router.use(loadUser); // Charger l'utilisateur s'il est connecté

// ============================================
// ROUTES PUBLIQUES
// ============================================

/**
 * GET /api/projects
 * Lister tous les projets publiés
 */
router.get('/', projectController.getAllProjects);

/**
 * GET /api/projects/:id
 * Obtenir un projet spécifique
 */
router.get('/:id', validateUUIDParam('id'), projectController.getProjectById);

/**
 * GET /api/projects/category/:category
 * Obtenir les projets d'une catégorie
 */
router.get('/category/:category', projectController.getProjectsByCategory);

/**
 * GET /api/projects/search
 * Chercher des projets
 */
router.get('/search', projectController.searchProjects);

/**
 * GET /api/projects/popular
 * Obtenir les projets populaires
 */
router.get('/popular', projectController.getPopularProjects);

/**
 * GET /api/projects/latest
 * Obtenir les derniers projets
 */
router.get('/latest', projectController.getLatestProjects);

/**
 * GET /api/projects/:id/stats
 * Obtenir les stats d'un projet
 */
router.get('/:id/stats', validateUUIDParam('id'), projectController.getProjectStats);

// ============================================
// ROUTES ADMIN
// ============================================

/**
 * POST /api/projects
 * Créer un projet (ADMIN)
 */
router.post('/', authRequired, adminRequired, validateProject, projectController.createProject);

/**
 * PUT /api/projects/:id
 * Mettre à jour un projet (ADMIN)
 */
router.put('/:id', authRequired, adminRequired, validateUUIDParam('id'), projectController.updateProject);

/**
 * DELETE /api/projects/:id
 * Supprimer un projet (ADMIN)
 */
router.delete('/:id', authRequired, adminRequired, validateUUIDParam('id'), projectController.deleteProject);

/**
 * POST /api/projects/:id/publish
 * Publier/Dépublier un projet (ADMIN)
 */
router.post('/:id/publish', authRequired, adminRequired, validateUUIDParam('id'), projectController.togglePublish);

module.exports = router;
