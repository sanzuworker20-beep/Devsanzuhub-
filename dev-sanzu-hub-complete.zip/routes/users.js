/**
 * ================================================
 * ROUTES UTILISATEURS
 * ================================================
 * Endpoints pour les profils et gestion utilisateurs
 */

const express = require('express');
const router = express.Router();

const userController = require('../controllers/userController');
const { authRequired, adminRequired, loadUser } = require('../middleware/auth');
const { validateUUIDParam, sanitizeInputs } = require('../middleware/validation');

// ============================================
// MIDDLEWARE
// ============================================

router.use(sanitizeInputs);
router.use(loadUser);

// ============================================
// ROUTES PUBLIQUES
// ============================================

/**
 * GET /api/users/:id
 * Obtenir le profil d'un utilisateur
 */
router.get('/:id', validateUUIDParam('id'), userController.getUserProfile);

// ============================================
// ROUTES UTILISATEUR
// ============================================

/**
 * GET /api/users/:id/downloads
 * Obtenir l'historique des téléchargements
 */
router.get('/:id/downloads', validateUUIDParam('id'), userController.getUserDownloads);

// ============================================
// ROUTES ADMIN
// ============================================

/**
 * GET /api/users
 * Lister tous les utilisateurs (ADMIN)
 */
router.get('/', authRequired, adminRequired, userController.getAllUsers);

/**
 * POST /api/users/:id/ban
 * Bannir un utilisateur (ADMIN)
 */
router.post('/:id/ban', authRequired, adminRequired, validateUUIDParam('id'), userController.banUser);

/**
 * POST /api/users/:id/unban
 * Débannir un utilisateur (ADMIN)
 */
router.post('/:id/unban', authRequired, adminRequired, validateUUIDParam('id'), userController.unbanUser);

/**
 * POST /api/users/:id/make-admin
 * Rendre administrateur (ADMIN)
 */
router.post('/:id/make-admin', authRequired, adminRequired, validateUUIDParam('id'), userController.makeAdmin);

/**
 * DELETE /api/users/:id
 * Supprimer un utilisateur (ADMIN)
 */
router.delete('/:id', authRequired, adminRequired, validateUUIDParam('id'), userController.deleteUser);

/**
 * GET /api/users/stats/overview
 * Statistiques utilisateurs (ADMIN)
 */
router.get('/stats/overview', authRequired, adminRequired, userController.getUserStats);

module.exports = router;
