/**
 * ================================================
 * ROUTES MÉTHODES
 * ================================================
 * Endpoints pour les méthodes privées payantes
 */

const express = require('express');
const router = express.Router();

const methodController = require('../controllers/methodController');
const { authRequired, adminRequired, loadUser } = require('../middleware/auth');
const { validateMethod, validateUUIDParam, sanitizeInputs } = require('../middleware/validation');

// ============================================
// MIDDLEWARE
// ============================================

router.use(sanitizeInputs);
router.use(loadUser);

// ============================================
// ROUTES PUBLIQUES
// ============================================

/**
 * GET /api/methods
 * Lister toutes les méthodes
 */
router.get('/', methodController.getAllMethods);

/**
 * GET /api/methods/:id
 * Obtenir une méthode
 */
router.get('/:id', validateUUIDParam('id'), methodController.getMethodById);

/**
 * GET /api/methods/search
 * Chercher des méthodes
 */
router.get('/search', methodController.searchMethods);

/**
 * GET /api/methods/popular
 * Méthodes populaires
 */
router.get('/popular', methodController.getPopularMethods);

/**
 * GET /api/methods/:id/content
 * Obtenir le contenu privé (authentification requise)
 */
router.get('/:id/content', authRequired, validateUUIDParam('id'), methodController.getMethodContent);

/**
 * GET /api/methods/:id/stats
 * Obtenir les stats d'une méthode (ADMIN)
 */
router.get('/:id/stats', authRequired, adminRequired, validateUUIDParam('id'), methodController.getMethodStats);

// ============================================
// ROUTES ADMIN
// ============================================

/**
 * POST /api/methods
 * Créer une méthode (ADMIN)
 */
router.post('/', authRequired, adminRequired, validateMethod, methodController.createMethod);

/**
 * PUT /api/methods/:id
 * Mettre à jour une méthode (ADMIN)
 */
router.put('/:id', authRequired, adminRequired, validateUUIDParam('id'), methodController.updateMethod);

/**
 * DELETE /api/methods/:id
 * Supprimer une méthode (ADMIN)
 */
router.delete('/:id', authRequired, adminRequired, validateUUIDParam('id'), methodController.deleteMethod);

/**
 * POST /api/methods/:id/publish
 * Publier/Dépublier une méthode (ADMIN)
 */
router.post('/:id/publish', authRequired, adminRequired, validateUUIDParam('id'), methodController.togglePublish);

module.exports = router;
