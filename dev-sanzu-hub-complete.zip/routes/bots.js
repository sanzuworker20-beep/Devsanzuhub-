/**
 * ================================================
 * ROUTES BOTS
 * ================================================
 * Endpoints pour les bots Telegram et WhatsApp
 */

const express = require('express');
const router = express.Router();

const botController = require('../controllers/botController');
const { authRequired, adminRequired, loadUser } = require('../middleware/auth');
const { validateUUIDParam, sanitizeInputs } = require('../middleware/validation');
const FileUploadService = require('../services/fileUploadService');

// ============================================
// MIDDLEWARE
// ============================================

router.use(sanitizeInputs);
router.use(loadUser);

// ============================================
// ROUTES BOTS TELEGRAM
// ============================================

/**
 * GET /api/bots/telegram
 * Lister tous les bots Telegram
 */
router.get('/telegram', botController.getAllTelegramBots);

/**
 * GET /api/bots/telegram/:id
 * Obtenir un bot Telegram
 */
router.get('/telegram/:id', validateUUIDParam('id'), botController.getTelegramBotById);

/**
 * GET /api/bots/telegram/search
 * Chercher des bots Telegram
 */
router.get('/telegram/search', botController.searchTelegramBots);

/**
 * GET /api/bots/telegram/popular
 * Bots Telegram populaires
 */
router.get('/telegram/popular', botController.getPopularTelegramBots);

/**
 * GET /api/bots/telegram/:id/download
 * Télécharger un bot Telegram
 */
router.get('/telegram/:id/download', validateUUIDParam('id'), botController.downloadTelegramBot);

/**
 * POST /api/bots/telegram
 * Créer un bot Telegram (ADMIN)
 */
router.post(
    '/telegram',
    authRequired,
    adminRequired,
    FileUploadService.getBotUploadMiddleware(),
    botController.createTelegramBot
);

/**
 * PUT /api/bots/telegram/:id
 * Mettre à jour un bot Telegram (ADMIN)
 */
router.put('/telegram/:id', authRequired, adminRequired, validateUUIDParam('id'), botController.updateTelegramBot);

/**
 * DELETE /api/bots/telegram/:id
 * Supprimer un bot Telegram (ADMIN)
 */
router.delete('/telegram/:id', authRequired, adminRequired, validateUUIDParam('id'), botController.deleteTelegramBot);

// ============================================
// ROUTES BOTS WHATSAPP
// ============================================

/**
 * GET /api/bots/whatsapp
 * Lister tous les bots WhatsApp
 */
router.get('/whatsapp', botController.getAllWhatsAppBots);

/**
 * GET /api/bots/whatsapp/:id
 * Obtenir un bot WhatsApp
 */
router.get('/whatsapp/:id', validateUUIDParam('id'), botController.getWhatsAppBotById);

/**
 * GET /api/bots/whatsapp/:id/download
 * Télécharger un bot WhatsApp
 */
router.get('/whatsapp/:id/download', validateUUIDParam('id'), botController.downloadWhatsAppBot);

/**
 * POST /api/bots/whatsapp
 * Créer un bot WhatsApp (ADMIN)
 */
router.post(
    '/whatsapp',
    authRequired,
    adminRequired,
    FileUploadService.getBotUploadMiddleware(),
    botController.createWhatsAppBot
);

module.exports = router;
