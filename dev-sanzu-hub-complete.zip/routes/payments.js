/**
 * ================================================
 * ROUTES PAIEMENTS
 * ================================================
 * Endpoints pour les paiements et validations
 */

const express = require('express');
const router = express.Router();

const paymentController = require('../controllers/paymentController');
const { authRequired, adminRequired, loadUser } = require('../middleware/auth');
const { validatePayment, validateUUIDParam, sanitizeInputs } = require('../middleware/validation');

// ============================================
// MIDDLEWARE
// ============================================

router.use(sanitizeInputs);
router.use(loadUser);

// ============================================
// ROUTES UTILISATEUR
// ============================================

/**
 * POST /api/payments
 * Créer une demande de paiement (authentification requise)
 */
router.post('/', authRequired, validatePayment, paymentController.createPayment);

/**
 * GET /api/payments/:id
 * Obtenir les détails d'un paiement
 */
router.get('/:id', validateUUIDParam('id'), paymentController.getPaymentById);

/**
 * GET /api/payments/user/me
 * Obtenir mes paiements (authentification requise)
 */
router.get('/user/me', authRequired, paymentController.getMyPayments);

/**
 * GET /api/payments/check-access/:methodId
 * Vérifier l'accès à une méthode
 */
router.get('/check-access/:methodId', validateUUIDParam('methodId'), paymentController.checkMethodAccess);

// ============================================
// ROUTES ADMIN
// ============================================

/**
 * GET /api/payments/status/:status
 * Obtenir les paiements par statut (ADMIN)
 * Status: pending, validated
 */
router.get('/status/:status', authRequired, adminRequired, paymentController.getPaymentsByStatus);

/**
 * POST /api/payments/:id/validate
 * Valider un paiement (ADMIN)
 */
router.post('/:id/validate', authRequired, adminRequired, validateUUIDParam('id'), paymentController.validatePayment);

/**
 * POST /api/payments/:id/reject
 * Rejeter un paiement (ADMIN)
 */
router.post('/:id/reject', authRequired, adminRequired, validateUUIDParam('id'), paymentController.rejectPayment);

/**
 * POST /api/payments/:id/unlock-contact
 * Débloquer les coordonnées manuellement (ADMIN)
 */
router.post('/:id/unlock-contact', authRequired, adminRequired, validateUUIDParam('id'), paymentController.unlockContact);

/**
 * GET /api/payments/stats/overview
 * Statistiques de paiement (ADMIN)
 */
router.get('/stats/overview', authRequired, adminRequired, paymentController.getPaymentStats);

/**
 * GET /api/payments/pending/count
 * Nombre de paiements en attente (ADMIN)
 */
router.get('/pending/count', authRequired, adminRequired, paymentController.getPendingCount);

/**
 * POST /api/payments/send-reminders
 * Envoyer des rappels pour paiements en attente (ADMIN)
 */
router.post('/send-reminders', authRequired, adminRequired, paymentController.sendPaymentReminders);

module.exports = router;
