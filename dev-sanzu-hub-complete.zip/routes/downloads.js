/**
 * ================================================
 * ROUTES TÉLÉCHARGEMENTS
 * ================================================
 * Endpoints pour l'historique et statistiques
 */

const express = require('express');
const router = express.Router();

const downloadController = require('../controllers/downloadController');
const { authRequired, adminRequired, loadUser } = require('../middleware/auth');
const { sanitizeInputs } = require('../middleware/validation');

// ============================================
// MIDDLEWARE
// ============================================

router.use(sanitizeInputs);
router.use(loadUser);

// ============================================
// ROUTES UTILISATEUR
// ============================================

/**
 * GET /api/downloads/history
 * Obtenir mon historique de téléchargements
 */
router.get('/history', authRequired, downloadController.getMyDownloads);

// ============================================
// ROUTES ADMIN
// ============================================

/**
 * GET /api/downloads/stats/overview
 * Statistiques globales de téléchargement
 */
router.get('/stats/overview', authRequired, adminRequired, downloadController.getDownloadStats);

/**
 * GET /api/downloads/stats/recent
 * Statistiques des 7 derniers jours
 */
router.get('/stats/recent', authRequired, adminRequired, downloadController.getRecentStats);

/**
 * GET /api/downloads/stats/popular
 * Projets les plus téléchargés
 */
router.get('/stats/popular', authRequired, adminRequired, downloadController.getMostDownloaded);

/**
 * GET /api/downloads/all
 * Tous les téléchargements
 */
router.get('/all', authRequired, adminRequired, downloadController.getAllDownloads);

/**
 * GET /api/downloads/by-type/:botType
 * Téléchargements par type de bot
 */
router.get('/by-type/:botType', authRequired, adminRequired, downloadController.getByBotType);

module.exports = router;
