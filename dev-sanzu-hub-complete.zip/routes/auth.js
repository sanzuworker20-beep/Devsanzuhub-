/**
 * ================================================
 * ROUTES AUTHENTIFICATION
 * ================================================
 * Routes pour l'authentification et les comptes
 */

const express = require('express');
const router = express.Router();

const authController = require('../controllers/authController');
const { authRequired, notBanned, loadUser } = require('../middleware/auth');
const { validateRegister, validateLogin } = require('../middleware/validation');
const { sanitizeInputs } = require('../middleware/validation');

// ============================================
// MIDDLEWARE
// ============================================

// Appliquer la sanitisation à toutes les routes
router.use(sanitizeInputs);

// ============================================
// AUTHENTIFICATION PUBLIQUE
// ============================================

/**
 * POST /api/auth/register
 * Inscrire un nouvel utilisateur
 */
router.post('/register', validateRegister, authController.register);

/**
 * POST /api/auth/login
 * Connecter un utilisateur
 */
router.post('/login', validateLogin, authController.login);

/**
 * GET /api/auth/check
 * Vérifier l'authentification (public)
 */
router.get('/check', authController.checkAuth);

// ============================================
// AUTHENTIFICATION REQUISE
// ============================================

/**
 * POST /api/auth/logout
 * Déconnecter l'utilisateur
 */
router.post('/logout', authRequired, authController.logout);

/**
 * GET /api/auth/me
 * Obtenir les infos de l'utilisateur connecté
 */
router.get('/me', authRequired, authController.getCurrentUser);

/**
 * PUT /api/auth/profile
 * Mettre à jour le profil
 */
router.put('/profile', authRequired, authController.updateProfile);

/**
 * POST /api/auth/change-password
 * Changer le mot de passe
 */
router.post('/change-password', authRequired, authController.changePassword);

/**
 * POST /api/auth/refresh-token
 * Rafraîchir le JWT token
 */
router.post('/refresh-token', authRequired, authController.refreshToken);

/**
 * POST /api/auth/verify-email
 * Vérifier l'email
 */
router.post('/verify-email', authRequired, authController.verifyEmail);

// ============================================
// PASSWORD RESET (PUBLIC)
// ============================================

/**
 * POST /api/auth/forgot-password
 * Demander une réinitialisation
 */
router.post('/forgot-password', authController.forgotPassword);

/**
 * POST /api/auth/reset-password
 * Réinitialiser le mot de passe
 */
router.post('/reset-password', authController.resetPassword);

module.exports = router;
