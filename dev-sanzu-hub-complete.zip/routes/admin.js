/**
 * ================================================
 * ROUTES ADMINISTRATION
 * ================================================
 * Endpoints pour le panneau d'administration
 */

const express = require('express');
const router = express.Router();

const adminController = require('../controllers/adminController');
const { authRequired, adminRequired } = require('../middleware/auth');
const { sanitizeInputs } = require('../middleware/validation');

// ============================================
// MIDDLEWARE
// ============================================

router.use(sanitizeInputs);
router.use(authRequired);
router.use(adminRequired);

// ============================================
// DASHBOARD
// ============================================

/**
 * GET /api/admin/dashboard
 * Obtenir les statistiques du dashboard
 */
router.get('/dashboard', adminController.getDashboardStats);

/**
 * GET /api/admin/recent-activity
 * Obtenir les activités récentes
 */
router.get('/recent-activity', adminController.getRecentActivity);

// ============================================
// PARAMÈTRES
// ============================================

/**
 * GET /api/admin/settings
 * Obtenir tous les paramètres
 */
router.get('/settings', adminController.getSettings);

/**
 * GET /api/admin/settings/:key
 * Obtenir un paramètre spécifique
 */
router.get('/settings/:key', adminController.getSetting);

/**
 * POST /api/admin/settings
 * Mettre à jour plusieurs paramètres
 */
router.post('/settings', adminController.updateSettings);

/**
 * PUT /api/admin/settings/:key
 * Mettre à jour un paramètre spécifique
 */
router.put('/settings/:key', adminController.updateSetting);

// ============================================
// LOGS D'ACTIVITÉ
// ============================================

/**
 * GET /api/admin/logs
 * Obtenir les logs d'activité
 */
router.get('/logs', adminController.getActivityLogs);

/**
 * GET /api/admin/logs/suspicious
 * Obtenir les activités suspectes
 */
router.get('/logs/suspicious', adminController.getSuspiciousActivity);

/**
 * POST /api/admin/logs/cleanup
 * Nettoyer les anciens logs
 */
router.post('/logs/cleanup', adminController.cleanupLogs);

// ============================================
// NOTIFICATIONS SYSTÈME
// ============================================

/**
 * POST /api/admin/notifications/broadcast
 * Envoyer une notification à tous les utilisateurs
 */
router.post('/notifications/broadcast', adminController.broadcastNotification);

// ============================================
// BACKUP & MAINTENANCE
// ============================================

/**
 * POST /api/admin/backup
 * Créer une sauvegarde
 */
router.post('/backup', adminController.createBackup);

module.exports = router;
