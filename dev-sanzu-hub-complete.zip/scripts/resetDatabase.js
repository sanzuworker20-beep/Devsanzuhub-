/**
 * ================================================
 * SCRIPT DE RÉINITIALISATION DATABASE
 * ================================================
 * ⚠️  ATTENTION: Supprime TOUTES les données!
 * À utiliser uniquement en développement ou test
 * 
 * Usage: npm run db:reset
 */

require('dotenv').config();
const { resetDatabase, initDatabase } = require('../config/database');
const Settings = require('../models/Settings');
const logger = require('../config/logger');
const readline = require('readline');

/**
 * Demander une confirmation à l'utilisateur
 */
function askConfirmation() {
    return new Promise((resolve) => {
        const rl = readline.createInterface({
            input: process.stdin,
            output: process.stdout
        });

        rl.question(
            '\n⚠️  ATTENTION: Cela supprimera TOUTES les données! Continuer? (yes/no) ',
            (answer) => {
                rl.close();
                resolve(answer.toLowerCase() === 'yes');
            }
        );
    });
}

/**
 * Réinitialiser la base de données
 */
async function reset() {
    try {
        logger.info('╔════════════════════════════════════════╗');
        logger.info('║   Réinitialisation Base de Données     ║');
        logger.info('╚════════════════════════════════════════╝');
        logger.warn('');
        logger.warn('⚠️  Cette opération supprimera TOUTES les données!');
        logger.warn('');

        // Demander confirmation
        const confirmed = await askConfirmation();

        if (!confirmed) {
            logger.info('Opération annulée.');
            process.exit(0);
        }

        logger.warn('');
        logger.warn('Suppression en cours...');

        // Réinitialiser les tables
        await resetDatabase();

        logger.info('');
        logger.info('Réinitialisation des tables complète.');
        logger.info('Création des nouvelles tables...');

        // Créer les nouvelles tables
        await initDatabase();

        // Initialiser les paramètres par défaut
        logger.info('Initialisation des paramètres...');
        await Settings.initializeDefaults();

        logger.info('');
        logger.info('✓ Réinitialisation complète avec succès');
        logger.info('La base de données est vierge et prête à être utilisée.');
        logger.info('');

        process.exit(0);
    } catch (error) {
        logger.error(`Erreur lors de la réinitialisation: ${error.message}`);
        process.exit(1);
    }
}

// Lancer la réinitialisation
reset();
