/**
 * ================================================
 * SCRIPT D'INITIALISATION DATABASE
 * ================================================
 * Lance l'initialisation complète de la base de données
 * À exécuter une seule fois au démarrage du projet
 * 
 * Usage: npm run db:init
 */

require('dotenv').config();
const { initDatabase, resetDatabase } = require('../config/database');
const Settings = require('../models/Settings');
const logger = require('../config/logger');

/**
 * Initialiser la base de données
 */
async function init() {
    try {
        logger.info('╔════════════════════════════════════════╗');
        logger.info('║   Initialisation Base de Données       ║');
        logger.info('╚════════════════════════════════════════╝');

        // Initialiser les tables
        await initDatabase();

        // Initialiser les paramètres par défaut
        await Settings.initializeDefaults();

        logger.info('✓ Initialisation complète avec succès');
        logger.info('');
        logger.info('Les tables et paramètres ont été créés.');
        logger.info('Vous pouvez maintenant lancer: npm start');
        logger.info('');

        process.exit(0);
    } catch (error) {
        logger.error(`Erreur lors de l'initialisation: ${error.message}`);
        process.exit(1);
    }
}

// Lancer l'initialisation
init();
