/**
 * ================================================
 * MIDDLEWARE DE VALIDATION
 * ================================================
 * Validation des données entrantes
 * Utilise validator.js pour les vérifications
 */

const validator = require('validator');
const logger = require('../config/logger');

/**
 * Valider un email
 * @param {string} email - Email à valider
 * @returns {boolean} Valide ou non
 */
function validateEmail(email) {
    return validator.isEmail(email);
}

/**
 * Valider un mot de passe
 * Minimum 8 caractères, 1 majuscule, 1 minuscule, 1 chiffre, 1 caractère spécial
 * @param {string} password - Mot de passe à valider
 * @returns {boolean} Valide ou non
 */
function validatePassword(password) {
    if (!password || password.length < 8) {
        return false;
    }
    const strongRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]/;
    return strongRegex.test(password);
}

/**
 * Valider un nom d'utilisateur
 * 3-20 caractères, alphanumériques et underscores
 * @param {string} username - Username à valider
 * @returns {boolean} Valide ou non
 */
function validateUsername(username) {
    const usernameRegex = /^[a-zA-Z0-9_]{3,20}$/;
    return usernameRegex.test(username);
}

/**
 * Valider une URL
 * @param {string} url - URL à valider
 * @returns {boolean} Valide ou non
 */
function validateURL(url) {
    return validator.isURL(url);
}

/**
 * Valider un numéro de téléphone
 * @param {string} phone - Numéro à valider
 * @returns {boolean} Valide ou non
 */
function validatePhoneNumber(phone) {
    if (!phone) return true; // Optionnel
    return validator.isMobilePhone(phone);
}

/**
 * Valider une UUID
 * @param {string} uuid - UUID à valider
 * @returns {boolean} Valide ou non
 */
function validateUUID(uuid) {
    return validator.isUUID(uuid);
}

/**
 * Middleware pour valider l'inscription
 */
function validateRegister(req, res, next) {
    const { username, email, password, passwordConfirm } = req.body;
    const errors = [];

    // Vérifier les champs requis
    if (!username || !email || !password || !passwordConfirm) {
        return res.status(400).json({
            success: false,
            message: 'Tous les champs sont requis'
        });
    }

    // Valider le username
    if (!validateUsername(username)) {
        errors.push('Le nom d\'utilisateur doit contenir 3-20 caractères alphanumériques');
    }

    // Valider l'email
    if (!validateEmail(email)) {
        errors.push('L\'email n\'est pas valide');
    }

    // Valider le mot de passe
    if (!validatePassword(password)) {
        errors.push('Le mot de passe doit contenir au moins 8 caractères, 1 majuscule, 1 minuscule, 1 chiffre et 1 caractère spécial');
    }

    // Vérifier la confirmation
    if (password !== passwordConfirm) {
        errors.push('Les mots de passe ne correspondent pas');
    }

    if (errors.length > 0) {
        return res.status(400).json({
            success: false,
            message: 'Validation échouée',
            errors: errors
        });
    }

    next();
}

/**
 * Middleware pour valider la connexion
 */
function validateLogin(req, res, next) {
    const { email, password } = req.body;

    if (!email || !password) {
        return res.status(400).json({
            success: false,
            message: 'Email et mot de passe requis'
        });
    }

    if (!validateEmail(email)) {
        return res.status(400).json({
            success: false,
            message: 'Email invalide'
        });
    }

    next();
}

/**
 * Middleware pour valider la création de projet
 */
function validateProject(req, res, next) {
    const { title, description, category } = req.body;
    const errors = [];

    if (!title || validator.isEmpty(title)) {
        errors.push('Le titre est requis');
    }

    if (!description || validator.isEmpty(description)) {
        errors.push('La description est requise');
    }

    if (!category || validator.isEmpty(category)) {
        errors.push('La catégorie est requise');
    }

    // Vérifier les longueurs
    if (title && title.length > 255) {
        errors.push('Le titre ne doit pas dépasser 255 caractères');
    }

    if (description && description.length > 5000) {
        errors.push('La description ne doit pas dépasser 5000 caractères');
    }

    if (errors.length > 0) {
        return res.status(400).json({
            success: false,
            message: 'Validation échouée',
            errors: errors
        });
    }

    next();
}

/**
 * Middleware pour valider la création de méthode
 */
function validateMethod(req, res, next) {
    const { title, description, price } = req.body;
    const errors = [];

    if (!title || validator.isEmpty(title)) {
        errors.push('Le titre est requis');
    }

    if (!description || validator.isEmpty(description)) {
        errors.push('La description est requise');
    }

    if (!price || !validator.isFloat(price.toString(), { min: 0.01 })) {
        errors.push('Le prix doit être un nombre positif');
    }

    if (errors.length > 0) {
        return res.status(400).json({
            success: false,
            message: 'Validation échouée',
            errors: errors
        });
    }

    next();
}

/**
 * Middleware pour valider la création de paiement
 */
function validatePayment(req, res, next) {
    const { methodId, amount } = req.body;
    const errors = [];

    if (!methodId || !validator.isUUID(methodId)) {
        errors.push('ID méthode invalide');
    }

    if (!amount || !validator.isFloat(amount.toString(), { min: 0.01 })) {
        errors.push('Montant invalide');
    }

    if (errors.length > 0) {
        return res.status(400).json({
            success: false,
            message: 'Validation échouée',
            errors: errors
        });
    }

    next();
}

/**
 * Middleware pour valider l'ID UUID
 */
function validateUUIDParam(paramName = 'id') {
    return (req, res, next) => {
        const id = req.params[paramName];

        if (!id || !validateUUID(id)) {
            return res.status(400).json({
                success: false,
                message: `${paramName} invalide`
            });
        }

        next();
    };
}

/**
 * Middleware pour sanitizer les inputs
 */
function sanitizeInputs(req, res, next) {
    // Nettoyer les strings
    const sanitize = (obj) => {
        if (typeof obj === 'string') {
            return validator.trim(validator.escape(obj));
        }
        if (Array.isArray(obj)) {
            return obj.map(sanitize);
        }
        if (typeof obj === 'object' && obj !== null) {
            const sanitized = {};
            for (const key in obj) {
                sanitized[key] = sanitize(obj[key]);
            }
            return sanitized;
        }
        return obj;
    };

    req.body = sanitize(req.body);
    req.query = sanitize(req.query);
    req.params = sanitize(req.params);

    next();
}

/**
 * Middleware pour valider le contenu JSON
 */
function validateJSON(req, res, next) {
    if (req.method !== 'GET' && req.headers['content-type'] && !req.headers['content-type'].includes('application/json')) {
        return res.status(400).json({
            success: false,
            message: 'Content-Type doit être application/json'
        });
    }
    next();
}

// Exporter les middlewares et fonctions
module.exports = {
    validateEmail,
    validatePassword,
    validateUsername,
    validateURL,
    validatePhoneNumber,
    validateUUID,
    validateRegister,
    validateLogin,
    validateProject,
    validateMethod,
    validatePayment,
    validateUUIDParam,
    sanitizeInputs,
    validateJSON
};
