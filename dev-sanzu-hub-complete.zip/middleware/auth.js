/**
 * ================================================
 * MIDDLEWARE D'AUTHENTIFICATION
 * ================================================
 * Vérification JWT et sessions utilisateur
 * Protection des routes selon les rôles
 */

const jwt = require('jsonwebtoken');
const User = require('../models/User');
const logger = require('../config/logger');

/**
 * Vérifier que l'utilisateur est authentifié
 * Utilise JWT ou session
 */
async function authRequired(req, res, next) {
    try {
        // Vérifier le JWT d'abord
        const token = req.headers.authorization?.split(' ')[1];

        if (token) {
            // Vérifier le JWT
            const decoded = jwt.verify(token, process.env.JWT_SECRET);
            req.user = decoded;
            return next();
        }

        // Sinon, vérifier la session
        if (req.session && req.session.userId) {
            const user = await User.findById(req.session.userId);
            if (user && !user.is_banned) {
                req.user = user;
                return next();
            }
        }

        // Pas authentifié
        return res.status(401).json({
            success: false,
            message: 'Authentification requise'
        });
    } catch (error) {
        logger.error(`Erreur authentification: ${error.message}`);
        return res.status(401).json({
            success: false,
            message: 'Token invalide ou expiré'
        });
    }
}

/**
 * Vérifier que l'utilisateur est administrateur
 * Doit être appelé après authRequired
 */
async function adminRequired(req, res, next) {
    try {
        if (!req.user) {
            return res.status(401).json({
                success: false,
                message: 'Authentification requise'
            });
        }

        // Récupérer l'utilisateur complet
        const user = await User.findById(req.user.id);

        if (!user || !user.is_admin) {
            logger.warn(`Accès admin refusé pour utilisateur: ${req.user.id}`);
            return res.status(403).json({
                success: false,
                message: 'Accès administrateur requis'
            });
        }

        req.user = user;
        next();
    } catch (error) {
        logger.error(`Erreur vérification admin: ${error.message}`);
        return res.status(500).json({
            success: false,
            message: 'Erreur lors de la vérification'
        });
    }
}

/**
 * Vérifier que l'utilisateur n'est pas banni
 */
async function notBanned(req, res, next) {
    try {
        if (!req.user) {
            return next();
        }

        const user = await User.findById(req.user.id);

        if (user && user.is_banned) {
            logger.warn(`Utilisateur banni a tenté d'accéder: ${req.user.id}`);
            return res.status(403).json({
                success: false,
                message: 'Votre compte a été banni'
            });
        }

        next();
    } catch (error) {
        logger.error(`Erreur vérification ban: ${error.message}`);
        next();
    }
}

/**
 * Optionnel: Charger l'utilisateur s'il est authentifié
 * Ne bloque pas si non authentifié
 */
async function loadUser(req, res, next) {
    try {
        // Vérifier le JWT d'abord
        const token = req.headers.authorization?.split(' ')[1];

        if (token) {
            const decoded = jwt.verify(token, process.env.JWT_SECRET);
            const user = await User.findById(decoded.id);
            if (user) {
                req.user = user;
            }
            return next();
        }

        // Sinon, vérifier la session
        if (req.session && req.session.userId) {
            const user = await User.findById(req.session.userId);
            if (user && !user.is_banned) {
                req.user = user;
            }
        }

        next();
    } catch (error) {
        // Ignorer les erreurs JWT, continuer sans utilisateur
        next();
    }
}

/**
 * Générer un JWT token
 * @param {Object} user - Données utilisateur
 * @returns {string} Token JWT
 */
function generateToken(user) {
    return jwt.sign(
        {
            id: user.id,
            username: user.username,
            email: user.email,
            is_admin: user.is_admin
        },
        process.env.JWT_SECRET,
        { expiresIn: process.env.JWT_EXPIRE || '7d' }
    );
}

/**
 * Vérifier les permissions spécifiques
 * @param {string} permission - Permission requise
 * @returns {Function} Middleware
 */
function checkPermission(permission) {
    return async (req, res, next) => {
        try {
            if (!req.user) {
                return res.status(401).json({
                    success: false,
                    message: 'Authentification requise'
                });
            }

            // Pour l'instant, seuls les admins ont toutes les permissions
            const user = await User.findById(req.user.id);

            if (!user || !user.is_admin) {
                return res.status(403).json({
                    success: false,
                    message: 'Permission refusée'
                });
            }

            next();
        } catch (error) {
            logger.error(`Erreur vérification permission: ${error.message}`);
            return res.status(500).json({
                success: false,
                message: 'Erreur lors de la vérification'
            });
        }
    };
}

// Exporter les middlewares
module.exports = {
    authRequired,
    adminRequired,
    notBanned,
    loadUser,
    generateToken,
    checkPermission
};
