/**
 * ================================================
 * MIDDLEWARE GESTION DES ERREURS
 * ================================================
 * Traitement centralisé des erreurs
 * Logging et formatage des réponses d'erreur
 */

const logger = require('../config/logger');

/**
 * Classe personnalisée pour les erreurs API
 */
class APIError extends Error {
    constructor(statusCode, message, details = null) {
        super(message);
        this.statusCode = statusCode;
        this.details = details;
        this.timestamp = new Date().toISOString();
    }
}

/**
 * Middleware d'erreur global
 * Doit être appelé en dernier
 */
function errorHandler(err, req, res, next) {
    // Définir les valeurs par défaut
    let statusCode = err.statusCode || 500;
    let message = err.message || 'Erreur serveur interne';
    let details = err.details || null;

    // Logging
    if (statusCode >= 500) {
        logger.error(`[${statusCode}] ${message} - Stack: ${err.stack}`);
    } else if (statusCode >= 400) {
        logger.warn(`[${statusCode}] ${message}`);
    } else {
        logger.debug(`[${statusCode}] ${message}`);
    }

    // Erreurs PostgreSQL
    if (err.code === '23505') { // Unique violation
        statusCode = 409;
        message = 'Cette donnée existe déjà';
    } else if (err.code === '23503') { // Foreign key violation
        statusCode = 400;
        message = 'Référence invalide';
    } else if (err.code === '22P02') { // Invalid text representation
        statusCode = 400;
        message = 'Format de données invalide';
    }

    // Erreur JWT
    if (err.name === 'JsonWebTokenError') {
        statusCode = 401;
        message = 'Token invalide';
    } else if (err.name === 'TokenExpiredError') {
        statusCode = 401;
        message = 'Token expiré';
    }

    // Erreur de validation Multer (uploads)
    if (err.code === 'LIMIT_FILE_SIZE') {
        statusCode = 413;
        message = 'Fichier trop volumineux';
    } else if (err.code === 'LIMIT_FILE_COUNT') {
        statusCode = 400;
        message = 'Trop de fichiers';
    }

    // Envoyer la réponse
    res.status(statusCode).json({
        success: false,
        statusCode: statusCode,
        message: message,
        ...(details && { details }),
        ...(process.env.NODE_ENV !== 'production' && { error: err.message }),
        timestamp: new Date().toISOString()
    });
}

/**
 * Middleware pour capturer les erreurs async
 * Wrapper pour les fonctions async des routes
 */
function asyncHandler(fn) {
    return (req, res, next) => {
        Promise.resolve(fn(req, res, next)).catch(next);
    };
}

/**
 * Erreur 404 - Route non trouvée
 */
function notFoundHandler(req, res) {
    res.status(404).json({
        success: false,
        statusCode: 404,
        message: `Route ${req.method} ${req.path} non trouvée`,
        timestamp: new Date().toISOString()
    });
}

/**
 * Générer une erreur personnalisée
 * @param {number} statusCode - Code HTTP
 * @param {string} message - Message d'erreur
 * @param {Object} details - Détails supplémentaires
 * @throws {APIError}
 */
function throwError(statusCode, message, details = null) {
    throw new APIError(statusCode, message, details);
}

/**
 * Middleware pour les erreurs de parsing JSON
 */
function jsonErrorHandler(err, req, res, next) {
    if (err instanceof SyntaxError && 'body' in err) {
        return res.status(400).json({
            success: false,
            statusCode: 400,
            message: 'JSON invalide',
            timestamp: new Date().toISOString()
        });
    }
    next(err);
}

/**
 * Gestionnaire d'erreurs personnalisé pour les contrôleurs
 * Retourne une fonction qui gère les erreurs courantes
 */
function handleError(fn) {
    return async (req, res, next) => {
        try {
            await fn(req, res, next);
        } catch (error) {
            next(error);
        }
    };
}

/**
 * Valider les paramètres requis
 * @param {Object} data - Données à valider
 * @param {Array} requiredFields - Champs requis
 * @throws {APIError}
 */
function validateRequired(data, requiredFields) {
    const missing = requiredFields.filter(field => 
        !data[field] || (typeof data[field] === 'string' && data[field].trim() === '')
    );

    if (missing.length > 0) {
        throwError(400, 'Champs manquants', {
            missing: missing
        });
    }
}

/**
 * Erreur personnalisée pour les ressources non trouvées
 * @param {string} resourceName - Nom de la ressource
 * @throws {APIError}
 */
function resourceNotFound(resourceName) {
    throwError(404, `${resourceName} non trouvé(e)`);
}

/**
 * Erreur personnalisée pour les accès refusés
 * @param {string} message - Message personnalisé
 * @throws {APIError}
 */
function accessDenied(message = 'Accès refusé') {
    throwError(403, message);
}

/**
 * Erreur personnalisée pour les conflits
 * @param {string} message - Message personnalisé
 * @throws {APIError}
 */
function conflictError(message) {
    throwError(409, message);
}

/**
 * Erreur personnalisée pour les données invalides
 * @param {string} field - Champ concerné
 * @param {string} reason - Raison
 * @throws {APIError}
 */
function validationError(field, reason) {
    throwError(400, 'Validation échouée', {
        field: field,
        reason: reason
    });
}

// Exporter les fonctions et middlewares
module.exports = {
    APIError,
    errorHandler,
    asyncHandler,
    notFoundHandler,
    throwError,
    jsonErrorHandler,
    handleError,
    validateRequired,
    resourceNotFound,
    accessDenied,
    conflictError,
    validationError
};
