/**
 * ================================================
 * CONTRÔLEUR ADMINISTRATION
 * ================================================
 * Gestion de l'administration du site
 * Dashboard, paramètres, logs
 */

const User = require('../models/User');
const Project = require('../models/Project');
const TelegramBot = require('../models/TelegramBot');
const WhatsAppBot = require('../models/WhatsAppBot');
const Method = require('../models/Method');
const Payment = require('../models/Payment');
const Download = require('../models/Download');
const ActivityLog = require('../models/ActivityLog');
const Notification = require('../models/Notification');
const Settings = require('../models/Settings');
const NotificationService = require('../services/notificationService');
const { asyncHandler } = require('../middleware/errorHandler');
const logger = require('../config/logger');

// ============================================
// DASHBOARD ADMIN
// ============================================

/**
 * GET /api/admin/dashboard
 * Obtenir les statistiques du dashboard
 */
exports.getDashboardStats = asyncHandler(async (req, res) => {
    try {
        const [
            userStats,
            projectStats,
            telegramStats,
            whatsappStats,
            methodStats,
            paymentStats,
            downloadStats,
            notificationStats
        ] = await Promise.all([
            User.count(),
            Project.countPublished(),
            TelegramBot.getStatistics(),
            WhatsAppBot.getStatistics(),
            Method.countPublished(),
            Payment.getStatistics(),
            Download.getStatistics(),
            Notification.getStatistics()
        ]);

        res.json({
            success: true,
            data: {
                users: {
                    total: userStats
                },
                projects: {
                    total: projectStats
                },
                bots: {
                    telegram: {
                        count: parseInt(telegramStats.total_bots) || 0,
                        downloads: parseInt(telegramStats.total_downloads) || 0
                    },
                    whatsapp: {
                        count: parseInt(whatsappStats.total_bots) || 0,
                        downloads: parseInt(whatsappStats.total_downloads) || 0
                    }
                },
                methods: {
                    total: methodStats
                },
                payments: {
                    total: parseInt(paymentStats.total_payments) || 0,
                    validated: parseInt(paymentStats.validated_payments) || 0,
                    pending: parseInt(paymentStats.pending_payments) || 0,
                    totalRevenue: parseFloat(paymentStats.total_revenue) || 0,
                    averagePayment: parseFloat(paymentStats.average_payment) || 0
                },
                downloads: {
                    total: parseInt(downloadStats.total_downloads) || 0,
                    uniqueUsers: parseInt(downloadStats.unique_users) || 0
                },
                notifications: {
                    total: parseInt(notificationStats.total_notifications) || 0,
                    unread: parseInt(notificationStats.unread_notifications) || 0
                }
            }
        });
    } catch (error) {
        logger.error(`Erreur dashboard: ${error.message}`);
        res.status(500).json({
            success: false,
            message: 'Erreur'
        });
    }
});

/**
 * GET /api/admin/recent-activity
 * Obtenir les activités récentes
 */
exports.getRecentActivity = asyncHandler(async (req, res) => {
    try {
        const limit = parseInt(req.query.limit) || 50;
        const activities = await ActivityLog.getRecent24Hours();

        res.json({
            success: true,
            data: activities.slice(0, limit)
        });
    } catch (error) {
        logger.error(`Erreur activités récentes: ${error.message}`);
        res.status(500).json({
            success: false,
            message: 'Erreur'
        });
    }
});

// ============================================
// GESTION DES PARAMÈTRES
// ============================================

/**
 * GET /api/admin/settings
 * Obtenir tous les paramètres
 */
exports.getSettings = asyncHandler(async (req, res) => {
    try {
        const settings = await Settings.toObject();

        res.json({
            success: true,
            data: settings
        });
    } catch (error) {
        logger.error(`Erreur settings: ${error.message}`);
        res.status(500).json({
            success: false,
            message: 'Erreur'
        });
    }
});

/**
 * GET /api/admin/settings/:key
 * Obtenir un paramètre spécifique
 */
exports.getSetting = asyncHandler(async (req, res) => {
    try {
        const { key } = req.params;

        const value = await Settings.get(key);
        if (value === null) {
            return res.status(404).json({
                success: false,
                message: 'Paramètre non trouvé'
            });
        }

        res.json({
            success: true,
            data: {
                key,
                value
            }
        });
    } catch (error) {
        logger.error(`Erreur setting: ${error.message}`);
        res.status(500).json({
            success: false,
            message: 'Erreur'
        });
    }
});

/**
 * POST /api/admin/settings
 * Mettre à jour les paramètres
 */
exports.updateSettings = asyncHandler(async (req, res) => {
    try {
        const { settings } = req.body;

        if (!settings || typeof settings !== 'object') {
            return res.status(400).json({
                success: false,
                message: 'Paramètres invalides'
            });
        }

        const updated = {};
        for (const [key, value] of Object.entries(settings)) {
            await Settings.set(key, value.toString(), 'string', '');
            updated[key] = value;
        }

        await ActivityLog.create({
            userId: req.user.id,
            action: 'settings_updated',
            entityType: 'settings',
            entityId: 'global',
            details: `${Object.keys(updated).length} paramètres mis à jour`,
            ipAddress: req.ip
        });

        res.json({
            success: true,
            message: 'Paramètres mis à jour',
            data: updated
        });
    } catch (error) {
        logger.error(`Erreur mise à jour settings: ${error.message}`);
        res.status(500).json({
            success: false,
            message: 'Erreur'
        });
    }
});

/**
 * PUT /api/admin/settings/:key
 * Mettre à jour un paramètre spécifique
 */
exports.updateSetting = asyncHandler(async (req, res) => {
    try {
        const { key } = req.params;
        const { value, type } = req.body;

        if (!value) {
            return res.status(400).json({
                success: false,
                message: 'Valeur requise'
            });
        }

        const updated = await Settings.set(key, value.toString(), type || 'string');

        await ActivityLog.create({
            userId: req.user.id,
            action: 'setting_updated',
            entityType: 'setting',
            entityId: key,
            details: `Paramètre ${key} mis à jour`,
            ipAddress: req.ip
        });

        res.json({
            success: true,
            message: 'Paramètre mis à jour',
            data: updated
        });
    } catch (error) {
        logger.error(`Erreur mise à jour setting: ${error.message}`);
        res.status(500).json({
            success: false,
            message: 'Erreur'
        });
    }
});

// ============================================
// LOGS D'ACTIVITÉ
// ============================================

/**
 * GET /api/admin/logs
 * Obtenir les logs d'activité
 */
exports.getActivityLogs = asyncHandler(async (req, res) => {
    try {
        const limit = parseInt(req.query.limit) || 100;
        const offset = parseInt(req.query.offset) || 0;
        const action = req.query.action;
        const userId = req.query.userId;

        let logs;
        if (action) {
            logs = await ActivityLog.getByAction(action, limit, offset);
        } else if (userId) {
            logs = await ActivityLog.getByUser(userId, limit, offset);
        } else {
            logs = await ActivityLog.getAll(limit, offset);
        }

        res.json({
            success: true,
            data: logs,
            pagination: {
                limit,
                offset
            }
        });
    } catch (error) {
        logger.error(`Erreur logs: ${error.message}`);
        res.status(500).json({
            success: false,
            message: 'Erreur'
        });
    }
});

/**
 * GET /api/admin/logs/suspicious
 * Obtenir les activités suspectes
 */
exports.getSuspiciousActivity = asyncHandler(async (req, res) => {
    try {
        const suspicious = await ActivityLog.getSuspiciousActivity();

        res.json({
            success: true,
            data: suspicious
        });
    } catch (error) {
        logger.error(`Erreur activités suspectes: ${error.message}`);
        res.status(500).json({
            success: false,
            message: 'Erreur'
        });
    }
});

/**
 * POST /api/admin/logs/cleanup
 * Nettoyer les anciens logs
 */
exports.cleanupLogs = asyncHandler(async (req, res) => {
    try {
        const { daysOld } = req.body;
        const days = daysOld || 90;

        const deleted = await ActivityLog.cleanOldLogs(days);

        await ActivityLog.create({
            userId: req.user.id,
            action: 'logs_cleaned',
            entityType: 'logs',
            entityId: 'cleanup',
            details: `${deleted} logs supprimés`,
            ipAddress: req.ip
        });

        res.json({
            success: true,
            message: `${deleted} logs supprimés`,
            deleted: deleted
        });
    } catch (error) {
        logger.error(`Erreur nettoyage logs: ${error.message}`);
        res.status(500).json({
            success: false,
            message: 'Erreur'
        });
    }
});

// ============================================
// NOTIFICATIONS SYSTÈME
// ============================================

/**
 * POST /api/admin/notifications/broadcast
 * Envoyer une notification à tous les utilisateurs
 */
exports.broadcastNotification = asyncHandler(async (req, res) => {
    try {
        const { title, message } = req.body;

        if (!title || !message) {
            return res.status(400).json({
                success: false,
                message: 'Titre et message requis'
            });
        }

        await NotificationService.broadcastNotification(title, message);

        await ActivityLog.create({
            userId: req.user.id,
            action: 'notification_broadcast',
            entityType: 'notification',
            entityId: 'broadcast',
            details: `Notification envoyée: ${title}`,
            ipAddress: req.ip
        });

        res.json({
            success: true,
            message: 'Notification envoyée'
        });
    } catch (error) {
        logger.error(`Erreur broadcast: ${error.message}`);
        res.status(500).json({
            success: false,
            message: 'Erreur'
        });
    }
});

// ============================================
// SYSTÈME DE BACKUP
// ============================================

/**
 * POST /api/admin/backup
 * Créer une sauvegarde
 */
exports.createBackup = asyncHandler(async (req, res) => {
    try {
        // À implémenter selon les besoins
        // Par exemple, créer une sauvegarde PostgreSQL

        await ActivityLog.create({
            userId: req.user.id,
            action: 'backup_created',
            entityType: 'backup',
            entityId: `backup_${Date.now()}`,
            details: 'Sauvegarde créée',
            ipAddress: req.ip
        });

        res.json({
            success: true,
            message: 'Sauvegarde créée'
        });
    } catch (error) {
        logger.error(`Erreur backup: ${error.message}`);
        res.status(500).json({
            success: false,
            message: 'Erreur'
        });
    }
});

module.exports = exports;
