/**
 * ================================================
 * CONTRÔLEUR TÉLÉCHARGEMENTS
 * ================================================
 * Gestion des téléchargements et historique
 */

const Download = require('../models/Download');
const ActivityLog = require('../models/ActivityLog');
const { asyncHandler } = require('../middleware/errorHandler');
const logger = require('../config/logger');

// ============================================
// TÉLÉCHARGEMENTS UTILISATEUR
// ============================================

/**
 * GET /api/downloads/history
 * Obtenir l'historique de mes téléchargements
 */
exports.getMyDownloads = asyncHandler(async (req, res) => {
    try {
        if (!req.user) {
            return res.status(401).json({
                success: false,
                message: 'Authentification requise'
            });
        }

        const limit = parseInt(req.query.limit) || 50;
        const offset = parseInt(req.query.offset) || 0;

        const downloads = await Download.getByUser(req.user.id, limit, offset);
        const total = await Download.countByUser(req.user.id);

        res.json({
            success: true,
            data: downloads,
            pagination: {
                limit,
                offset,
                total,
                pages: Math.ceil(total / limit)
            }
        });
    } catch (error) {
        logger.error(`Erreur historique: ${error.message}`);
        res.status(500).json({
            success: false,
            message: 'Erreur'
        });
    }
});

// ============================================
// STATISTIQUES (ADMIN)
// ============================================

/**
 * GET /api/downloads/stats/overview
 * Obtenir les statistiques globales de téléchargement
 */
exports.getDownloadStats = asyncHandler(async (req, res) => {
    try {
        const stats = await Download.getStatistics();

        res.json({
            success: true,
            data: stats
        });
    } catch (error) {
        logger.error(`Erreur stats: ${error.message}`);
        res.status(500).json({
            success: false,
            message: 'Erreur'
        });
    }
});

/**
 * GET /api/downloads/stats/recent
 * Obtenir les statistiques des 7 derniers jours
 */
exports.getRecentStats = asyncHandler(async (req, res) => {
    try {
        const stats = await Download.getRecentStats();

        res.json({
            success: true,
            data: stats
        });
    } catch (error) {
        logger.error(`Erreur stats récentes: ${error.message}`);
        res.status(500).json({
            success: false,
            message: 'Erreur'
        });
    }
});

/**
 * GET /api/downloads/stats/popular
 * Obtenir les projets les plus téléchargés
 */
exports.getMostDownloaded = asyncHandler(async (req, res) => {
    try {
        const limit = parseInt(req.query.limit) || 10;
        const projects = await Download.getMostDownloaded(limit);

        res.json({
            success: true,
            data: projects
        });
    } catch (error) {
        logger.error(`Erreur populaires: ${error.message}`);
        res.status(500).json({
            success: false,
            message: 'Erreur'
        });
    }
});

/**
 * GET /api/downloads/all
 * Obtenir tous les téléchargements (ADMIN)
 */
exports.getAllDownloads = asyncHandler(async (req, res) => {
    try {
        const limit = parseInt(req.query.limit) || 50;
        const offset = parseInt(req.query.offset) || 0;

        const downloads = await Download.getAll(limit, offset);

        res.json({
            success: true,
            data: downloads,
            pagination: {
                limit,
                offset
            }
        });
    } catch (error) {
        logger.error(`Erreur all downloads: ${error.message}`);
        res.status(500).json({
            success: false,
            message: 'Erreur'
        });
    }
});

/**
 * GET /api/downloads/by-type/:botType
 * Obtenir les téléchargements par type de bot
 */
exports.getByBotType = asyncHandler(async (req, res) => {
    try {
        const { botType } = req.params;
        const limit = parseInt(req.query.limit) || 50;
        const offset = parseInt(req.query.offset) || 0;

        if (!['telegram', 'whatsapp'].includes(botType)) {
            return res.status(400).json({
                success: false,
                message: 'Type de bot invalide'
            });
        }

        const downloads = await Download.getByBotType(botType, limit, offset);

        res.json({
            success: true,
            data: downloads,
            botType: botType,
            pagination: {
                limit,
                offset
            }
        });
    } catch (error) {
        logger.error(`Erreur par type: ${error.message}`);
        res.status(500).json({
            success: false,
            message: 'Erreur'
        });
    }
});

module.exports = exports;
