/**
 * ================================================
 * CONTRÔLEUR PROJETS
 * ================================================
 * Gestion des projets publics et admins
 */

const Project = require('../models/Project');
const ActivityLog = require('../models/ActivityLog');
const { asyncHandler } = require('../middleware/errorHandler');
const logger = require('../config/logger');

// ============================================
// RÉCUPÉRATION DES PROJETS
// ============================================

/**
 * GET /api/projects
 * Lister tous les projets publiés (avec pagination)
 */
exports.getAllProjects = asyncHandler(async (req, res) => {
    try {
        const limit = parseInt(req.query.limit) || 20;
        const offset = parseInt(req.query.offset) || 0;

        const projects = await Project.getPublished(limit, offset);
        const total = await Project.countPublished();

        res.json({
            success: true,
            data: projects,
            pagination: {
                limit,
                offset,
                total,
                pages: Math.ceil(total / limit)
            }
        });
    } catch (error) {
        logger.error(`Erreur récupération projets: ${error.message}`);
        res.status(500).json({
            success: false,
            message: 'Erreur'
        });
    }
});

/**
 * GET /api/projects/:id
 * Obtenir les détails d'un projet
 */
exports.getProjectById = asyncHandler(async (req, res) => {
    try {
        const { id } = req.params;

        const project = await Project.findById(id);
        if (!project) {
            return res.status(404).json({
                success: false,
                message: 'Projet non trouvé'
            });
        }

        // Incrémenter les vues
        await Project.incrementViewCount(id);

        res.json({
            success: true,
            data: project
        });
    } catch (error) {
        logger.error(`Erreur récupération projet: ${error.message}`);
        res.status(500).json({
            success: false,
            message: 'Erreur'
        });
    }
});

/**
 * GET /api/projects/category/:category
 * Obtenir les projets d'une catégorie
 */
exports.getProjectsByCategory = asyncHandler(async (req, res) => {
    try {
        const { category } = req.params;
        const limit = parseInt(req.query.limit) || 20;
        const offset = parseInt(req.query.offset) || 0;

        const projects = await Project.getByCategory(category, limit, offset);

        res.json({
            success: true,
            data: projects,
            category: category,
            pagination: {
                limit,
                offset
            }
        });
    } catch (error) {
        logger.error(`Erreur catégorie: ${error.message}`);
        res.status(500).json({
            success: false,
            message: 'Erreur'
        });
    }
});

/**
 * GET /api/projects/search
 * Chercher des projets
 */
exports.searchProjects = asyncHandler(async (req, res) => {
    try {
        const { q } = req.query;
        const limit = parseInt(req.query.limit) || 20;
        const offset = parseInt(req.query.offset) || 0;

        if (!q || q.length < 2) {
            return res.status(400).json({
                success: false,
                message: 'Terme de recherche trop court'
            });
        }

        const results = await Project.search(q, limit, offset);

        res.json({
            success: true,
            data: results,
            searchTerm: q,
            pagination: {
                limit,
                offset,
                total: results.length
            }
        });
    } catch (error) {
        logger.error(`Erreur recherche: ${error.message}`);
        res.status(500).json({
            success: false,
            message: 'Erreur'
        });
    }
});

/**
 * GET /api/projects/popular
 * Obtenir les projets populaires
 */
exports.getPopularProjects = asyncHandler(async (req, res) => {
    try {
        const limit = parseInt(req.query.limit) || 10;
        const projects = await Project.getPopular(limit);

        res.json({
            success: true,
            data: projects
        });
    } catch (error) {
        logger.error(`Erreur projets populaires: ${error.message}`);
        res.status(500).json({
            success: false,
            message: 'Erreur'
        });
    }
});

/**
 * GET /api/projects/latest
 * Obtenir les derniers projets
 */
exports.getLatestProjects = asyncHandler(async (req, res) => {
    try {
        const limit = parseInt(req.query.limit) || 10;
        const projects = await Project.getLatest(limit);

        res.json({
            success: true,
            data: projects
        });
    } catch (error) {
        logger.error(`Erreur derniers projets: ${error.message}`);
        res.status(500).json({
            success: false,
            message: 'Erreur'
        });
    }
});

// ============================================
// CRÉATION & MODIFICATION (ADMIN)
// ============================================

/**
 * POST /api/projects
 * Créer un nouveau projet (ADMIN)
 */
exports.createProject = asyncHandler(async (req, res) => {
    try {
        const { title, description, category, version, imageUrl } = req.body;

        // Vérifier les champs requis
        if (!title || !description || !category) {
            return res.status(400).json({
                success: false,
                message: 'Champs manquants'
            });
        }

        const project = await Project.create({
            title,
            description,
            category,
            version: version || '1.0.0',
            authorId: req.user.id,
            imageUrl: imageUrl || null
        });

        // Enregistrer l'activité
        await ActivityLog.create({
            userId: req.user.id,
            action: 'project_created',
            entityType: 'project',
            entityId: project.id,
            details: `Créé le projet: ${title}`,
            ipAddress: req.ip
        });

        res.status(201).json({
            success: true,
            message: 'Projet créé',
            data: project
        });
    } catch (error) {
        logger.error(`Erreur création projet: ${error.message}`);
        res.status(500).json({
            success: false,
            message: 'Erreur'
        });
    }
});

/**
 * PUT /api/projects/:id
 * Mettre à jour un projet (ADMIN)
 */
exports.updateProject = asyncHandler(async (req, res) => {
    try {
        const { id } = req.params;
        const { title, description, category, version, imageUrl, isPublished } = req.body;

        // Vérifier que le projet existe
        const project = await Project.findById(id);
        if (!project) {
            return res.status(404).json({
                success: false,
                message: 'Projet non trouvé'
            });
        }

        const updated = await Project.update(id, {
            title,
            description,
            category,
            version,
            imageUrl,
            isPublished
        });

        // Enregistrer l'activité
        await ActivityLog.create({
            userId: req.user.id,
            action: 'project_updated',
            entityType: 'project',
            entityId: id,
            details: `Mis à jour le projet: ${title || project.title}`,
            ipAddress: req.ip
        });

        res.json({
            success: true,
            message: 'Projet mis à jour',
            data: updated
        });
    } catch (error) {
        logger.error(`Erreur mise à jour projet: ${error.message}`);
        res.status(500).json({
            success: false,
            message: 'Erreur'
        });
    }
});

/**
 * DELETE /api/projects/:id
 * Supprimer un projet (ADMIN)
 */
exports.deleteProject = asyncHandler(async (req, res) => {
    try {
        const { id } = req.params;

        // Vérifier que le projet existe
        const project = await Project.findById(id);
        if (!project) {
            return res.status(404).json({
                success: false,
                message: 'Projet non trouvé'
            });
        }

        await Project.delete(id);

        // Enregistrer l'activité
        await ActivityLog.create({
            userId: req.user.id,
            action: 'project_deleted',
            entityType: 'project',
            entityId: id,
            details: `Supprimé le projet: ${project.title}`,
            ipAddress: req.ip
        });

        res.json({
            success: true,
            message: 'Projet supprimé'
        });
    } catch (error) {
        logger.error(`Erreur suppression projet: ${error.message}`);
        res.status(500).json({
            success: false,
            message: 'Erreur'
        });
    }
});

/**
 * POST /api/projects/:id/publish
 * Publier/Dépublier un projet (ADMIN)
 */
exports.togglePublish = asyncHandler(async (req, res) => {
    try {
        const { id } = req.params;
        const { isPublished } = req.body;

        // Vérifier que le projet existe
        const project = await Project.findById(id);
        if (!project) {
            return res.status(404).json({
                success: false,
                message: 'Projet non trouvé'
            });
        }

        const updated = await Project.update(id, {
            isPublished: isPublished
        });

        // Enregistrer l'activité
        const action = isPublished ? 'Publié' : 'Dépublié';
        await ActivityLog.create({
            userId: req.user.id,
            action: `project_${isPublished ? 'published' : 'unpublished'}`,
            entityType: 'project',
            entityId: id,
            details: `${action} le projet: ${project.title}`,
            ipAddress: req.ip
        });

        res.json({
            success: true,
            message: `Projet ${isPublished ? 'publié' : 'dépublié'}`,
            data: updated
        });
    } catch (error) {
        logger.error(`Erreur publication: ${error.message}`);
        res.status(500).json({
            success: false,
            message: 'Erreur'
        });
    }
});

/**
 * GET /api/projects/:id/stats
 * Obtenir les statistiques d'un projet
 */
exports.getProjectStats = asyncHandler(async (req, res) => {
    try {
        const { id } = req.params;

        const project = await Project.findById(id);
        if (!project) {
            return res.status(404).json({
                success: false,
                message: 'Projet non trouvé'
            });
        }

        res.json({
            success: true,
            data: {
                id: project.id,
                title: project.title,
                downloads: project.download_count,
                views: project.view_count,
                createdAt: project.created_at
            }
        });
    } catch (error) {
        logger.error(`Erreur stats: ${error.message}`);
        res.status(500).json({
            success: false,
            message: 'Erreur'
        });
    }
});

module.exports = exports;
