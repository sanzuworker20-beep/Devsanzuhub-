/**
 * ================================================
 * CONTRÔLEUR MÉTHODES
 * ================================================
 * Gestion des méthodes privées payantes
 */

const Method = require('../models/Method');
const PaymentService = require('../services/paymentService');
const ActivityLog = require('../models/ActivityLog');
const { asyncHandler } = require('../middleware/errorHandler');
const logger = require('../config/logger');

// ============================================
// RÉCUPÉRATION DES MÉTHODES
// ============================================

/**
 * GET /api/methods
 * Lister toutes les méthodes publiées
 */
exports.getAllMethods = asyncHandler(async (req, res) => {
    try {
        const limit = parseInt(req.query.limit) || 20;
        const offset = parseInt(req.query.offset) || 0;

        const methods = await Method.getPublished(limit, offset);
        const total = await Method.countPublished();

        res.json({
            success: true,
            data: methods,
            pagination: {
                limit,
                offset,
                total,
                pages: Math.ceil(total / limit)
            }
        });
    } catch (error) {
        logger.error(`Erreur méthodes: ${error.message}`);
        res.status(500).json({
            success: false,
            message: 'Erreur'
        });
    }
});

/**
 * GET /api/methods/:id
 * Obtenir les détails d'une méthode
 */
exports.getMethodById = asyncHandler(async (req, res) => {
    try {
        const { id } = req.params;

        const method = await Method.findById(id);
        if (!method) {
            return res.status(404).json({
                success: false,
                message: 'Méthode non trouvée'
            });
        }

        // Ne pas retourner le contenu privé si l'utilisateur n'a pas accès
        const methodData = { ...method };
        if (req.user) {
            const hasAccess = await PaymentService.hasAccessToMethod(req.user.id, id);
            if (!hasAccess) {
                methodData.content = null;
                methodData.contact_info = null;
            }
        } else {
            methodData.content = null;
            methodData.contact_info = null;
        }

        // Incrémenter les vues
        await Method.incrementViewCount(id);

        res.json({
            success: true,
            data: methodData
        });
    } catch (error) {
        logger.error(`Erreur méthode: ${error.message}`);
        res.status(500).json({
            success: false,
            message: 'Erreur'
        });
    }
});

/**
 * GET /api/methods/search
 * Chercher des méthodes
 */
exports.searchMethods = asyncHandler(async (req, res) => {
    try {
        const { q } = req.query;
        const limit = parseInt(req.query.limit) || 20;
        const offset = parseInt(req.query.offset) || 0;

        if (!q || q.length < 2) {
            return res.status(400).json({
                success: false,
                message: 'Terme trop court'
            });
        }

        const results = await Method.search(q, limit, offset);

        res.json({
            success: true,
            data: results,
            searchTerm: q
        });
    } catch (error) {
        logger.error(`Erreur recherche: ${error.message}`);
        res.status(500).json({
            success: false,
            message: 'Erreur'
        });
    }
});

/**
 * GET /api/methods/popular
 * Méthodes populaires
 */
exports.getPopularMethods = asyncHandler(async (req, res) => {
    try {
        const limit = parseInt(req.query.limit) || 10;
        const methods = await Method.getPopular(limit);

        res.json({
            success: true,
            data: methods
        });
    } catch (error) {
        logger.error(`Erreur populaires: ${error.message}`);
        res.status(500).json({
            success: false,
            message: 'Erreur'
        });
    }
});

/**
 * GET /api/methods/:id/content
 * Obtenir le contenu privé d'une méthode (avec vérification d'accès)
 */
exports.getMethodContent = asyncHandler(async (req, res) => {
    try {
        if (!req.user) {
            return res.status(401).json({
                success: false,
                message: 'Authentification requise'
            });
        }

        const { id } = req.params;

        const content = await PaymentService.getMethodContent(req.user.id, id);

        res.json({
            success: true,
            data: {
                content: content.content,
                contactInfo: content.contact_info,
                contactEmail: content.contact_email,
                contactPhone: content.contact_phone
            }
        });
    } catch (error) {
        logger.error(`Erreur contenu: ${error.message}`);

        if (error.message.includes('n\'avez pas accès')) {
            return res.status(403).json({
                success: false,
                message: error.message
            });
        }

        res.status(500).json({
            success: false,
            message: 'Erreur'
        });
    }
});

// ============================================
// CRÉATION & MODIFICATION (ADMIN)
// ============================================

/**
 * POST /api/methods
 * Créer une nouvelle méthode (ADMIN)
 */
exports.createMethod = asyncHandler(async (req, res) => {
    try {
        const { 
            title, description, version, price, currency, 
            imageUrl, content, contactInfo, contactEmail, contactPhone 
        } = req.body;

        if (!title || !description || !price) {
            return res.status(400).json({
                success: false,
                message: 'Champs manquants'
            });
        }

        const method = await Method.create({
            title,
            description,
            version: version || '1.0.0',
            price,
            currency: currency || 'USD',
            imageUrl,
            content,
            contactInfo,
            contactEmail,
            contactPhone
        });

        await ActivityLog.create({
            userId: req.user.id,
            action: 'method_created',
            entityType: 'method',
            entityId: method.id,
            details: `Créée la méthode: ${title}`,
            ipAddress: req.ip
        });

        res.status(201).json({
            success: true,
            message: 'Méthode créée',
            data: method
        });
    } catch (error) {
        logger.error(`Erreur création: ${error.message}`);
        res.status(500).json({
            success: false,
            message: 'Erreur'
        });
    }
});

/**
 * PUT /api/methods/:id
 * Mettre à jour une méthode (ADMIN)
 */
exports.updateMethod = asyncHandler(async (req, res) => {
    try {
        const { id } = req.params;
        const { 
            title, description, version, price, currency, 
            imageUrl, content, contactInfo, isPublished, isActive 
        } = req.body;

        const method = await Method.findById(id);
        if (!method) {
            return res.status(404).json({
                success: false,
                message: 'Méthode non trouvée'
            });
        }

        const updated = await Method.update(id, {
            title,
            description,
            version,
            price,
            currency,
            imageUrl,
            content,
            contactInfo,
            isPublished,
            isActive
        });

        await ActivityLog.create({
            userId: req.user.id,
            action: 'method_updated',
            entityType: 'method',
            entityId: id,
            details: `Mise à jour: ${title || method.title}`,
            ipAddress: req.ip
        });

        res.json({
            success: true,
            message: 'Méthode mise à jour',
            data: updated
        });
    } catch (error) {
        logger.error(`Erreur mise à jour: ${error.message}`);
        res.status(500).json({
            success: false,
            message: 'Erreur'
        });
    }
});

/**
 * DELETE /api/methods/:id
 * Supprimer une méthode (ADMIN)
 */
exports.deleteMethod = asyncHandler(async (req, res) => {
    try {
        const { id } = req.params;

        const method = await Method.findById(id);
        if (!method) {
            return res.status(404).json({
                success: false,
                message: 'Méthode non trouvée'
            });
        }

        await Method.delete(id);

        await ActivityLog.create({
            userId: req.user.id,
            action: 'method_deleted',
            entityType: 'method',
            entityId: id,
            details: `Supprimée: ${method.title}`,
            ipAddress: req.ip
        });

        res.json({
            success: true,
            message: 'Méthode supprimée'
        });
    } catch (error) {
        logger.error(`Erreur suppression: ${error.message}`);
        res.status(500).json({
            success: false,
            message: 'Erreur'
        });
    }
});

/**
 * POST /api/methods/:id/publish
 * Publier/Dépublier une méthode (ADMIN)
 */
exports.togglePublish = asyncHandler(async (req, res) => {
    try {
        const { id } = req.params;
        const { isPublished } = req.body;

        const method = await Method.findById(id);
        if (!method) {
            return res.status(404).json({
                success: false,
                message: 'Méthode non trouvée'
            });
        }

        const updated = await Method.update(id, { isPublished });

        const action = isPublished ? 'Publiée' : 'Dépubliée';
        await ActivityLog.create({
            userId: req.user.id,
            action: `method_${isPublished ? 'published' : 'unpublished'}`,
            entityType: 'method',
            entityId: id,
            details: `${action}: ${method.title}`,
            ipAddress: req.ip
        });

        res.json({
            success: true,
            message: `Méthode ${isPublished ? 'publiée' : 'dépubliée'}`,
            data: updated
        });
    } catch (error) {
        logger.error(`Erreur publication: ${error.message}`);
        res.status(500).json({
            success: false,
            message: 'Erreur'
        });
    }
});

/**
 * GET /api/methods/:id/stats
 * Obtenir les statistiques d'une méthode (ADMIN)
 */
exports.getMethodStats = asyncHandler(async (req, res) => {
    try {
        const { id } = req.params;

        const method = await Method.findById(id);
        if (!method) {
            return res.status(404).json({
                success: false,
                message: 'Méthode non trouvée'
            });
        }

        res.json({
            success: true,
            data: {
                id: method.id,
                title: method.title,
                price: method.price,
                views: method.view_count,
                purchases: method.purchase_count,
                revenue: (method.price * method.purchase_count),
                createdAt: method.created_at
            }
        });
    } catch (error) {
        logger.error(`Erreur stats: ${error.message}`);
        res.status(500).json({
            success: false,
            message: 'Erreur'
        });
    }
});

module.exports = exports;
