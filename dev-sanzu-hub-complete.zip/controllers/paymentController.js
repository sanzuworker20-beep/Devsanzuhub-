/**
 * ================================================
 * CONTRÔLEUR PAIEMENTS
 * ================================================
 * Gestion des paiements avec validation manuelle
 */

const PaymentService = require('../services/paymentService');
const Payment = require('../models/Payment');
const Method = require('../models/Method');
const ActivityLog = require('../models/ActivityLog');
const { asyncHandler } = require('../middleware/errorHandler');
const logger = require('../config/logger');

// ============================================
// CRÉATION PAIEMENT
// ============================================

/**
 * POST /api/payments
 * Créer une demande de paiement
 */
exports.createPayment = asyncHandler(async (req, res) => {
    try {
        if (!req.user) {
            return res.status(401).json({
                success: false,
                message: 'Authentification requise'
            });
        }

        const { methodId, amount } = req.body;

        if (!methodId || !amount) {
            return res.status(400).json({
                success: false,
                message: 'Champs manquants'
            });
        }

        // Vérifier la méthode et le prix
        const method = await Method.findById(methodId);
        if (!method) {
            return res.status(404).json({
                success: false,
                message: 'Méthode non trouvée'
            });
        }

        if (amount !== method.price) {
            return res.status(400).json({
                success: false,
                message: 'Le montant ne correspond pas au prix'
            });
        }

        const payment = await PaymentService.createPayment(
            req.user.id,
            methodId,
            amount,
            req.ip
        );

        res.status(201).json({
            success: true,
            message: 'Paiement créé',
            data: payment
        });
    } catch (error) {
        logger.error(`Erreur création paiement: ${error.message}`);
        res.status(500).json({
            success: false,
            message: error.message || 'Erreur'
        });
    }
});

// ============================================
// CONSULTATION PAIEMENTS
// ============================================

/**
 * GET /api/payments/:id
 * Obtenir les détails d'un paiement
 */
exports.getPaymentById = asyncHandler(async (req, res) => {
    try {
        const { id } = req.params;

        const payment = await Payment.findById(id);
        if (!payment) {
            return res.status(404).json({
                success: false,
                message: 'Paiement non trouvé'
            });
        }

        // Vérifier que l'utilisateur peut voir ce paiement
        if (req.user && req.user.id !== payment.user_id && !req.user.is_admin) {
            return res.status(403).json({
                success: false,
                message: 'Accès refusé'
            });
        }

        res.json({
            success: true,
            data: payment
        });
    } catch (error) {
        logger.error(`Erreur récupération paiement: ${error.message}`);
        res.status(500).json({
            success: false,
            message: 'Erreur'
        });
    }
});

/**
 * GET /api/payments/user/me
 * Obtenir mes paiements
 */
exports.getMyPayments = asyncHandler(async (req, res) => {
    try {
        if (!req.user) {
            return res.status(401).json({
                success: false,
                message: 'Authentification requise'
            });
        }

        const limit = parseInt(req.query.limit) || 50;
        const offset = parseInt(req.query.offset) || 0;

        const payments = await PaymentService.getUserPayments(req.user.id, limit, offset);

        res.json({
            success: true,
            data: payments,
            pagination: {
                limit,
                offset
            }
        });
    } catch (error) {
        logger.error(`Erreur paiements utilisateur: ${error.message}`);
        res.status(500).json({
            success: false,
            message: 'Erreur'
        });
    }
});

/**
 * GET /api/payments/status/:status
 * Obtenir les paiements par statut (ADMIN)
 */
exports.getPaymentsByStatus = asyncHandler(async (req, res) => {
    try {
        const { status } = req.params;
        const limit = parseInt(req.query.limit) || 50;
        const offset = parseInt(req.query.offset) || 0;

        let payments;
        if (status === 'pending') {
            payments = await Payment.getPending(limit, offset);
        } else if (status === 'validated') {
            payments = await Payment.getValidated(limit, offset);
        } else {
            return res.status(400).json({
                success: false,
                message: 'Statut invalide'
            });
        }

        res.json({
            success: true,
            data: payments,
            status: status,
            pagination: {
                limit,
                offset
            }
        });
    } catch (error) {
        logger.error(`Erreur paiements par statut: ${error.message}`);
        res.status(500).json({
            success: false,
            message: 'Erreur'
        });
    }
});

// ============================================
// VALIDATION PAIEMENTS (ADMIN)
// ============================================

/**
 * POST /api/payments/:id/validate
 * Valider un paiement (ADMIN)
 */
exports.validatePayment = asyncHandler(async (req, res) => {
    try {
        const { id } = req.params;
        const { notes } = req.body;

        const validated = await PaymentService.validatePayment(
            id,
            req.user.id,
            notes || ''
        );

        res.json({
            success: true,
            message: 'Paiement validé et coordonnées débloquées',
            data: validated
        });
    } catch (error) {
        logger.error(`Erreur validation: ${error.message}`);
        
        if (error.message.includes('non trouvé')) {
            return res.status(404).json({
                success: false,
                message: error.message
            });
        }

        res.status(500).json({
            success: false,
            message: 'Erreur'
        });
    }
});

/**
 * POST /api/payments/:id/reject
 * Rejeter un paiement (ADMIN)
 */
exports.rejectPayment = asyncHandler(async (req, res) => {
    try {
        const { id } = req.params;
        const { reason } = req.body;

        if (!reason) {
            return res.status(400).json({
                success: false,
                message: 'Raison requise'
            });
        }

        const rejected = await PaymentService.rejectPayment(
            id,
            req.user.id,
            reason
        );

        res.json({
            success: true,
            message: 'Paiement rejeté',
            data: rejected
        });
    } catch (error) {
        logger.error(`Erreur rejet: ${error.message}`);

        if (error.message.includes('non trouvé')) {
            return res.status(404).json({
                success: false,
                message: error.message
            });
        }

        res.status(500).json({
            success: false,
            message: 'Erreur'
        });
    }
});

/**
 * POST /api/payments/:id/unlock-contact
 * Débloquer les coordonnées manuellement (ADMIN)
 */
exports.unlockContact = asyncHandler(async (req, res) => {
    try {
        const { id } = req.params;

        const payment = await Payment.findById(id);
        if (!payment) {
            return res.status(404).json({
                success: false,
                message: 'Paiement non trouvé'
            });
        }

        await Payment.unlockContact(id);

        await ActivityLog.create({
            userId: req.user.id,
            action: 'contact_unlocked_manual',
            entityType: 'payment',
            entityId: id,
            details: `Déblocage manuel des coordonnées`,
            ipAddress: req.ip
        });

        res.json({
            success: true,
            message: 'Coordonnées débloquées'
        });
    } catch (error) {
        logger.error(`Erreur déblocage: ${error.message}`);
        res.status(500).json({
            success: false,
            message: 'Erreur'
        });
    }
});

// ============================================
// STATISTIQUES PAIEMENTS (ADMIN)
// ============================================

/**
 * GET /api/payments/stats/overview
 * Obtenir les statistiques de paiement (ADMIN)
 */
exports.getPaymentStats = asyncHandler(async (req, res) => {
    try {
        const stats = await PaymentService.getPaymentStatistics();

        res.json({
            success: true,
            data: stats
        });
    } catch (error) {
        logger.error(`Erreur stats: ${error.message}`);
        res.status(500).json({
            success: false,
            message: 'Erreur'
        });
    }
});

/**
 * GET /api/payments/pending/count
 * Obtenir le nombre de paiements en attente (ADMIN)
 */
exports.getPendingCount = asyncHandler(async (req, res) => {
    try {
        const count = await Payment.countPending();

        res.json({
            success: true,
            pendingCount: count
        });
    } catch (error) {
        logger.error(`Erreur compte pending: ${error.message}`);
        res.status(500).json({
            success: false,
            message: 'Erreur'
        });
    }
});

// ============================================
// ACCÈS AUX MÉTHODES PAYANTES
// ============================================

/**
 * GET /api/payments/check-access/:methodId
 * Vérifier l'accès à une méthode
 */
exports.checkMethodAccess = asyncHandler(async (req, res) => {
    try {
        if (!req.user) {
            return res.json({
                success: true,
                hasAccess: false
            });
        }

        const { methodId } = req.params;

        const hasAccess = await PaymentService.hasAccessToMethod(
            req.user.id,
            methodId
        );

        res.json({
            success: true,
            hasAccess: hasAccess
        });
    } catch (error) {
        logger.error(`Erreur vérification accès: ${error.message}`);
        res.status(500).json({
            success: false,
            message: 'Erreur'
        });
    }
});

/**
 * POST /api/payments/send-reminders
 * Envoyer des rappels pour paiements en attente (ADMIN - tâche planifiée)
 */
exports.sendPaymentReminders = asyncHandler(async (req, res) => {
    try {
        await PaymentService.sendPendingReminders();

        res.json({
            success: true,
            message: 'Rappels envoyés'
        });
    } catch (error) {
        logger.error(`Erreur rappels: ${error.message}`);
        res.status(500).json({
            success: false,
            message: 'Erreur'
        });
    }
});

module.exports = exports;
