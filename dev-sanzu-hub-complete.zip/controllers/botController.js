/**
 * ================================================
 * CONTRÔLEUR BOTS
 * ================================================
 * Gestion des bots Telegram et WhatsApp
 */

const TelegramBot = require('../models/TelegramBot');
const WhatsAppBot = require('../models/WhatsAppBot');
const Download = require('../models/Download');
const ActivityLog = require('../models/ActivityLog');
const { asyncHandler } = require('../middleware/errorHandler');
const logger = require('../config/logger');
const fs = require('fs');

// ============================================
// BOTS TELEGRAM
// ============================================

/**
 * GET /api/bots/telegram
 * Lister tous les bots Telegram
 */
exports.getAllTelegramBots = asyncHandler(async (req, res) => {
    try {
        const limit = parseInt(req.query.limit) || 20;
        const offset = parseInt(req.query.offset) || 0;

        const bots = await TelegramBot.getAll(limit, offset);
        const total = await TelegramBot.count();

        res.json({
            success: true,
            data: bots,
            pagination: {
                limit,
                offset,
                total,
                pages: Math.ceil(total / limit)
            }
        });
    } catch (error) {
        logger.error(`Erreur bots telegram: ${error.message}`);
        res.status(500).json({
            success: false,
            message: 'Erreur'
        });
    }
});

/**
 * GET /api/bots/telegram/:id
 * Obtenir les détails d'un bot Telegram
 */
exports.getTelegramBotById = asyncHandler(async (req, res) => {
    try {
        const { id } = req.params;

        const bot = await TelegramBot.findById(id);
        if (!bot) {
            return res.status(404).json({
                success: false,
                message: 'Bot non trouvé'
            });
        }

        res.json({
            success: true,
            data: bot
        });
    } catch (error) {
        logger.error(`Erreur bot telegram: ${error.message}`);
        res.status(500).json({
            success: false,
            message: 'Erreur'
        });
    }
});

/**
 * GET /api/bots/telegram/search
 * Chercher des bots Telegram
 */
exports.searchTelegramBots = asyncHandler(async (req, res) => {
    try {
        const { q } = req.query;
        const limit = parseInt(req.query.limit) || 20;
        const offset = parseInt(req.query.offset) || 0;

        if (!q || q.length < 2) {
            return res.status(400).json({
                success: false,
                message: 'Terme trop court'
            });
        }

        const results = await TelegramBot.search(q, limit, offset);

        res.json({
            success: true,
            data: results,
            searchTerm: q
        });
    } catch (error) {
        logger.error(`Erreur recherche telegram: ${error.message}`);
        res.status(500).json({
            success: false,
            message: 'Erreur'
        });
    }
});

/**
 * GET /api/bots/telegram/popular
 * Bots Telegram populaires
 */
exports.getPopularTelegramBots = asyncHandler(async (req, res) => {
    try {
        const limit = parseInt(req.query.limit) || 10;
        const bots = await TelegramBot.getPopular(limit);

        res.json({
            success: true,
            data: bots
        });
    } catch (error) {
        logger.error(`Erreur populaires telegram: ${error.message}`);
        res.status(500).json({
            success: false,
            message: 'Erreur'
        });
    }
});

/**
 * POST /api/bots/telegram
 * Créer un bot Telegram (ADMIN)
 */
exports.createTelegramBot = asyncHandler(async (req, res) => {
    try {
        const { projectId, name, description, version, features, fileUrl, changelog } = req.body;

        if (!projectId || !name || !description) {
            return res.status(400).json({
                success: false,
                message: 'Champs manquants'
            });
        }

        // Obtenir les infos du fichier uploadé
        let filePath = null;
        let fileSize = 0;

        if (req.file) {
            filePath = req.file.path;
            fileSize = req.file.size;
        }

        const bot = await TelegramBot.create({
            projectId,
            name,
            description,
            version: version || '1.0.0',
            features,
            fileUrl: fileUrl || null,
            filePath,
            fileSize,
            changelog
        });

        await ActivityLog.create({
            userId: req.user.id,
            action: 'bot_created',
            entityType: 'bot',
            entityId: bot.id,
            details: `Créé bot telegram: ${name}`,
            ipAddress: req.ip
        });

        res.status(201).json({
            success: true,
            message: 'Bot créé',
            data: bot
        });
    } catch (error) {
        logger.error(`Erreur création bot: ${error.message}`);
        res.status(500).json({
            success: false,
            message: 'Erreur'
        });
    }
});

/**
 * PUT /api/bots/telegram/:id
 * Mettre à jour un bot Telegram (ADMIN)
 */
exports.updateTelegramBot = asyncHandler(async (req, res) => {
    try {
        const { id } = req.params;
        const { name, description, version, features, changelog } = req.body;

        const bot = await TelegramBot.findById(id);
        if (!bot) {
            return res.status(404).json({
                success: false,
                message: 'Bot non trouvé'
            });
        }

        const updated = await TelegramBot.update(id, {
            name,
            description,
            version,
            features,
            changelog
        });

        await ActivityLog.create({
            userId: req.user.id,
            action: 'bot_updated',
            entityType: 'bot',
            entityId: id,
            details: `Mis à jour bot: ${name || bot.name}`,
            ipAddress: req.ip
        });

        res.json({
            success: true,
            message: 'Bot mis à jour',
            data: updated
        });
    } catch (error) {
        logger.error(`Erreur mise à jour bot: ${error.message}`);
        res.status(500).json({
            success: false,
            message: 'Erreur'
        });
    }
});

/**
 * DELETE /api/bots/telegram/:id
 * Supprimer un bot Telegram (ADMIN)
 */
exports.deleteTelegramBot = asyncHandler(async (req, res) => {
    try {
        const { id } = req.params;

        const bot = await TelegramBot.findById(id);
        if (!bot) {
            return res.status(404).json({
                success: false,
                message: 'Bot non trouvé'
            });
        }

        // Supprimer le fichier
        if (bot.file_path && fs.existsSync(bot.file_path)) {
            fs.unlinkSync(bot.file_path);
        }

        await TelegramBot.delete(id);

        await ActivityLog.create({
            userId: req.user.id,
            action: 'bot_deleted',
            entityType: 'bot',
            entityId: id,
            details: `Supprimé bot: ${bot.name}`,
            ipAddress: req.ip
        });

        res.json({
            success: true,
            message: 'Bot supprimé'
        });
    } catch (error) {
        logger.error(`Erreur suppression bot: ${error.message}`);
        res.status(500).json({
            success: false,
            message: 'Erreur'
        });
    }
});

/**
 * GET /api/bots/telegram/:id/download
 * Télécharger un bot Telegram
 */
exports.downloadTelegramBot = asyncHandler(async (req, res) => {
    try {
        const { id } = req.params;

        const bot = await TelegramBot.findById(id);
        if (!bot) {
            return res.status(404).json({
                success: false,
                message: 'Bot non trouvé'
            });
        }

        // Enregistrer le téléchargement
        if (req.user) {
            await Download.create({
                userId: req.user.id,
                projectId: bot.project_id,
                botType: 'telegram',
                fileName: bot.name,
                fileSize: bot.file_size,
                ipAddress: req.ip
            });

            await ActivityLog.create({
                userId: req.user.id,
                action: 'bot_downloaded',
                entityType: 'bot',
                entityId: id,
                details: `Téléchargé: ${bot.name}`,
                ipAddress: req.ip
            });
        }

        // Incrémenter le compteur
        await TelegramBot.incrementDownloadCount(id);

        // Retourner l'URL de téléchargement
        res.json({
            success: true,
            message: 'Lien de téléchargement prêt',
            downloadUrl: bot.file_url,
            fileName: `${bot.name}.zip`
        });
    } catch (error) {
        logger.error(`Erreur téléchargement: ${error.message}`);
        res.status(500).json({
            success: false,
            message: 'Erreur'
        });
    }
});

// ============================================
// BOTS WHATSAPP (structure identique)
// ============================================

/**
 * GET /api/bots/whatsapp
 * Lister tous les bots WhatsApp
 */
exports.getAllWhatsAppBots = asyncHandler(async (req, res) => {
    try {
        const limit = parseInt(req.query.limit) || 20;
        const offset = parseInt(req.query.offset) || 0;

        const bots = await WhatsAppBot.getAll(limit, offset);
        const total = await WhatsAppBot.count();

        res.json({
            success: true,
            data: bots,
            pagination: {
                limit,
                offset,
                total,
                pages: Math.ceil(total / limit)
            }
        });
    } catch (error) {
        logger.error(`Erreur bots whatsapp: ${error.message}`);
        res.status(500).json({
            success: false,
            message: 'Erreur'
        });
    }
});

/**
 * GET /api/bots/whatsapp/:id
 * Obtenir les détails d'un bot WhatsApp
 */
exports.getWhatsAppBotById = asyncHandler(async (req, res) => {
    try {
        const { id } = req.params;

        const bot = await WhatsAppBot.findById(id);
        if (!bot) {
            return res.status(404).json({
                success: false,
                message: 'Bot non trouvé'
            });
        }

        res.json({
            success: true,
            data: bot
        });
    } catch (error) {
        logger.error(`Erreur bot whatsapp: ${error.message}`);
        res.status(500).json({
            success: false,
            message: 'Erreur'
        });
    }
});

/**
 * POST /api/bots/whatsapp
 * Créer un bot WhatsApp (ADMIN)
 */
exports.createWhatsAppBot = asyncHandler(async (req, res) => {
    try {
        const { projectId, name, description, version, features, fileUrl, changelog } = req.body;

        if (!projectId || !name || !description) {
            return res.status(400).json({
                success: false,
                message: 'Champs manquants'
            });
        }

        let filePath = null;
        let fileSize = 0;

        if (req.file) {
            filePath = req.file.path;
            fileSize = req.file.size;
        }

        const bot = await WhatsAppBot.create({
            projectId,
            name,
            description,
            version: version || '1.0.0',
            features,
            fileUrl: fileUrl || null,
            filePath,
            fileSize,
            changelog
        });

        await ActivityLog.create({
            userId: req.user.id,
            action: 'bot_created',
            entityType: 'bot',
            entityId: bot.id,
            details: `Créé bot whatsapp: ${name}`,
            ipAddress: req.ip
        });

        res.status(201).json({
            success: true,
            message: 'Bot créé',
            data: bot
        });
    } catch (error) {
        logger.error(`Erreur création bot: ${error.message}`);
        res.status(500).json({
            success: false,
            message: 'Erreur'
        });
    }
});

/**
 * GET /api/bots/whatsapp/:id/download
 * Télécharger un bot WhatsApp
 */
exports.downloadWhatsAppBot = asyncHandler(async (req, res) => {
    try {
        const { id } = req.params;

        const bot = await WhatsAppBot.findById(id);
        if (!bot) {
            return res.status(404).json({
                success: false,
                message: 'Bot non trouvé'
            });
        }

        if (req.user) {
            await Download.create({
                userId: req.user.id,
                projectId: bot.project_id,
                botType: 'whatsapp',
                fileName: bot.name,
                fileSize: bot.file_size,
                ipAddress: req.ip
            });

            await ActivityLog.create({
                userId: req.user.id,
                action: 'bot_downloaded',
                entityType: 'bot',
                entityId: id,
                details: `Téléchargé: ${bot.name}`,
                ipAddress: req.ip
            });
        }

        await WhatsAppBot.incrementDownloadCount(id);

        res.json({
            success: true,
            message: 'Lien de téléchargement prêt',
            downloadUrl: bot.file_url,
            fileName: `${bot.name}.zip`
        });
    } catch (error) {
        logger.error(`Erreur téléchargement: ${error.message}`);
        res.status(500).json({
            success: false,
            message: 'Erreur'
        });
    }
});

module.exports = exports;
