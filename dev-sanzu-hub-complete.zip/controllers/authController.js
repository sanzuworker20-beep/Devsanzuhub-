/**
 * ================================================
 * CONTRÔLEUR AUTHENTIFICATION
 * ================================================
 * Gestion de l'authentification et des comptes utilisateurs
 */

const AuthService = require('../services/authService');
const User = require('../models/User');
const ActivityLog = require('../models/ActivityLog');
const { asyncHandler } = require('../middleware/errorHandler');
const logger = require('../config/logger');

// ============================================
// INSCRIPTION
// ============================================

/**
 * POST /api/auth/register
 * Inscrire un nouvel utilisateur
 */
exports.register = asyncHandler(async (req, res) => {
    const { username, email, password, passwordConfirm, fullName } = req.body;

    // Vérification basique
    if (!username || !email || !password || !passwordConfirm) {
        return res.status(400).json({
            success: false,
            message: 'Tous les champs sont requis'
        });
    }

    // Vérifier la confirmation du mot de passe
    if (password !== passwordConfirm) {
        return res.status(400).json({
            success: false,
            message: 'Les mots de passe ne correspondent pas'
        });
    }

    try {
        // Utiliser le service pour l'inscription
        const result = await AuthService.register(
            { username, email, password, fullName },
            req.ip
        );

        // Stocker l'ID utilisateur en session
        req.session.userId = result.user.id;

        res.status(201).json({
            success: true,
            message: 'Inscription réussie',
            user: result.user,
            token: result.token
        });
    } catch (error) {
        logger.error(`Erreur inscription: ${error.message}`);
        
        // Vérifier si c'est un erreur d'email/username déjà existant
        if (error.message.includes('exists') || error.message.includes('pris')) {
            return res.status(409).json({
                success: false,
                message: error.message
            });
        }

        res.status(500).json({
            success: false,
            message: 'Erreur lors de l\'inscription'
        });
    }
});

// ============================================
// CONNEXION
// ============================================

/**
 * POST /api/auth/login
 * Connecter un utilisateur
 */
exports.login = asyncHandler(async (req, res) => {
    const { email, password } = req.body;

    // Vérification
    if (!email || !password) {
        return res.status(400).json({
            success: false,
            message: 'Email et mot de passe requis'
        });
    }

    try {
        // Utiliser le service pour la connexion
        const result = await AuthService.login(email, password, req.ip);

        // Stocker l'ID utilisateur en session
        req.session.userId = result.user.id;

        res.json({
            success: true,
            message: 'Connexion réussie',
            user: result.user,
            token: result.token
        });
    } catch (error) {
        logger.warn(`Tentative connexion échouée: ${email} - ${error.message}`);

        res.status(401).json({
            success: false,
            message: error.message || 'Email ou mot de passe incorrect'
        });
    }
});

// ============================================
// DÉCONNEXION
// ============================================

/**
 * POST /api/auth/logout
 * Déconnecter l'utilisateur
 */
exports.logout = asyncHandler(async (req, res) => {
    try {
        const userId = req.user?.id;

        if (userId) {
            await AuthService.logout(userId, req.ip);
        }

        // Détruire la session
        req.session.destroy((err) => {
            if (err) {
                logger.error(`Erreur destruction session: ${err.message}`);
            }
        });

        res.json({
            success: true,
            message: 'Déconnexion réussie'
        });
    } catch (error) {
        logger.error(`Erreur déconnexion: ${error.message}`);
        
        res.json({
            success: true,
            message: 'Déconnexion'
        });
    }
});

// ============================================
// PROFIL UTILISATEUR
// ============================================

/**
 * GET /api/auth/me
 * Obtenir les infos de l'utilisateur connecté
 */
exports.getCurrentUser = asyncHandler(async (req, res) => {
    try {
        if (!req.user) {
            return res.status(401).json({
                success: false,
                message: 'Non authentifié'
            });
        }

        const user = await AuthService.getCurrentUser(req.user.id);

        res.json({
            success: true,
            user: user
        });
    } catch (error) {
        logger.error(`Erreur récupération utilisateur: ${error.message}`);

        res.status(500).json({
            success: false,
            message: 'Erreur'
        });
    }
});

/**
 * PUT /api/auth/profile
 * Mettre à jour le profil
 */
exports.updateProfile = asyncHandler(async (req, res) => {
    try {
        if (!req.user) {
            return res.status(401).json({
                success: false,
                message: 'Non authentifié'
            });
        }

        const { fullName, bio, phoneNumber, contactInfo } = req.body;

        const updated = await User.update(req.user.id, {
            fullName,
            bio,
            phoneNumber,
            contactInfo
        });

        res.json({
            success: true,
            message: 'Profil mis à jour',
            user: updated
        });
    } catch (error) {
        logger.error(`Erreur mise à jour profil: ${error.message}`);

        res.status(500).json({
            success: false,
            message: 'Erreur'
        });
    }
});

/**
 * POST /api/auth/change-password
 * Changer le mot de passe
 */
exports.changePassword = asyncHandler(async (req, res) => {
    try {
        if (!req.user) {
            return res.status(401).json({
                success: false,
                message: 'Non authentifié'
            });
        }

        const { oldPassword, newPassword, confirmPassword } = req.body;

        // Vérifier les champs
        if (!oldPassword || !newPassword || !confirmPassword) {
            return res.status(400).json({
                success: false,
                message: 'Tous les champs sont requis'
            });
        }

        // Vérifier la confirmation
        if (newPassword !== confirmPassword) {
            return res.status(400).json({
                success: false,
                message: 'Les mots de passe ne correspondent pas'
            });
        }

        await AuthService.changePassword(req.user.id, oldPassword, newPassword, req.ip);

        res.json({
            success: true,
            message: 'Mot de passe changé avec succès'
        });
    } catch (error) {
        logger.error(`Erreur changement mot de passe: ${error.message}`);

        res.status(400).json({
            success: false,
            message: error.message || 'Erreur'
        });
    }
});

// ============================================
// TOKEN & SESSION
// ============================================

/**
 * POST /api/auth/refresh-token
 * Rafraîchir le token JWT
 */
exports.refreshToken = asyncHandler(async (req, res) => {
    try {
        if (!req.user) {
            return res.status(401).json({
                success: false,
                message: 'Non authentifié'
            });
        }

        const token = await AuthService.refreshToken(req.user.id);

        res.json({
            success: true,
            token: token
        });
    } catch (error) {
        logger.error(`Erreur refresh token: ${error.message}`);

        res.status(401).json({
            success: false,
            message: 'Erreur'
        });
    }
});

/**
 * POST /api/auth/verify-email
 * Vérifier l'email (pour les futures implémentations)
 */
exports.verifyEmail = asyncHandler(async (req, res) => {
    try {
        if (!req.user) {
            return res.status(401).json({
                success: false,
                message: 'Non authentifié'
            });
        }

        await AuthService.verifyEmail(req.user.id);

        res.json({
            success: true,
            message: 'Email vérifié'
        });
    } catch (error) {
        logger.error(`Erreur vérification email: ${error.message}`);

        res.status(500).json({
            success: false,
            message: 'Erreur'
        });
    }
});

// ============================================
// PASSWORD RESET (Future)
// ============================================

/**
 * POST /api/auth/forgot-password
 * Demander une réinitialisation de mot de passe
 */
exports.forgotPassword = asyncHandler(async (req, res) => {
    try {
        const { email } = req.body;

        if (!email) {
            return res.status(400).json({
                success: false,
                message: 'Email requis'
            });
        }

        // Pour la sécurité, toujours retourner le même message
        res.json({
            success: true,
            message: 'Si cet email existe dans notre système, vous recevrez un lien de réinitialisation'
        });
    } catch (error) {
        logger.error(`Erreur forgot password: ${error.message}`);

        res.json({
            success: true,
            message: 'Si cet email existe dans notre système, vous recevrez un lien de réinitialisation'
        });
    }
});

/**
 * POST /api/auth/reset-password
 * Réinitialiser le mot de passe avec token
 */
exports.resetPassword = asyncHandler(async (req, res) => {
    try {
        const { resetToken, newPassword, confirmPassword } = req.body;

        if (!resetToken || !newPassword || !confirmPassword) {
            return res.status(400).json({
                success: false,
                message: 'Tous les champs sont requis'
            });
        }

        if (newPassword !== confirmPassword) {
            return res.status(400).json({
                success: false,
                message: 'Les mots de passe ne correspondent pas'
            });
        }

        await AuthService.completePasswordReset(resetToken, newPassword);

        res.json({
            success: true,
            message: 'Mot de passe réinitialisé'
        });
    } catch (error) {
        logger.error(`Erreur reset password: ${error.message}`);

        res.status(400).json({
            success: false,
            message: error.message || 'Erreur'
        });
    }
});

// ============================================
// INFORMATION SESSION
// ============================================

/**
 * GET /api/auth/check
 * Vérifier si l'utilisateur est authentifié
 */
exports.checkAuth = asyncHandler(async (req, res) => {
    const isAuthenticated = !!req.user;

    res.json({
        success: true,
        authenticated: isAuthenticated,
        user: isAuthenticated ? req.user : null
    });
});

module.exports = exports;
