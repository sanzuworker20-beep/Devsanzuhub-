/**
 * ================================================
 * CONTRÔLEUR NOTIFICATIONS
 * ================================================
 * Gestion des notifications utilisateur
 */

const Notification = require('../models/Notification');
const NotificationService = require('../services/notificationService');
const { asyncHandler } = require('../middleware/errorHandler');
const logger = require('../config/logger');

// ============================================
// NOTIFICATIONS UTILISATEUR
// ============================================

/**
 * GET /api/notifications
 * Obtenir mes notifications
 */
exports.getMyNotifications = asyncHandler(async (req, res) => {
    try {
        const limit = parseInt(req.query.limit) || 50;
        const offset = parseInt(req.query.offset) || 0;

        const notifications = await Notification.getByUser(req.user.id, limit, offset);

        res.json({
            success: true,
            data: notifications,
            pagination: {
                limit,
                offset
            }
        });
    } catch (error) {
        logger.error(`Erreur notifications: ${error.message}`);
        res.status(500).json({
            success: false,
            message: 'Erreur'
        });
    }
});

/**
 * GET /api/notifications/unread
 * Obtenir les notifications non lues
 */
exports.getUnreadNotifications = asyncHandler(async (req, res) => {
    try {
        const notifications = await NotificationService.getUnreadNotifications(req.user.id);

        res.json({
            success: true,
            data: notifications
        });
    } catch (error) {
        logger.error(`Erreur non lues: ${error.message}`);
        res.status(500).json({
            success: false,
            message: 'Erreur'
        });
    }
});

/**
 * GET /api/notifications/unread/count
 * Obtenir le nombre de notifications non lues
 */
exports.getUnreadCount = asyncHandler(async (req, res) => {
    try {
        const count = await NotificationService.getUnreadCount(req.user.id);

        res.json({
            success: true,
            unreadCount: count
        });
    } catch (error) {
        logger.error(`Erreur compte: ${error.message}`);
        res.status(500).json({
            success: false,
            message: 'Erreur'
        });
    }
});

/**
 * POST /api/notifications/:id/read
 * Marquer une notification comme lue
 */
exports.markAsRead = asyncHandler(async (req, res) => {
    try {
        const { id } = req.params;

        const notification = await Notification.findById(id);
        if (!notification) {
            return res.status(404).json({
                success: false,
                message: 'Notification non trouvée'
            });
        }

        // Vérifier que c'est la notification de l'utilisateur
        if (notification.user_id !== req.user.id) {
            return res.status(403).json({
                success: false,
                message: 'Accès refusé'
            });
        }

        await NotificationService.markAsRead(id);

        res.json({
            success: true,
            message: 'Marquée comme lue'
        });
    } catch (error) {
        logger.error(`Erreur marquage: ${error.message}`);
        res.status(500).json({
            success: false,
            message: 'Erreur'
        });
    }
});

/**
 * POST /api/notifications/mark-all-read
 * Marquer toutes les notifications comme lues
 */
exports.markAllAsRead = asyncHandler(async (req, res) => {
    try {
        await NotificationService.markAllAsRead(req.user.id);

        res.json({
            success: true,
            message: 'Toutes marquées comme lues'
        });
    } catch (error) {
        logger.error(`Erreur marquage all: ${error.message}`);
        res.status(500).json({
            success: false,
            message: 'Erreur'
        });
    }
});

/**
 * DELETE /api/notifications/:id
 * Supprimer une notification
 */
exports.deleteNotification = asyncHandler(async (req, res) => {
    try {
        const { id } = req.params;

        const notification = await Notification.findById(id);
        if (!notification) {
            return res.status(404).json({
                success: false,
                message: 'Notification non trouvée'
            });
        }

        // Vérifier que c'est la notification de l'utilisateur
        if (notification.user_id !== req.user.id) {
            return res.status(403).json({
                success: false,
                message: 'Accès refusé'
            });
        }

        await NotificationService.deleteNotification(id);

        res.json({
            success: true,
            message: 'Supprimée'
        });
    } catch (error) {
        logger.error(`Erreur suppression: ${error.message}`);
        res.status(500).json({
            success: false,
            message: 'Erreur'
        });
    }
});

/**
 * DELETE /api/notifications/cleanup
 * Nettoyer les notifications lues
 */
exports.cleanupReadNotifications = asyncHandler(async (req, res) => {
    try {
        await NotificationService.cleanupReadNotifications(req.user.id);

        res.json({
            success: true,
            message: 'Nettoyé'
        });
    } catch (error) {
        logger.error(`Erreur nettoyage: ${error.message}`);
        res.status(500).json({
            success: false,
            message: 'Erreur'
        });
    }
});

module.exports = exports;
