/**
 * ================================================
 * CONTRÔLEUR UTILISATEURS
 * ================================================
 * Gestion des utilisateurs et comptes
 */

const User = require('../models/User');
const Download = require('../models/Download');
const ActivityLog = require('../models/ActivityLog');
const { asyncHandler } = require('../middleware/errorHandler');
const logger = require('../config/logger');

// ============================================
// PROFILS UTILISATEURS
// ============================================

/**
 * GET /api/users/:id
 * Obtenir le profil d'un utilisateur
 */
exports.getUserProfile = asyncHandler(async (req, res) => {
    try {
        const { id } = req.params;

        const user = await User.findById(id);
        if (!user) {
            return res.status(404).json({
                success: false,
                message: 'Utilisateur non trouvé'
            });
        }

        // Ne pas exposer les infos sensibles
        const safeUser = {
            id: user.id,
            username: user.username,
            fullName: user.full_name,
            bio: user.bio,
            avatarUrl: user.avatar_url,
            createdAt: user.created_at
        };

        res.json({
            success: true,
            data: safeUser
        });
    } catch (error) {
        logger.error(`Erreur profil: ${error.message}`);
        res.status(500).json({
            success: false,
            message: 'Erreur'
        });
    }
});

/**
 * GET /api/users/:id/downloads
 * Obtenir l'historique de téléchargements d'un utilisateur
 */
exports.getUserDownloads = asyncHandler(async (req, res) => {
    try {
        const { id } = req.params;
        const limit = parseInt(req.query.limit) || 50;
        const offset = parseInt(req.query.offset) || 0;

        // Vérifier que l'utilisateur consultent ses propres données ou admin
        if (req.user && req.user.id !== id && !req.user.is_admin) {
            return res.status(403).json({
                success: false,
                message: 'Accès refusé'
            });
        }

        const downloads = await Download.getByUser(id, limit, offset);

        res.json({
            success: true,
            data: downloads,
            pagination: {
                limit,
                offset
            }
        });
    } catch (error) {
        logger.error(`Erreur téléchargements: ${error.message}`);
        res.status(500).json({
            success: false,
            message: 'Erreur'
        });
    }
});

// ============================================
// GESTION UTILISATEURS (ADMIN)
// ============================================

/**
 * GET /api/users
 * Lister tous les utilisateurs (ADMIN)
 */
exports.getAllUsers = asyncHandler(async (req, res) => {
    try {
        const limit = parseInt(req.query.limit) || 50;
        const offset = parseInt(req.query.offset) || 0;

        const users = await User.getAll(limit, offset);
        const total = await User.count();

        res.json({
            success: true,
            data: users,
            pagination: {
                limit,
                offset,
                total,
                pages: Math.ceil(total / limit)
            }
        });
    } catch (error) {
        logger.error(`Erreur utilisateurs: ${error.message}`);
        res.status(500).json({
            success: false,
            message: 'Erreur'
        });
    }
});

/**
 * POST /api/users/:id/ban
 * Bannir un utilisateur (ADMIN)
 */
exports.banUser = asyncHandler(async (req, res) => {
    try {
        const { id } = req.params;

        const user = await User.findById(id);
        if (!user) {
            return res.status(404).json({
                success: false,
                message: 'Utilisateur non trouvé'
            });
        }

        await User.ban(id);

        await ActivityLog.create({
            userId: req.user.id,
            action: 'user_banned',
            entityType: 'user',
            entityId: id,
            details: `Utilisateur banni: ${user.username}`,
            ipAddress: req.ip
        });

        res.json({
            success: true,
            message: 'Utilisateur banni'
        });
    } catch (error) {
        logger.error(`Erreur bannissement: ${error.message}`);
        res.status(500).json({
            success: false,
            message: 'Erreur'
        });
    }
});

/**
 * POST /api/users/:id/unban
 * Débannir un utilisateur (ADMIN)
 */
exports.unbanUser = asyncHandler(async (req, res) => {
    try {
        const { id } = req.params;

        const user = await User.findById(id);
        if (!user) {
            return res.status(404).json({
                success: false,
                message: 'Utilisateur non trouvé'
            });
        }

        await User.unban(id);

        await ActivityLog.create({
            userId: req.user.id,
            action: 'user_unbanned',
            entityType: 'user',
            entityId: id,
            details: `Utilisateur débanni: ${user.username}`,
            ipAddress: req.ip
        });

        res.json({
            success: true,
            message: 'Utilisateur débanni'
        });
    } catch (error) {
        logger.error(`Erreur débannissement: ${error.message}`);
        res.status(500).json({
            success: false,
            message: 'Erreur'
        });
    }
});

/**
 * POST /api/users/:id/make-admin
 * Rendre un utilisateur administrateur (ADMIN)
 */
exports.makeAdmin = asyncHandler(async (req, res) => {
    try {
        const { id } = req.params;

        const user = await User.findById(id);
        if (!user) {
            return res.status(404).json({
                success: false,
                message: 'Utilisateur non trouvé'
            });
        }

        await User.makeAdmin(id);

        await ActivityLog.create({
            userId: req.user.id,
            action: 'user_promoted',
            entityType: 'user',
            entityId: id,
            details: `Utilisateur promu administrateur: ${user.username}`,
            ipAddress: req.ip
        });

        res.json({
            success: true,
            message: 'Utilisateur promu administrateur'
        });
    } catch (error) {
        logger.error(`Erreur promotion: ${error.message}`);
        res.status(500).json({
            success: false,
            message: 'Erreur'
        });
    }
});

/**
 * DELETE /api/users/:id
 * Supprimer un utilisateur (ADMIN)
 */
exports.deleteUser = asyncHandler(async (req, res) => {
    try {
        const { id } = req.params;

        const user = await User.findById(id);
        if (!user) {
            return res.status(404).json({
                success: false,
                message: 'Utilisateur non trouvé'
            });
        }

        // Ne pas pouvoir se supprimer soi-même
        if (req.user.id === id) {
            return res.status(400).json({
                success: false,
                message: 'Vous ne pouvez pas supprimer votre propre compte'
            });
        }

        await User.delete(id);

        await ActivityLog.create({
            userId: req.user.id,
            action: 'user_deleted',
            entityType: 'user',
            entityId: id,
            details: `Utilisateur supprimé: ${user.username}`,
            ipAddress: req.ip
        });

        res.json({
            success: true,
            message: 'Utilisateur supprimé'
        });
    } catch (error) {
        logger.error(`Erreur suppression: ${error.message}`);
        res.status(500).json({
            success: false,
            message: 'Erreur'
        });
    }
});

/**
 * GET /api/users/stats/overview
 * Obtenir les statistiques utilisateurs (ADMIN)
 */
exports.getUserStats = asyncHandler(async (req, res) => {
    try {
        const totalUsers = await User.count();

        res.json({
            success: true,
            data: {
                totalUsers: totalUsers
            }
        });
    } catch (error) {
        logger.error(`Erreur stats utilisateurs: ${error.message}`);
        res.status(500).json({
            success: false,
            message: 'Erreur'
        });
    }
});

module.exports = exports;
