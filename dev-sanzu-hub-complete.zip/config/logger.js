/**
 * ================================================
 * CONFIGURATION DU LOGGER
 * ================================================
 * Gestion des logs et journalisation des événements
 */

const fs = require('fs');
const path = require('path');

// Créer le dossier logs s'il n'existe pas
const logDir = path.join(__dirname, '..', 'logs');
if (!fs.existsSync(logDir)) {
    fs.mkdirSync(logDir, { recursive: true });
}

/**
 * Nivaux de log
 */
const LOG_LEVELS = {
    ERROR: 0,
    WARN: 1,
    INFO: 2,
    DEBUG: 3
};

/**
 * Obtenir le niveau de log depuis l'environnement
 */
const currentLogLevel = LOG_LEVELS[process.env.LOG_LEVEL?.toUpperCase()] || LOG_LEVELS.INFO;

/**
 * Formater la date et l'heure
 * @param {Date} date - La date à formater
 * @returns {string} Date formatée
 */
function formatDateTime(date) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');
    const seconds = String(date.getSeconds()).padStart(2, '0');
    return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
}

/**
 * Écrire un log dans un fichier
 * @param {string} level - Niveau du log
 * @param {string} message - Message du log
 */
function writeLogFile(level, message) {
    const date = new Date();
    const dateStr = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
    const logFile = path.join(logDir, `${dateStr}.log`);
    
    const logEntry = `[${formatDateTime(date)}] [${level}] ${message}\n`;
    
    fs.appendFileSync(logFile, logEntry, 'utf-8');
}

/**
 * Logger une erreur
 * @param {string} message - Message d'erreur
 */
function error(message) {
    if (currentLogLevel >= LOG_LEVELS.ERROR) {
        const timestamp = formatDateTime(new Date());
        const logMessage = `\x1b[31m[${timestamp}] [ERROR] ${message}\x1b[0m`;
        console.error(logMessage);
        writeLogFile('ERROR', message);
    }
}

/**
 * Logger un avertissement
 * @param {string} message - Message d'avertissement
 */
function warn(message) {
    if (currentLogLevel >= LOG_LEVELS.WARN) {
        const timestamp = formatDateTime(new Date());
        const logMessage = `\x1b[33m[${timestamp}] [WARN] ${message}\x1b[0m`;
        console.warn(logMessage);
        writeLogFile('WARN', message);
    }
}

/**
 * Logger une information
 * @param {string} message - Message d'information
 */
function info(message) {
    if (currentLogLevel >= LOG_LEVELS.INFO) {
        const timestamp = formatDateTime(new Date());
        const logMessage = `\x1b[36m[${timestamp}] [INFO] ${message}\x1b[0m`;
        console.log(logMessage);
        writeLogFile('INFO', message);
    }
}

/**
 * Logger un message de débogage
 * @param {string} message - Message de débogage
 */
function debug(message) {
    if (currentLogLevel >= LOG_LEVELS.DEBUG) {
        const timestamp = formatDateTime(new Date());
        const logMessage = `\x1b[35m[${timestamp}] [DEBUG] ${message}\x1b[0m`;
        console.log(logMessage);
        writeLogFile('DEBUG', message);
    }
}

/**
 * Logger l'activité d'un utilisateur
 * @param {string} userId - ID de l'utilisateur
 * @param {string} action - Action effectuée
 * @param {string} details - Détails de l'action
 */
function logActivity(userId, action, details = '') {
    const message = `User: ${userId} | Action: ${action} | Details: ${details}`;
    info(message);
    writeLogFile('ACTIVITY', message);
}

// Exporter les fonctions
module.exports = {
    error,
    warn,
    info,
    debug,
    logActivity
};
