/**
 * ================================================
 * CONFIGURATION BASE DE DONNÉES
 * ================================================
 * Gestion de la connexion et du pool PostgreSQL
 * Initialisation des tables et schémas
 */

const { Pool } = require('pg');
const logger = require('./logger');

// Configuration du pool de connexions PostgreSQL
const pool = new Pool({
    host: process.env.DB_HOST || 'localhost',
    port: process.env.DB_PORT || 5432,
    user: process.env.DB_USER || 'devsanzu',
    password: process.env.DB_PASSWORD || 'password',
    database: process.env.DB_NAME || 'devsanzu_hub'
});

/**
 * Vérifier la connexion à la base de données
 * @returns {Promise<void>}
 */
async function checkDatabaseConnection() {
    try {
        const client = await pool.connect();
        await client.query('SELECT NOW()');
        client.release();
        return true;
    } catch (error) {
        logger.error(`Erreur de connexion BDD: ${error.message}`);
        throw error;
    }
}

/**
 * Initialiser les tables de la base de données
 * Crée tous les schémas nécessaires au fonctionnement
 */
async function initDatabase() {
    const client = await pool.connect();
    
    try {
        // Commencer la transaction
        await client.query('BEGIN');

        // ============================================
        // TABLE UTILISATEURS
        // ============================================
        await client.query(`
            CREATE TABLE IF NOT EXISTS users (
                id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                username VARCHAR(255) UNIQUE NOT NULL,
                email VARCHAR(255) UNIQUE NOT NULL,
                password_hash VARCHAR(255) NOT NULL,
                full_name VARCHAR(255),
                bio TEXT,
                avatar_url VARCHAR(500),
                is_admin BOOLEAN DEFAULT FALSE,
                is_banned BOOLEAN DEFAULT FALSE,
                email_verified BOOLEAN DEFAULT FALSE,
                verification_token VARCHAR(255),
                phone_number VARCHAR(20),
                contact_info TEXT,
                is_contact_locked BOOLEAN DEFAULT TRUE,
                unlocked_at TIMESTAMP,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        `);
        logger.info('✓ Table users créée');

        // ============================================
        // TABLE SESSIONS
        // ============================================
        await client.query(`
            CREATE TABLE IF NOT EXISTS sessions (
                sid VARCHAR NOT NULL COLLATE "default" PRIMARY KEY,
                sess JSON NOT NULL,
                expire TIMESTAMP NOT NULL
            )
        `);
        logger.info('✓ Table sessions créée');

        // ============================================
        // TABLE PROJETS
        // ============================================
        await client.query(`
            CREATE TABLE IF NOT EXISTS projects (
                id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                title VARCHAR(255) NOT NULL,
                description TEXT NOT NULL,
                category VARCHAR(50) NOT NULL,
                version VARCHAR(50),
                author_id UUID REFERENCES users(id),
                image_url VARCHAR(500),
                is_published BOOLEAN DEFAULT FALSE,
                download_count INTEGER DEFAULT 0,
                view_count INTEGER DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        `);
        logger.info('✓ Table projects créée');

        // ============================================
        // TABLE BOTS TELEGRAM
        // ============================================
        await client.query(`
            CREATE TABLE IF NOT EXISTS telegram_bots (
                id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                project_id UUID REFERENCES projects(id) ON DELETE CASCADE,
                name VARCHAR(255) NOT NULL,
                description TEXT,
                version VARCHAR(50),
                features TEXT,
                is_free BOOLEAN DEFAULT TRUE,
                file_url VARCHAR(500),
                file_path VARCHAR(500),
                file_size BIGINT,
                changelog TEXT,
                download_count INTEGER DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        `);
        logger.info('✓ Table telegram_bots créée');

        // ============================================
        // TABLE BOTS WHATSAPP
        // ============================================
        await client.query(`
            CREATE TABLE IF NOT EXISTS whatsapp_bots (
                id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                project_id UUID REFERENCES projects(id) ON DELETE CASCADE,
                name VARCHAR(255) NOT NULL,
                description TEXT,
                version VARCHAR(50),
                features TEXT,
                is_free BOOLEAN DEFAULT TRUE,
                file_url VARCHAR(500),
                file_path VARCHAR(500),
                file_size BIGINT,
                changelog TEXT,
                download_count INTEGER DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        `);
        logger.info('✓ Table whatsapp_bots créée');

        // ============================================
        // TABLE MÉTHODES (PRODUITS PAYANTS)
        // ============================================
        await client.query(`
            CREATE TABLE IF NOT EXISTS methods (
                id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                title VARCHAR(255) NOT NULL,
                description TEXT NOT NULL,
                version VARCHAR(50),
                price DECIMAL(10, 2) NOT NULL,
                currency VARCHAR(3) DEFAULT 'USD',
                image_url VARCHAR(500),
                is_published BOOLEAN DEFAULT FALSE,
                is_active BOOLEAN DEFAULT TRUE,
                content TEXT,
                contact_info TEXT,
                contact_email VARCHAR(255),
                contact_phone VARCHAR(20),
                view_count INTEGER DEFAULT 0,
                purchase_count INTEGER DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        `);
        logger.info('✓ Table methods créée');

        // ============================================
        // TABLE PAIEMENTS
        // ============================================
        await client.query(`
            CREATE TABLE IF NOT EXISTS payments (
                id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                user_id UUID REFERENCES users(id),
                method_id UUID REFERENCES methods(id),
                amount DECIMAL(10, 2) NOT NULL,
                currency VARCHAR(3) DEFAULT 'USD',
                status VARCHAR(50) DEFAULT 'pending',
                payment_method VARCHAR(50),
                transaction_id VARCHAR(255),
                notes TEXT,
                is_validated BOOLEAN DEFAULT FALSE,
                validation_notes TEXT,
                validated_by UUID REFERENCES users(id),
                validated_at TIMESTAMP,
                contact_unlocked BOOLEAN DEFAULT FALSE,
                unlocked_at TIMESTAMP,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        `);
        logger.info('✓ Table payments créée');

        // ============================================
        // TABLE NOTIFICATIONS
        // ============================================
        await client.query(`
            CREATE TABLE IF NOT EXISTS notifications (
                id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                user_id UUID REFERENCES users(id),
                type VARCHAR(100) NOT NULL,
                title VARCHAR(255) NOT NULL,
                message TEXT NOT NULL,
                related_id UUID,
                is_read BOOLEAN DEFAULT FALSE,
                read_at TIMESTAMP,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        `);
        logger.info('✓ Table notifications créée');

        // ============================================
        // TABLE TÉLÉCHARGEMENTS
        // ============================================
        await client.query(`
            CREATE TABLE IF NOT EXISTS downloads (
                id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                user_id UUID REFERENCES users(id),
                project_id UUID REFERENCES projects(id),
                bot_type VARCHAR(50),
                file_name VARCHAR(255),
                file_size BIGINT,
                ip_address VARCHAR(45),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        `);
        logger.info('✓ Table downloads créée');

        // ============================================
        // TABLE LOGS D'ACTIVITÉ
        // ============================================
        await client.query(`
            CREATE TABLE IF NOT EXISTS activity_logs (
                id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                user_id UUID REFERENCES users(id),
                action VARCHAR(255) NOT NULL,
                entity_type VARCHAR(100),
                entity_id VARCHAR(255),
                details TEXT,
                ip_address VARCHAR(45),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        `);
        logger.info('✓ Table activity_logs créée');

        // ============================================
        // TABLE STATISTIQUES GLOBALES
        // ============================================
        await client.query(`
            CREATE TABLE IF NOT EXISTS statistics (
                id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                total_users INTEGER DEFAULT 0,
                total_downloads INTEGER DEFAULT 0,
                total_revenue DECIMAL(15, 2) DEFAULT 0,
                total_projects INTEGER DEFAULT 0,
                total_methods_sold INTEGER DEFAULT 0,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        `);
        logger.info('✓ Table statistics créée');

        // ============================================
        // TABLE PARAMÈTRES DU SITE
        // ============================================
        await client.query(`
            CREATE TABLE IF NOT EXISTS settings (
                id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                setting_key VARCHAR(255) UNIQUE NOT NULL,
                setting_value TEXT,
                setting_type VARCHAR(50),
                description TEXT,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        `);
        logger.info('✓ Table settings créée');

        // ============================================
        // CRÉER LES INDEX
        // ============================================
        
        // Index pour les recherches utilisateurs
        await client.query(`
            CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
            CREATE INDEX IF NOT EXISTS idx_users_username ON users(username);
        `);

        // Index pour les recherches de projets
        await client.query(`
            CREATE INDEX IF NOT EXISTS idx_projects_category ON projects(category);
            CREATE INDEX IF NOT EXISTS idx_projects_author ON projects(author_id);
        `);

        // Index pour les recherches de paiements
        await client.query(`
            CREATE INDEX IF NOT EXISTS idx_payments_user ON payments(user_id);
            CREATE INDEX IF NOT EXISTS idx_payments_status ON payments(status);
            CREATE INDEX IF NOT EXISTS idx_payments_method ON payments(method_id);
        `);

        // Index pour les logs
        await client.query(`
            CREATE INDEX IF NOT EXISTS idx_activity_logs_user ON activity_logs(user_id);
            CREATE INDEX IF NOT EXISTS idx_activity_logs_date ON activity_logs(created_at);
        `);

        logger.info('✓ Index créés');

        // Valider la transaction
        await client.query('COMMIT');
        logger.info('✓ Base de données initialisée avec succès');

    } catch (error) {
        // Annuler la transaction en cas d'erreur
        await client.query('ROLLBACK');
        logger.error(`Erreur lors de l'initialisation: ${error.message}`);
        throw error;
    } finally {
        client.release();
    }
}

/**
 * Réinitialiser complètement la base de données
 * ATTENTION: Supprime toutes les données!
 */
async function resetDatabase() {
    const client = await pool.connect();
    
    try {
        await client.query('BEGIN');

        // Supprimer les tables dans l'ordre inverse des dépendances
        const tables = [
            'activity_logs',
            'statistics',
            'settings',
            'downloads',
            'notifications',
            'payments',
            'methods',
            'whatsapp_bots',
            'telegram_bots',
            'projects',
            'sessions',
            'users'
        ];

        for (const table of tables) {
            await client.query(`DROP TABLE IF EXISTS ${table} CASCADE`);
            logger.info(`✓ Table ${table} supprimée`);
        }

        await client.query('COMMIT');
        logger.info('✓ Base de données réinitialisée');

    } catch (error) {
        await client.query('ROLLBACK');
        logger.error(`Erreur lors de la réinitialisation: ${error.message}`);
        throw error;
    } finally {
        client.release();
    }
}

// Exporter les fonctions
module.exports = {
    pool,
    checkDatabaseConnection,
    initDatabase,
    resetDatabase
};
