/**
 * ================================================
 * SERVICE AUTHENTIFICATION
 * ================================================
 * Logique métier pour l'authentification
 * Inscription, connexion, vérification
 */

const User = require('../models/User');
const ActivityLog = require('../models/ActivityLog');
const { generateToken } = require('../middleware/auth');
const logger = require('../config/logger');

class AuthService {
    /**
     * Inscrire un nouvel utilisateur
     * @param {Object} userData - Données d'inscription
     * @param {string} ipAddress - Adresse IP de l'utilisateur
     * @returns {Promise<Object>} Utilisateur créé avec token
     */
    static async register(userData, ipAddress) {
        try {
            const { username, email, password, fullName } = userData;

            // Vérifier si l'utilisateur existe déjà
            const existingUser = await User.findByEmail(email);
            if (existingUser) {
                throw new Error('Un utilisateur avec cet email existe déjà');
            }

            const existingUsername = await User.findByUsername(username);
            if (existingUsername) {
                throw new Error('Ce nom d\'utilisateur est déjà pris');
            }

            // Créer l'utilisateur
            const newUser = await User.create({
                username,
                email,
                password,
                fullName
            });

            // Enregistrer l'activité
            await ActivityLog.create({
                userId: newUser.id,
                action: 'user_registered',
                entityType: 'user',
                entityId: newUser.id,
                details: `Nouvel utilisateur inscrit: ${username}`,
                ipAddress
            });

            // Générer le token
            const token = generateToken(newUser);

            logger.info(`✓ Nouvel utilisateur inscrit: ${username}`);

            return {
                user: newUser,
                token: token
            };
        } catch (error) {
            logger.error(`Erreur inscription: ${error.message}`);
            throw error;
        }
    }

    /**
     * Authentifier un utilisateur (connexion)
     * @param {string} email - Email de l'utilisateur
     * @param {string} password - Mot de passe en clair
     * @param {string} ipAddress - Adresse IP
     * @returns {Promise<Object>} Utilisateur avec token
     */
    static async login(email, password, ipAddress) {
        try {
            // Trouver l'utilisateur
            const user = await User.findByEmail(email);
            if (!user) {
                throw new Error('Email ou mot de passe incorrect');
            }

            // Vérifier le mot de passe
            const isValidPassword = await User.verifyPassword(password, user.password_hash);
            if (!isValidPassword) {
                // Enregistrer la tentative échouée
                await ActivityLog.create({
                    userId: user.id,
                    action: 'login_failed',
                    details: 'Mot de passe incorrect',
                    ipAddress
                });

                throw new Error('Email ou mot de passe incorrect');
            }

            // Vérifier si l'utilisateur est banni
            if (user.is_banned) {
                logger.warn(`Tentative login d'utilisateur banni: ${email}`);
                throw new Error('Votre compte a été banni');
            }

            // Générer le token
            const token = generateToken(user);

            // Enregistrer la connexion
            await ActivityLog.create({
                userId: user.id,
                action: 'user_login',
                entityType: 'user',
                entityId: user.id,
                details: 'Connexion réussie',
                ipAddress
            });

            logger.info(`✓ Utilisateur connecté: ${email}`);

            return {
                user: user,
                token: token
            };
        } catch (error) {
            logger.error(`Erreur connexion: ${error.message}`);
            throw error;
        }
    }

    /**
     * Déconnexion d'un utilisateur
     * @param {string} userId - ID de l'utilisateur
     * @param {string} ipAddress - Adresse IP
     * @returns {Promise<void>}
     */
    static async logout(userId, ipAddress) {
        try {
            await ActivityLog.create({
                userId: userId,
                action: 'user_logout',
                entityType: 'user',
                entityId: userId,
                details: 'Déconnexion',
                ipAddress
            });

            logger.info(`✓ Utilisateur déconnecté: ${userId}`);
        } catch (error) {
            logger.error(`Erreur déconnexion: ${error.message}`);
            throw error;
        }
    }

    /**
     * Vérifier un email
     * @param {string} userId - ID de l'utilisateur
     * @returns {Promise<void>}
     */
    static async verifyEmail(userId) {
        try {
            await User.verifyEmail(userId);
            logger.info(`✓ Email vérifié pour utilisateur: ${userId}`);
        } catch (error) {
            logger.error(`Erreur vérification email: ${error.message}`);
            throw error;
        }
    }

    /**
     * Changer le mot de passe
     * @param {string} userId - ID de l'utilisateur
     * @param {string} oldPassword - Ancien mot de passe
     * @param {string} newPassword - Nouveau mot de passe
     * @returns {Promise<void>}
     */
    static async changePassword(userId, oldPassword, newPassword, ipAddress) {
        try {
            const user = await User.findById(userId);
            if (!user) {
                throw new Error('Utilisateur non trouvé');
            }

            // Vérifier l'ancien mot de passe
            const isValid = await User.verifyPassword(oldPassword, user.password_hash);
            if (!isValid) {
                throw new Error('Ancien mot de passe incorrect');
            }

            // Mettre à jour le mot de passe
            const bcrypt = require('bcryptjs');
            const hashedPassword = await bcrypt.hash(newPassword, parseInt(process.env.BCRYPT_ROUNDS) || 10);

            const { pool } = require('../config/database');
            await pool.query(
                'UPDATE users SET password_hash = $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2',
                [hashedPassword, userId]
            );

            // Enregistrer l'activité
            await ActivityLog.create({
                userId: userId,
                action: 'password_changed',
                entityType: 'user',
                entityId: userId,
                details: 'Mot de passe changé',
                ipAddress
            });

            logger.info(`✓ Mot de passe changé pour: ${userId}`);
        } catch (error) {
            logger.error(`Erreur changement mot de passe: ${error.message}`);
            throw error;
        }
    }

    /**
     * Obtenir les informations de l'utilisateur connecté
     * @param {string} userId - ID de l'utilisateur
     * @returns {Promise<Object>} Données utilisateur
     */
    static async getCurrentUser(userId) {
        try {
            const user = await User.findById(userId);
            if (!user) {
                throw new Error('Utilisateur non trouvé');
            }

            return user;
        } catch (error) {
            logger.error(`Erreur récupération utilisateur: ${error.message}`);
            throw error;
        }
    }

    /**
     * Rafraîchir le token JWT
     * @param {string} userId - ID de l'utilisateur
     * @returns {Promise<string>} Nouveau token
     */
    static async refreshToken(userId) {
        try {
            const user = await User.findById(userId);
            if (!user) {
                throw new Error('Utilisateur non trouvé');
            }

            const token = generateToken(user);
            return token;
        } catch (error) {
            logger.error(`Erreur rafraîchissement token: ${error.message}`);
            throw error;
        }
    }

    /**
     * Réinitialiser le mot de passe (pour forgot password)
     * @param {string} email - Email de l'utilisateur
     * @returns {Promise<Object>} Token de réinitialisation
     */
    static async requestPasswordReset(email) {
        try {
            const user = await User.findByEmail(email);
            if (!user) {
                // Ne pas révéler si l'email existe
                logger.warn(`Demande reset password pour email inexistant: ${email}`);
                return { message: 'Si cet email existe, vous recevrez un lien' };
            }

            // Générer un token de réinitialisation
            const resetToken = require('crypto').randomBytes(32).toString('hex');

            // Sauvegarder le token (à implémenter dans la table users)
            const { pool } = require('../config/database');
            await pool.query(
                'UPDATE users SET verification_token = $1 WHERE id = $2',
                [resetToken, user.id]
            );

            logger.info(`✓ Token reset password généré pour: ${email}`);

            return {
                message: 'Lien de réinitialisation envoyé',
                resetToken: resetToken
            };
        } catch (error) {
            logger.error(`Erreur demande reset: ${error.message}`);
            throw error;
        }
    }

    /**
     * Compléter la réinitialisation du mot de passe
     * @param {string} resetToken - Token de réinitialisation
     * @param {string} newPassword - Nouveau mot de passe
     * @returns {Promise<void>}
     */
    static async completePasswordReset(resetToken, newPassword) {
        try {
            const user = await User.findByEmail(''); // À améliorer
            if (!user || user.verification_token !== resetToken) {
                throw new Error('Token de réinitialisation invalide');
            }

            // Mettre à jour le mot de passe
            const bcrypt = require('bcryptjs');
            const hashedPassword = await bcrypt.hash(newPassword, parseInt(process.env.BCRYPT_ROUNDS) || 10);

            const { pool } = require('../config/database');
            await pool.query(
                'UPDATE users SET password_hash = $1, verification_token = NULL WHERE id = $2',
                [hashedPassword, user.id]
            );

            logger.info(`✓ Mot de passe réinitialisé pour: ${user.email}`);
        } catch (error) {
            logger.error(`Erreur completion reset: ${error.message}`);
            throw error;
        }
    }
}

module.exports = AuthService;
