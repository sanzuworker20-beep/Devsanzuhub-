/**
 * ================================================
 * SERVICE PAIEMENT
 * ================================================
 * Logique métier pour les paiements
 * Validation manuelle et déblocage de coordonnées
 */

const Payment = require('../models/Payment');
const Method = require('../models/Method');
const User = require('../models/User');
const Notification = require('../models/Notification');
const ActivityLog = require('../models/ActivityLog');
const logger = require('../config/logger');

class PaymentService {
    /**
     * Créer une demande de paiement
     * @param {string} userId - ID de l'utilisateur
     * @param {string} methodId - ID de la méthode
     * @param {number} amount - Montant
     * @param {string} ipAddress - Adresse IP
     * @returns {Promise<Object>} Paiement créé
     */
    static async createPayment(userId, methodId, amount, ipAddress) {
        try {
            // Vérifier la méthode
            const method = await Method.findById(methodId);
            if (!method) {
                throw new Error('Méthode non trouvée');
            }

            // Vérifier l'utilisateur
            const user = await User.findById(userId);
            if (!user) {
                throw new Error('Utilisateur non trouvé');
            }

            // Vérifier que le montant correspond
            if (amount !== method.price) {
                throw new Error('Le montant ne correspond pas au prix de la méthode');
            }

            // Créer le paiement
            const payment = await Payment.create({
                userId: userId,
                methodId: methodId,
                amount: amount,
                currency: method.currency,
                paymentMethod: 'qrcode',
                transactionId: `txn_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
                notes: `Paiement pour: ${method.title}`
            });

            // Enregistrer l'activité
            await ActivityLog.create({
                userId: userId,
                action: 'payment_created',
                entityType: 'payment',
                entityId: payment.id,
                details: `Paiement initié pour la méthode: ${method.title}`,
                ipAddress
            });

            // Créer une notification
            await Notification.create({
                userId: userId,
                type: 'payment',
                title: 'Paiement initié',
                message: `Votre paiement de ${amount} ${method.currency} pour "${method.title}" est en attente de validation. Le délai d'attente est généralement de 2-24 heures.`,
                relatedId: payment.id
            });

            logger.info(`✓ Paiement créé: ${payment.id} - Utilisateur: ${userId}`);

            return payment;
        } catch (error) {
            logger.error(`Erreur création paiement: ${error.message}`);
            throw error;
        }
    }

    /**
     * Obtenir les paiements en attente de validation
     * @param {number} limit - Limite
     * @param {number} offset - Décalage
     * @returns {Promise<Array>} Paiements en attente
     */
    static async getPendingPayments(limit = 50, offset = 0) {
        try {
            const payments = await Payment.getPending(limit, offset);
            return payments;
        } catch (error) {
            logger.error(`Erreur paiements en attente: ${error.message}`);
            throw error;
        }
    }

    /**
     * Valider un paiement (par admin)
     * @param {string} paymentId - ID du paiement
     * @param {string} adminId - ID de l'admin
     * @param {string} notes - Notes de validation
     * @returns {Promise<Object>} Paiement validé
     */
    static async validatePayment(paymentId, adminId, notes = '') {
        try {
            // Obtenir le paiement
            const payment = await Payment.findById(paymentId);
            if (!payment) {
                throw new Error('Paiement non trouvé');
            }

            // Valider le paiement
            const validatedPayment = await Payment.validate(paymentId, adminId, notes);

            // Débloquer les coordonnées de l'utilisateur
            await Payment.unlockContact(paymentId);

            // Incrémenter le compteur d'achats de la méthode
            await Method.incrementPurchaseCount(payment.method_id);

            // Créer une notification pour l'utilisateur
            const method = await Method.findById(payment.method_id);
            await Notification.create({
                userId: payment.user_id,
                type: 'payment_validated',
                title: 'Paiement validé!',
                message: `Votre paiement pour "${method.title}" a été validé. Vous avez accès au contenu privé et vos coordonnées de contact ont été débloquées.`,
                relatedId: paymentId
            });

            // Enregistrer l'activité
            await ActivityLog.create({
                userId: adminId,
                action: 'payment_validated',
                entityType: 'payment',
                entityId: paymentId,
                details: `Paiement ${paymentId} validé - ${notes}`,
                ipAddress: ''
            });

            logger.info(`✓ Paiement validé: ${paymentId}`);

            return validatedPayment;
        } catch (error) {
            logger.error(`Erreur validation paiement: ${error.message}`);
            throw error;
        }
    }

    /**
     * Rejeter un paiement
     * @param {string} paymentId - ID du paiement
     * @param {string} adminId - ID de l'admin
     * @param {string} reason - Raison du rejet
     * @returns {Promise<Object>} Paiement rejeté
     */
    static async rejectPayment(paymentId, adminId, reason = '') {
        try {
            // Obtenir le paiement
            const payment = await Payment.findById(paymentId);
            if (!payment) {
                throw new Error('Paiement non trouvé');
            }

            // Rejeter le paiement
            const rejectedPayment = await Payment.reject(paymentId, adminId, reason);

            // Créer une notification pour l'utilisateur
            const method = await Method.findById(payment.method_id);
            await Notification.create({
                userId: payment.user_id,
                type: 'payment_rejected',
                title: 'Paiement rejeté',
                message: `Votre paiement pour "${method.title}" a été rejeté. Raison: ${reason || 'Non spécifiée'}. Veuillez nous contacter.`,
                relatedId: paymentId
            });

            // Enregistrer l'activité
            await ActivityLog.create({
                userId: adminId,
                action: 'payment_rejected',
                entityType: 'payment',
                entityId: paymentId,
                details: `Paiement ${paymentId} rejeté - ${reason}`,
                ipAddress: ''
            });

            logger.info(`✓ Paiement rejeté: ${paymentId}`);

            return rejectedPayment;
        } catch (error) {
            logger.error(`Erreur rejet paiement: ${error.message}`);
            throw error;
        }
    }

    /**
     * Obtenir les paiements d'un utilisateur
     * @param {string} userId - ID de l'utilisateur
     * @param {number} limit - Limite
     * @param {number} offset - Décalage
     * @returns {Promise<Array>} Paiements de l'utilisateur
     */
    static async getUserPayments(userId, limit = 50, offset = 0) {
        try {
            const payments = await Payment.getByUser(userId, limit, offset);
            return payments;
        } catch (error) {
            logger.error(`Erreur paiements utilisateur: ${error.message}`);
            throw error;
        }
    }

    /**
     * Vérifier si un utilisateur a accès à une méthode
     * @param {string} userId - ID de l'utilisateur
     * @param {string} methodId - ID de la méthode
     * @returns {Promise<boolean>} Vrai si l'utilisateur a accès
     */
    static async hasAccessToMethod(userId, methodId) {
        try {
            const payments = await Payment.getByUser(userId);
            const validPayment = payments.find(p => 
                p.method_id === methodId && p.is_validated === true
            );
            return !!validPayment;
        } catch (error) {
            logger.error(`Erreur vérification accès: ${error.message}`);
            throw error;
        }
    }

    /**
     * Obtenir le contenu privé d'une méthode (avec vérification d'accès)
     * @param {string} userId - ID de l'utilisateur
     * @param {string} methodId - ID de la méthode
     * @returns {Promise<Object>} Contenu privé
     */
    static async getMethodContent(userId, methodId) {
        try {
            // Vérifier l'accès
            const hasAccess = await this.hasAccessToMethod(userId, methodId);
            if (!hasAccess) {
                throw new Error('Vous n\'avez pas accès à ce contenu');
            }

            // Obtenir le contenu
            const method = await Method.getPrivateContent(methodId);
            if (!method) {
                throw new Error('Contenu non trouvé');
            }

            // Enregistrer l'accès
            await ActivityLog.create({
                userId: userId,
                action: 'access_private_content',
                entityType: 'method',
                entityId: methodId,
                details: `Accès au contenu privé de la méthode ${methodId}`,
                ipAddress: ''
            });

            return method;
        } catch (error) {
            logger.error(`Erreur accès contenu: ${error.message}`);
            throw error;
        }
    }

    /**
     * Obtenir les statistiques de paiement
     * @returns {Promise<Object>} Statistiques
     */
    static async getPaymentStatistics() {
        try {
            const stats = await Payment.getStatistics();
            return {
                totalPayments: parseInt(stats.total_payments) || 0,
                validatedPayments: parseInt(stats.validated_payments) || 0,
                pendingPayments: parseInt(stats.pending_payments) || 0,
                totalRevenue: parseFloat(stats.total_revenue) || 0,
                averagePayment: parseFloat(stats.average_payment) || 0
            };
        } catch (error) {
            logger.error(`Erreur statistiques: ${error.message}`);
            throw error;
        }
    }

    /**
     * Envoyer une notification de rappel pour paiement en attente
     * @returns {Promise<void>}
     */
    static async sendPendingReminders() {
        try {
            // Obtenir tous les paiements en attente depuis plus de 1h
            const payments = await Payment.getPending(1000);
            
            for (const payment of payments) {
                const createdAt = new Date(payment.created_at);
                const now = new Date();
                const hoursDifference = (now - createdAt) / (1000 * 60 * 60);

                if (hoursDifference > 1 && hoursDifference < 24) {
                    // Envoyer un rappel
                    await Notification.create({
                        userId: payment.user_id,
                        type: 'payment_reminder',
                        title: 'Rappel: Paiement en attente',
                        message: 'Votre paiement est toujours en attente de validation. Il sera traité dans les 24 heures.',
                        relatedId: payment.id
                    });
                }
            }

            logger.info(`✓ Rappels de paiement envoyés`);
        } catch (error) {
            logger.error(`Erreur envoi rappels: ${error.message}`);
            throw error;
        }
    }
}

module.exports = PaymentService;
