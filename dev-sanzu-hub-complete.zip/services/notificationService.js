/**
 * ================================================
 * SERVICE NOTIFICATIONS
 * ================================================
 * Gestion des notifications utilisateurs
 * Créations d'événements et alertes
 */

const Notification = require('../models/Notification');
const logger = require('../config/logger');

class NotificationService {
    /**
     * Créer et envoyer une notification
     * @param {string} userId - ID de l'utilisateur
     * @param {Object} notificationData - Données de la notification
     * @returns {Promise<Object>} Notification créée
     */
    static async sendNotification(userId, notificationData) {
        try {
            const {
                type = 'info',
                title,
                message,
                relatedId = null,
                priority = 'normal'
            } = notificationData;

            const notification = await Notification.create({
                userId,
                type,
                title,
                message,
                relatedId
            });

            // Ajouter la priorité aux logs
            if (priority === 'high') {
                logger.warn(`[NOTIFICATION] High Priority - ${title}`);
            } else {
                logger.debug(`[NOTIFICATION] ${type} - ${title}`);
            }

            return notification;
        } catch (error) {
            logger.error(`Erreur envoi notification: ${error.message}`);
            throw error;
        }
    }

    /**
     * Envoyer une notification de bienvenue
     * @param {string} userId - ID de l'utilisateur
     * @param {string} username - Nom d'utilisateur
     * @returns {Promise<void>}
     */
    static async sendWelcomeNotification(userId, username) {
        try {
            await this.sendNotification(userId, {
                type: 'welcome',
                title: 'Bienvenue!',
                message: `Bienvenue ${username}! Explorez nos bots gratuits et nos méthodes exclusives.`
            });
        } catch (error) {
            logger.error(`Erreur notification bienvenue: ${error.message}`);
            throw error;
        }
    }

    /**
     * Notifier lors d'une validation de paiement
     * @param {string} userId - ID de l'utilisateur
     * @param {string} methodTitle - Titre de la méthode
     * @returns {Promise<void>}
     */
    static async notifyPaymentValidated(userId, methodTitle) {
        try {
            await this.sendNotification(userId, {
                type: 'payment_validated',
                title: 'Paiement Validé!',
                message: `Votre paiement pour "${methodTitle}" a été validé. Vous avez accès au contenu privé.`,
                priority: 'high'
            });
        } catch (error) {
            logger.error(`Erreur notification paiement: ${error.message}`);
            throw error;
        }
    }

    /**
     * Notifier lors d'une nouvelle méthode
     * @param {Array} userIds - IDs des utilisateurs à notifier
     * @param {string} methodTitle - Titre de la méthode
     * @returns {Promise<void>}
     */
    static async notifyNewMethod(userIds, methodTitle) {
        try {
            await Notification.sendBulk(
                userIds,
                'new_method',
                'Nouvelle Méthode!',
                `Une nouvelle méthode "${methodTitle}" vient de être publiée. Découvrez-la maintenant!`
            );
        } catch (error) {
            logger.error(`Erreur notification nouvelle méthode: ${error.message}`);
            throw error;
        }
    }

    /**
     * Notifier lors d'une nouvelle bot
     * @param {Array} userIds - IDs des utilisateurs à notifier
     * @param {string} botName - Nom du bot
     * @param {string} botType - Type du bot (telegram/whatsapp)
     * @returns {Promise<void>}
     */
    static async notifyNewBot(userIds, botName, botType) {
        try {
            await Notification.sendBulk(
                userIds,
                'new_bot',
                `Nouveau Bot ${botType.toUpperCase()}!`,
                `Un nouveau bot "${botName}" est maintenant disponible au téléchargement!`
            );
        } catch (error) {
            logger.error(`Erreur notification nouveau bot: ${error.message}`);
            throw error;
        }
    }

    /**
     * Notifier un utilisateur de l'accès à une ressource
     * @param {string} userId - ID de l'utilisateur
     * @param {string} resourceName - Nom de la ressource
     * @returns {Promise<void>}
     */
    static async notifyResourceAccess(userId, resourceName) {
        try {
            await this.sendNotification(userId, {
                type: 'resource_access',
                title: 'Accès Accordé',
                message: `Vous avez accès à: ${resourceName}`
            });
        } catch (error) {
            logger.error(`Erreur notification accès: ${error.message}`);
            throw error;
        }
    }

    /**
     * Notifier une action de système
     * @param {Array} userIds - IDs des utilisateurs
     * @param {string} title - Titre
     * @param {string} message - Message
     * @returns {Promise<void>}
     */
    static async notifySystem(userIds, title, message) {
        try {
            await Notification.sendBulk(userIds, 'system', title, message);
        } catch (error) {
            logger.error(`Erreur notification système: ${error.message}`);
            throw error;
        }
    }

    /**
     * Notifier une maintenance
     * @param {Array} userIds - IDs des utilisateurs
     * @param {string} maintenanceTime - Heure de maintenance
     * @param {string} duration - Durée estimée
     * @returns {Promise<void>}
     */
    static async notifyMaintenance(userIds, maintenanceTime, duration) {
        try {
            await Notification.sendBulk(
                userIds,
                'maintenance',
                'Maintenance Programmée',
                `Le site sera en maintenance le ${maintenanceTime} pendant environ ${duration}. Merci pour votre patience!`
            );
        } catch (error) {
            logger.error(`Erreur notification maintenance: ${error.message}`);
            throw error;
        }
    }

    /**
     * Notifier une erreur ou alerte
     * @param {string} userId - ID de l'utilisateur
     * @param {string} title - Titre
     * @param {string} message - Message
     * @returns {Promise<void>}
     */
    static async notifyAlert(userId, title, message) {
        try {
            await this.sendNotification(userId, {
                type: 'alert',
                title,
                message,
                priority: 'high'
            });
        } catch (error) {
            logger.error(`Erreur notification alerte: ${error.message}`);
            throw error;
        }
    }

    /**
     * Obtenir les notifications non lues d'un utilisateur
     * @param {string} userId - ID de l'utilisateur
     * @returns {Promise<Array>} Notifications non lues
     */
    static async getUnreadNotifications(userId) {
        try {
            const notifications = await Notification.getUnread(userId);
            return notifications;
        } catch (error) {
            logger.error(`Erreur récupération notifications: ${error.message}`);
            throw error;
        }
    }

    /**
     * Obtenir le nombre de notifications non lues
     * @param {string} userId - ID de l'utilisateur
     * @returns {Promise<number>} Nombre de notifications non lues
     */
    static async getUnreadCount(userId) {
        try {
            const count = await Notification.countUnread(userId);
            return count;
        } catch (error) {
            logger.error(`Erreur compte notifications: ${error.message}`);
            throw error;
        }
    }

    /**
     * Marquer une notification comme lue
     * @param {string} notificationId - ID de la notification
     * @returns {Promise<void>}
     */
    static async markAsRead(notificationId) {
        try {
            await Notification.markAsRead(notificationId);
        } catch (error) {
            logger.error(`Erreur marquage notification: ${error.message}`);
            throw error;
        }
    }

    /**
     * Marquer toutes les notifications comme lues
     * @param {string} userId - ID de l'utilisateur
     * @returns {Promise<void>}
     */
    static async markAllAsRead(userId) {
        try {
            await Notification.markAllAsRead(userId);
        } catch (error) {
            logger.error(`Erreur marquage all notifications: ${error.message}`);
            throw error;
        }
    }

    /**
     * Supprimer une notification
     * @param {string} notificationId - ID de la notification
     * @returns {Promise<void>}
     */
    static async deleteNotification(notificationId) {
        try {
            await Notification.delete(notificationId);
        } catch (error) {
            logger.error(`Erreur suppression notification: ${error.message}`);
            throw error;
        }
    }

    /**
     * Nettoyer les notifications lues d'un utilisateur
     * @param {string} userId - ID de l'utilisateur
     * @returns {Promise<void>}
     */
    static async cleanupReadNotifications(userId) {
        try {
            await Notification.deleteReadNotifications(userId);
        } catch (error) {
            logger.error(`Erreur nettoyage notifications: ${error.message}`);
            throw error;
        }
    }

    /**
     * Créer une notification pour tous les utilisateurs (admin)
     * @param {string} title - Titre
     * @param {string} message - Message
     * @returns {Promise<void>}
     */
    static async broadcastNotification(title, message) {
        try {
            await Notification.createSystemNotification(title, message);
            logger.info(`✓ Notification broadcastée: ${title}`);
        } catch (error) {
            logger.error(`Erreur broadcast notification: ${error.message}`);
            throw error;
        }
    }
}

module.exports = NotificationService;
