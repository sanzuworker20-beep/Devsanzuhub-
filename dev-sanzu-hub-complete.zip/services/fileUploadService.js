/**
 * ================================================
 * SERVICE GESTION DES FICHIERS
 * ================================================
 * Upload, suppression et gestion des fichiers
 * Configuration Multer pour les uploads sécurisés
 */

const multer = require('multer');
const path = require('path');
const fs = require('fs');
const logger = require('../config/logger');

// Dossier d'upload
const uploadDir = process.env.UPLOAD_DIR || 'uploads';

// Vérifier et créer les dossiers
const uploadFolders = [
    uploadDir,
    `${uploadDir}/projects`,
    `${uploadDir}/bots`,
    `${uploadDir}/methods`,
    `${uploadDir}/avatars`,
    `${uploadDir}/temp`
];

uploadFolders.forEach(folder => {
    if (!fs.existsSync(folder)) {
        fs.mkdirSync(folder, { recursive: true });
    }
});

// Extensions autorisées
const ALLOWED_EXTENSIONS = {
    'image': ['jpg', 'jpeg', 'png', 'gif', 'webp'],
    'archive': ['zip', 'rar', '7z', 'tar', 'gz'],
    'document': ['pdf', 'doc', 'docx', 'txt', 'xlsx'],
};

/**
 * Configurer multer pour les images
 */
const imageStorage = multer.diskStorage({
    destination: function (req, file, cb) {
        const folder = `${uploadDir}/avatars`;
        cb(null, folder);
    },
    filename: function (req, file, cb) {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
    }
});

/**
 * Configurer multer pour les archives (bots)
 */
const botStorage = multer.diskStorage({
    destination: function (req, file, cb) {
        const folder = `${uploadDir}/bots`;
        cb(null, folder);
    },
    filename: function (req, file, cb) {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
    }
});

/**
 * Vérifier le type de fichier
 */
function fileFilter(req, file, cb) {
    const ext = path.extname(file.originalname).toLowerCase().slice(1);
    const allowedExts = process.env.ALLOWED_EXTENSIONS?.split(',') || 
        ['zip', 'rar', '7z', 'jpg', 'jpeg', 'png', 'gif', 'pdf'];

    if (allowedExts.includes(ext)) {
        cb(null, true);
    } else {
        cb(new Error(`Extension non autorisée: ${ext}`));
    }
}

/**
 * Middleware multer pour les images
 */
const uploadImage = multer({
    storage: imageStorage,
    limits: {
        fileSize: parseInt(process.env.MAX_FILE_SIZE) || 50000000 // 50MB par défaut
    },
    fileFilter: fileFilter
});

/**
 * Middleware multer pour les archives
 */
const uploadBot = multer({
    storage: botStorage,
    limits: {
        fileSize: parseInt(process.env.MAX_FILE_SIZE) || 50000000
    },
    fileFilter: fileFilter
});

class FileUploadService {
    /**
     * Obtenir le middleware multer pour les images
     */
    static getImageUploadMiddleware() {
        return uploadImage.single('image');
    }

    /**
     * Obtenir le middleware multer pour les bots
     */
    static getBotUploadMiddleware() {
        return uploadBot.single('file');
    }

    /**
     * Obtenir le middleware multer pour plusieurs fichiers
     */
    static getMultipleFilesMiddleware() {
        return uploadBot.array('files', 10);
    }

    /**
     * Obtenir le chemin URL d'un fichier
     * @param {string} filePath - Chemin du fichier
     * @returns {string} URL du fichier
     */
    static getFileURL(filePath) {
        return `${process.env.APP_URL}/${filePath}`;
    }

    /**
     * Supprimer un fichier
     * @param {string} filePath - Chemin du fichier
     * @returns {Promise<boolean>} Succès ou non
     */
    static async deleteFile(filePath) {
        try {
            if (!filePath) {
                return false;
            }

            // Sécurité: vérifier que le chemin est dans le dossier upload
            if (!filePath.startsWith(uploadDir)) {
                logger.warn(`Tentative suppression fichier non autorisé: ${filePath}`);
                return false;
            }

            if (fs.existsSync(filePath)) {
                fs.unlinkSync(filePath);
                logger.info(`✓ Fichier supprimé: ${filePath}`);
                return true;
            }

            return false;
        } catch (error) {
            logger.error(`Erreur suppression fichier: ${error.message}`);
            return false;
        }
    }

    /**
     * Obtenir les informations d'un fichier
     * @param {string} filePath - Chemin du fichier
     * @returns {Object} Informations du fichier
     */
    static getFileInfo(filePath) {
        try {
            if (!fs.existsSync(filePath)) {
                return null;
            }

            const stats = fs.statSync(filePath);
            return {
                path: filePath,
                size: stats.size,
                created: stats.birthtime,
                modified: stats.mtime,
                extension: path.extname(filePath).slice(1)
            };
        } catch (error) {
            logger.error(`Erreur info fichier: ${error.message}`);
            return null;
        }
    }

    /**
     * Valider les informations du fichier uploadé
     * @param {Object} file - Objet fichier de multer
     * @returns {Object} Validation result
     */
    static validateUploadedFile(file) {
        if (!file) {
            return {
                valid: false,
                error: 'Aucun fichier fourni'
            };
        }

        const maxSize = parseInt(process.env.MAX_FILE_SIZE) || 50000000;

        if (file.size > maxSize) {
            return {
                valid: false,
                error: `Fichier trop volumineux (max: ${maxSize / 1000000}MB)`
            };
        }

        const ext = path.extname(file.originalname).toLowerCase().slice(1);
        const allowedExts = process.env.ALLOWED_EXTENSIONS?.split(',') || 
            ['zip', 'rar', '7z', 'jpg', 'jpeg', 'png', 'gif', 'pdf'];

        if (!allowedExts.includes(ext)) {
            return {
                valid: false,
                error: `Extension non autorisée: ${ext}`
            };
        }

        return {
            valid: true,
            fileInfo: {
                originalName: file.originalname,
                filename: file.filename,
                path: file.path,
                size: file.size,
                mimeType: file.mimetype,
                extension: ext
            }
        };
    }

    /**
     * Copier un fichier
     * @param {string} sourcePath - Chemin source
     * @param {string} destPath - Chemin destination
     * @returns {Promise<boolean>} Succès ou non
     */
    static async copyFile(sourcePath, destPath) {
        try {
            if (!fs.existsSync(sourcePath)) {
                throw new Error('Fichier source non trouvé');
            }

            fs.copyFileSync(sourcePath, destPath);
            logger.info(`✓ Fichier copié: ${sourcePath} -> ${destPath}`);
            return true;
        } catch (error) {
            logger.error(`Erreur copie fichier: ${error.message}`);
            return false;
        }
    }

    /**
     * Renommer un fichier
     * @param {string} oldPath - Ancien chemin
     * @param {string} newPath - Nouveau chemin
     * @returns {Promise<boolean>} Succès ou non
     */
    static async renameFile(oldPath, newPath) {
        try {
            if (!fs.existsSync(oldPath)) {
                throw new Error('Fichier non trouvé');
            }

            fs.renameSync(oldPath, newPath);
            logger.info(`✓ Fichier renommé: ${oldPath} -> ${newPath}`);
            return true;
        } catch (error) {
            logger.error(`Erreur renommage fichier: ${error.message}`);
            return false;
        }
    }

    /**
     * Nettoyer les anciens fichiers temporaires
     * @param {number} ageInHours - Supprimer les fichiers plus anciens que X heures
     * @returns {Promise<number>} Nombre de fichiers supprimés
     */
    static async cleanupTempFiles(ageInHours = 24) {
        try {
            const tempDir = `${uploadDir}/temp`;
            let deletedCount = 0;

            if (!fs.existsSync(tempDir)) {
                return 0;
            }

            const files = fs.readdirSync(tempDir);
            const now = Date.now();
            const maxAge = ageInHours * 60 * 60 * 1000;

            for (const file of files) {
                const filePath = path.join(tempDir, file);
                const stats = fs.statSync(filePath);
                const age = now - stats.mtime.getTime();

                if (age > maxAge) {
                    fs.unlinkSync(filePath);
                    deletedCount++;
                }
            }

            if (deletedCount > 0) {
                logger.info(`✓ ${deletedCount} fichiers temporaires supprimés`);
            }

            return deletedCount;
        } catch (error) {
            logger.error(`Erreur nettoyage fichiers: ${error.message}`);
            return 0;
        }
    }

    /**
     * Obtenir les statistiques des uploads
     * @returns {Object} Statistiques
     */
    static getUploadStatistics() {
        try {
            let totalSize = 0;
            let totalFiles = 0;

            const getDirectorySize = (dir) => {
                let size = 0;
                let files = 0;

                if (!fs.existsSync(dir)) {
                    return { size, files };
                }

                const items = fs.readdirSync(dir);
                for (const item of items) {
                    const itemPath = path.join(dir, item);
                    const stats = fs.statSync(itemPath);

                    if (stats.isFile()) {
                        size += stats.size;
                        files++;
                    } else if (stats.isDirectory()) {
                        const subStats = getDirectorySize(itemPath);
                        size += subStats.size;
                        files += subStats.files;
                    }
                }

                return { size, files };
            };

            const stats = getDirectorySize(uploadDir);

            return {
                totalSize: stats.size,
                totalSizeInMB: (stats.size / 1000000).toFixed(2),
                totalFiles: stats.files,
                maxFileSize: parseInt(process.env.MAX_FILE_SIZE) || 50000000,
                maxFileSizeInMB: (parseInt(process.env.MAX_FILE_SIZE) / 1000000 || 50)
            };
        } catch (error) {
            logger.error(`Erreur statistiques upload: ${error.message}`);
            return null;
        }
    }
}

module.exports = FileUploadService;
